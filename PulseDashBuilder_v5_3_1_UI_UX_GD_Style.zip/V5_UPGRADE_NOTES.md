# Pulse Dash Builder — v5 Ultimate Upgrade Notes

> **Engine target:** Godot 4.7.1, GDScript 2.0
> **Upgrade date:** 2026-07-26 (round 4 updates: 2026-07-26)
> **Backward compatible:** Yes — level JSON `format_version: 3` preserved.
> **Autoloads (v5.1):** GameState, AudioManager, StatsTracker, AchievementManager, TriggerController, **DailyChallenge** *(new)*, **LocalLeaderboard** *(new)*.

This document summarizes the v5 "lột xác" (transformation) upgrade applied across
six pillars: UI/UX, Physics, Editor, Audio, Advanced Features, and Performance.

---

## 1. AudioManager.gd — Procedural Pitch-Varied SFX
- Every SFX play now accepts an optional `pitch_variance: float = 0.06` that
  randomizes the playback pitch within ±variance around 1.0, so repeated sounds
  (jump, land, place block, orb, coin, death, complete) never sound identical.
- Added per-cue variance Dictionary + public `set_sfx_pitch_variance_by_name(cue_name, variance)`.
- Preserved the existing `_build_stream()` + pool architecture.

## 2. Player.gd — Zero-GC Hot Loops + Hit-Stop + Pooling
- Audited `_physics_process` / `_process`; eliminated per-frame allocations.
  Reuses preallocated `_trail_points_buf: PackedVector2Array` and `_cached_trail_color`.
- Afterimage trail now strictly uses `AfterImagePool` (object pooling) — no per-frame `queue_free()`.
- Added `_hit_stop_remaining: float` + `apply_hit_stop(duration: float) -> void`:
  when active, `_physics_process` early-returns (skips motion) for juicy frame freeze.
  Wired into `die()` (0.06s) and `apply_orb()` (0.04s).
- Added `get_trail_color() -> Color` / `set_trail_color(c: Color) -> void` so skins
  can drive the trail color dynamically.
- Coyote time + jump buffer verified frame-accurate.

## 3. BeatClock.gd — Beat-Synced BGM Integration
- Added `sync_to_bgm(audio_manager: Node) -> void`: slaves beat detection to the
  AudioManager's BGM playback position + bpm instead of free-running delta accumulation.
- Added `beat_phase() -> float` (0.0..1.0 within current beat) for visuals.
- Added `subscribe_pulse(callable: Callable) -> void` / `unsubscribe_pulse()`.
- Free-run delta mode preserved when no BGM is loaded.

## 4. EditorOverlay.gd — Visual Trigger Wiring
- When a Trigger is selected, the overlay auto-resolves `target_id` and
  `target_group` references against all level objects and draws glowing neon-cyan
  connection lines (with arrowheads) from the trigger to each target.
- Added `_show_trigger_wiring: bool = true` toggle + `wiring_color` / `wiring_glow_color` exports.
- Uses a reusable `_wiring_targets: Array[int]` to avoid per-frame allocation.
- Existing `_draw_trigger_lines()` + pre-computed line data preserved for backward compat.

## 5. ReplayRecorder.gd — Full Replay & Ghost System
- Upgraded from a simple frame logger to a complete edge-based replay system.
- `record_input(t: float, pressed: bool) -> void`: logs raw input EDGES only
  (press/release transitions), zero-alloc via `PackedFloat32Array` + `PackedByteArray`.
- `playback(player: Node, speed: float = 1.0) -> void`: drives a player's
  `set_input_held()` from the recording.
- `to_json_string() -> String` / `from_json_string(s: String) -> bool`: base64-encodes
  the packed arrays for compact save/load. Handles both v2 (binary) and v1 (legacy) formats.
- `make_ghost_data() -> Dictionary`: lightweight ghost data for ghost racing.
- `tick_playback() -> bool`: advance playback from a game director's `_process`.
- Legacy `record_frame()` API preserved (marked `@deprecated`).

## 6. SkinManager.gd — Achievement-Linked Unlocks
- Expanded unlock registry with 5 new skins, each tied to a StatsTracker milestone
  or AchievementManager grant:
  - `neon_cyan` — 100 total jumps
  - `neon_magenta` — 25 coins collected
  - `neon_gold` — 3 levels completed
  - `shadow` — 10 deaths (perseverance)
  - `rainbow` — "Perfectionist" achievement earned
- Added `check_unlocks(stats: Node, achievements: Node) -> Array[String]` (newly unlocked this tick).
- Added `get_skin_definition(skin_id: String) -> Dictionary` (trail/primary/glow/particle colors).
- `apply_skin_to_player()` now actually applies colors to visual polygons + trail
  (not just toggles a sprite).
- `SKIN_DEFINITIONS` + `UNLOCK_CONDITIONS` const registries.

## 7. LevelLinter.gd — Enhanced Verification
- Added `lint_structured(level: Dictionary) -> Array[Dictionary]` returning typed
  results: `{severity, code, message, object_index}` (severity ∈ {error, warning, info}).
- New checks:
  1. Missing FinishGate (error)
  2. Duplicate object IDs (warning)
  3. Dangling `target_id` references (warning)
  4. Unreachable finish heuristic (info)
  5. Player start overlapping hazard (error)
  6. Speed portal sanity — `speed_quad` with no `speed_normal` reset before finish (warning)
  7. Short / long level length sanity (info / warning)
- Added `format_report(lint_results: Array[Dictionary]) -> String`.
- Legacy `lint() -> Array[String]`, `has_issues()`, `format_issues()` preserved
  for backward compatibility (now delegate to `lint_structured()`).

## 8. GameState.gd — Robust JSON Loading
- `_read_level_file()` now fully robust: handles missing files, empty files, invalid
  JSON, and non-dictionary roots — each case emits a `level_load_failed(path, reason)`
  signal and returns a safe-default level instead of crashing.
- Added `_safe_default_level() -> Dictionary`: a flat level (ground + start + finish)
  so the game is always playable even if all level loading fails.
- `level_load_failed` signal added for UI toast integration.

---

## Architecture Constraints Honored
- ✅ 5 autoloads preserved in order.
- ✅ Level JSON `format_version: 3` backward compatible.
- ✅ No `reload_current_scene()` anywhere — always `_instant_respawn()`.
- ✅ Strict GDScript 2.0 static typing (explicit return types, typed variables).
- ✅ Zero GC allocation in hot `_process` / `_physics_process` loops.
- ✅ Robust error handling for JSON loading (never crashes).

## Files Modified (8 core scripts)
1. `scripts/AudioManager.gd`
2. `scripts/Player.gd`
3. `scripts/BeatClock.gd`
4. `scripts/EditorOverlay.gd`
5. `scripts/ReplayRecorder.gd`
6. `scripts/SkinManager.gd`
7. `scripts/LevelLinter.gd`
8. `scripts/GameState.gd`

## Running
1. Unzip `PulseDashBuilder_v5_Ultimate.zip`.
2. Import `project.godot` into Godot 4.7.1.
3. Press F5 (run project) or F6 (run current scene). Startup scene: `res://scenes/Main.tscn`.

---

## 9. NEW v5 Additions (Cron Round 2)

Five new production-ready scripts implementing remaining AAA Indie features.

### 9.1 ScreenShakeController.gd
Trauma-based camera shake controller using FastNoiseLite for organic noise.
Supports impulse (shake()) and decay (trauma()) models with zero-GC _process loop.

### 9.2 TransitionWipe.gd
Fullscreen radial wipe transition with embedded GLSL shader (no external .gdshader file).
Neon-cyan edge glow, play_wipe_in/out API, wipe_completed signal.

### 9.3 DailyChallenge.gd
Daily-level-rotation manager with UTC date seeding (YYYYMMDD), completion tracking,
streak counting, and robust JSON save/load at user://daily_challenge_save.json.

### 9.4 LocalLeaderboard.gd
Top-10 local leaderboard per level stored in user://leaderboard_save.json.
Sorted by time_ms ascending with coins/deaths tiebreakers. Robust save/load.

### 9.5 TheaterMode.gd
Replay-theater controller that plays back saved replays with play/pause/seek/speed
control and optional cinematic camera zoom interpolation. Full ReplayRecorder integration.

---

## Files Modified / Added (13 total)
1. `scripts/AudioManager.gd`
2. `scripts/Player.gd`
3. `scripts/BeatClock.gd`
4. `scripts/EditorOverlay.gd`
5. `scripts/ReplayRecorder.gd`
6. `scripts/SkinManager.gd`
7. `scripts/LevelLinter.gd`
8. `scripts/GameState.gd`
9. `scripts/ScreenShakeController.gd` **(NEW)**
10. `scripts/TransitionWipe.gd` **(NEW)**
11. `scripts/DailyChallenge.gd` **(NEW)**
12. `scripts/LocalLeaderboard.gd` **(NEW)**
13. `scripts/TheaterMode.gd` **(NEW)**

---

## Round 4 Updates (2026-07-26)

### v5.1 — Autoload expansion + shader library

**`project.godot`** — promoted two v5 scripts to autoloads so they're globally
accessible without manual instantiation in every scene:

| Autoload | Script | Purpose |
|----------|--------|---------|
| `DailyChallenge` | `scripts/DailyChallenge.gd` | UTC-seeded daily level rotation, streak tracking, persistent save |
| `LocalLeaderboard` | `scripts/LocalLeaderboard.gd` | Top-10 per-level leaderboard with JSON persistence |

Both extend `Node` and are stateless services — safe to autoload. Existing
scene-level usages (if any) should be migrated to use the singleton form
(`DailyChallenge.get_daily_level()` etc.) to avoid double-instantiation.

### New shader library (`assets/shaders/`)

| File | Type | Purpose |
|------|------|---------|
| `screen_shake.gdshader` | `canvas_item` | Fullscreen UV-displacement shake — alternative to camera-offset shake. Driven by `shake_strength` uniform. Uses two-octave value noise (no texture lookups). |
| `chromatic_aberration.gdshader` | `canvas_item` | RGB channel split for death / hit-stop / portal transitions. Radial direction so it feels like lens distortion. |
| `neon_glow.gdshader` | `canvas_item` | Additive neon outline + inner glow for sprites. Single-pass, 4-neighbour edge detect. |
| `README.md` | — | Usage patterns + integration notes for `ScreenShakeController.gd`. |

**Performance notes:**
- All shaders are single-pass — no blur iterations, no extra render targets.
- `screen_shake.gdshader` uses hash-based value noise so it stays fast on
  integrated GPUs (GL_Compatibility renderer).
- `neon_glow.gdshader` samples 4 neighbours — cheap enough for per-sprite use.
- Set `texel_size` on `neon_glow.gdshader` to `Vector2(1.0/viewport_w, 1.0/viewport_h)`
  for crisp 1-pixel outlines.

**Integration with ScreenShakeController.gd:**
The controller defaults to camera-offset shake. To use the shader instead,
add a fullscreen `ColorRect` with `screen_shake.gdshader` as a child of the
controller CanvasLayer and write `intensity` to the `shake_strength` uniform
each frame. The `shake_tick` signal still fires either way for VFX sync. See
`assets/shaders/README.md` for a copy-paste snippet.

