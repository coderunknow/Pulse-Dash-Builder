# Part 1 — Audit & Bug Fixes: COMPLETE (v3.3 → v4 prep)

**All bugs listed in BUGS_AUDIT_REPORT_v4.md have been fixed at the root cause.**

## Fixed Bugs Summary (with exact locations & method)

1. **Bug 1 — Shared Shape Resource (9 scenes)**
   - Fixed: Added `resource_local_to_scene = true` to SubResource shapes in:
     Coin.tscn, FinishGate.tscn, JumpOrb.tscn, JumpPad.tscn, KeyLock.tscn, Player.tscn, Portal.tscn, Sawblade.tscn, Trigger.tscn.
   - Root cause eliminated.

2. **Bug 2 — Death + Finish race (Dual)**
   - Main.gd: Added `_pending_finish_player` latch.
   - `_on_player_died` now defers pending finish.
   - `_on_finish_reached` latches when state == DYING.

3. **Bug 3 — Unsafe `free()`**
   - Main.gd: Replaced `child.free()` → `child.queue_free()` in:
     `_clear_runtime_world()`, `_clear_practice_flags()`, `_rebuild_editor_preview()`.

4. **Bug 4 — Spawn recursion infinite loop**
   - TriggerController.gd: Added `_spawn_chain_depth` + `MAX_SPAWN_CHAIN_DEPTH = 8`.
   - Guard in `_apply_spawn()`, reset in `clear_all()`.

5. **Bug 5 — Broken atomic write in settings**
   - GameState.gd: Removed `DirAccess.remove_absolute(SETTINGS_PATH)` before rename.

6. **Bug 6 — Non-atomic save_custom_level**
   - GameState.gd: Converted to temp + rename atomic pattern.

7. **Bug 7 — MovingPlatform double-carry**
   - MovingPlatform.gd: Added per-frame arbitration using `set_meta("carry_platform_dist")` / `get_meta` + best-distance selection. Clears meta after.

8. **Bug 8 — Editor undo/redo desync on paste spam**
   - Main.gd: Store `index` at push time for "add".
   - Undo/redo now insert/remove at recorded index (with fallback).

9. **Bug 9 — SFX buffer clipping**
   - AudioManager.gd: Added mandatory hard linear fade-out on last ~4ms (176 samples) in `_build_stream`.

10. **Bug 10 — Parallax seed inconsistency on theme switch**
    - ParallaxBackdrop.gd: Store `_last_palette_seed`, pass it in `set_theme` and `rebuild`.

**All fixes follow handoff rules:**
- No public API changes without call-site updates.
- `set_deferred` not newly violated.
- Enums not reordered.
- `queue_free` + deferred where appropriate.
- Backward compatibility with v3 JSON preserved.

**Next:** Part 2 features + handoff update + validation.
