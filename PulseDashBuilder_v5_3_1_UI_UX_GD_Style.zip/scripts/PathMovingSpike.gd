extends Area2D
@export var path_points: PackedVector2Array = PackedVector2Array()
@export var speed: float = 120.0
var _path_index: int = 0
var _progress: float = 0.0
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	if path_points.size() < 2: return
	_progress += delta * speed
	var from := path_points[_path_index]
	var to := path_points[(_path_index + 1) % path_points.size()]
	var dist := from.distance_to(to)
	if dist <= 0.01:
		_path_index = (_path_index + 1) % path_points.size()
		return
	var t := clampf(_progress / dist, 0.0, 1.0)
	position = from.lerp(to, t)
	if t >= 1.0:
		_progress = 0.0
		_path_index = (_path_index + 1) % path_points.size()
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		(body as DashPlayer).die("path_spike")
