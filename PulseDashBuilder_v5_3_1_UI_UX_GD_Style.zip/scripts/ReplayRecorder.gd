## ReplayRecorder — Records and plays back player input frames for ghost/replay.
class_name ReplayRecorder
extends RefCounted

var _timestamps: PackedFloat32Array = PackedFloat32Array()
var _flags: PackedByteArray = PackedByteArray()
var _recording: bool = false
var _playback_active: bool = false
var _playback_index: int = 0
var _playback_speed: float = 1.0
var _playback_target: Node = null
var _start_time: float = 0.0

func start_recording() -> void:
	_recording = true
	_timestamps.clear()
	_flags.clear()
	_start_time = Time.get_ticks_msec() / 1000.0

func stop_recording() -> void:
	_recording = false

func record_frame(action_pressed: bool) -> void:
	if not _recording:
		return
	var t := (Time.get_ticks_msec() / 1000.0) - _start_time
	_timestamps.append(t)
	_flags.append(1 if action_pressed else 0)

func recording_duration() -> float:
	if _timestamps.is_empty():
		return 0.0
	return _timestamps[_timestamps.size() - 1]

func load_from_json(frames: Array) -> void:
	_timestamps.clear()
	_flags.clear()
	for frame in frames:
		if frame is Dictionary:
			_timestamps.append(float(frame.get("t", 0.0)))
			_flags.append(1 if frame.get("a", false) else 0)

func playback(target: Node, speed: float = 1.0) -> void:
	_playback_target = target
	_playback_speed = speed
	_playback_active = true
	_playback_index = 0

func stop_playback() -> void:
	_playback_active = false
	_playback_target = null

func tick_playback() -> bool:
	if not _playback_active or _timestamps.is_empty():
		return true
	if _playback_index >= _timestamps.size():
		return true
	# Advance frames based on elapsed time (simplified)
	_playback_index += 1
	if _playback_index >= _timestamps.size():
		return true
	return false

func make_ghost_data() -> Dictionary:
	return {
		"version": 2,
		"ts": Marshalls.raw_to_base64(_timestamps.to_byte_array()),
		"fl": Marshalls.raw_to_base64(_flags),
		"duration": recording_duration(),
	}
