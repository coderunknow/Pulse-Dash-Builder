extends Area2D
@export var pad_type: int = 0
@onready var outline: Polygon2D = $Outline
@onready var glow_halo: Polygon2D = $GlowHalo
var _glow_phase: float = 0.0
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	_glow_phase += delta * 3.0
	if glow_halo:
		glow_halo.modulate.a = 0.06 + sin(_glow_phase) * 0.04
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		var p: DashPlayer = body as DashPlayer
		var force := 900.0 if pad_type == 0 else 1200.0
		p.velocity.y = -force
