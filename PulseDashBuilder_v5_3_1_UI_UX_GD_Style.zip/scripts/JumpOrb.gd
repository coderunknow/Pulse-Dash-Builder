class_name JumpOrb
extends Area2D

## A tap-activated orb. v5.2 visual overhaul: neon-outlined style with
## dark core, bright ring, glow halo, and core highlight.
## It registers while a player overlaps it; the player's next action press
## triggers the assigned impulse or dash.

@export var orb_type: int = GDGameTypes.OrbType.YELLOW:
	set(value):
		orb_type = value
		if is_node_ready():
			_refresh_visual()

# `hidden` is already a native Area2D member in Godot 4, so this deliberately
# uses a distinct exported name. JSON level data still uses the user-friendly
# key "hidden" and Main maps that key to this property.
@export var is_hidden_orb: bool = false:
	set(value):
		is_hidden_orb = value
		if is_node_ready():
			_refresh_visual()

@onready var visual: Polygon2D = $Visual
@onready var ring: Polygon2D = $Ring
@onready var core: Polygon2D = $Core
@onready var glow_halo: Polygon2D = $GlowHalo
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

var _consumed: bool = false
var _animation_time: float = 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitoring = true
	_refresh_visual()
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _process(delta: float) -> void:
	if _consumed:
		return
	_animation_time += delta
	var pulse: float = 1.0 + sin(_animation_time * 5.0) * 0.10
	visual.scale = Vector2.ONE * pulse
	ring.scale = Vector2.ONE * (1.0 + sin(_animation_time * 5.0 + PI) * 0.08)
	ring.rotation += delta * 1.6
	core.scale = Vector2.ONE * (1.0 + sin(_animation_time * 5.0 + 0.5) * 0.06)
	# Glow halo subtle pulse
	var halo_pulse: float = 1.0 + sin(_animation_time * 3.0) * 0.15
	glow_halo.scale = Vector2.ONE * halo_pulse


func activate(player: DashPlayer) -> void:
	if _consumed:
		return
	_consumed = true
	player.apply_orb(orb_type)
	# Deferred mutation also keeps this safe if an orb is activated by a future
	# trigger callback during Area2D's in/out signal phase.
	set_deferred("monitoring", false)
	collision_shape.set_deferred("disabled", true)
	visual.visible = false
	ring.visible = false
	core.visible = false
	glow_halo.visible = false


func _refresh_visual() -> void:
	var color: Color = _orb_color()
	# Dark interior
	var dark_interior: Color = Color(color.r * 0.12, color.g * 0.12, color.b * 0.12, 1.0)
	if is_hidden_orb:
		dark_interior.a = 0.20
	visual.color = dark_interior
	# Bright ring border
	var ring_color: Color = color.lightened(0.20)
	if is_hidden_orb:
		ring_color.a = 0.20
	ring.color = ring_color
	# Core highlight
	var core_color: Color = color.lightened(0.55)
	core.color = core_color
	# Glow halo
	var halo_color: Color = Color(color.r, color.g, color.b, 0.12)
	if is_hidden_orb:
		halo_color.a = 0.04
	glow_halo.color = halo_color


func _on_body_entered(body: Node2D) -> void:
	if not _consumed and body is DashPlayer:
		var player: DashPlayer = body as DashPlayer
		player.register_orb(self)


func _on_body_exited(body: Node2D) -> void:
	if body is DashPlayer:
		var player: DashPlayer = body as DashPlayer
		player.unregister_orb(self)


func _orb_color() -> Color:
	match orb_type:
		GDGameTypes.OrbType.YELLOW:
			return Color("ffe35c")
		GDGameTypes.OrbType.PINK:
			return Color("ff83d0")
		GDGameTypes.OrbType.RED:
			return Color("ff6363")
		GDGameTypes.OrbType.BLUE:
			return Color("5bb8ff")
		GDGameTypes.OrbType.PURPLE:
			return Color("b17bff")
		GDGameTypes.OrbType.BLACK:
			return Color("2d3554")
		GDGameTypes.OrbType.DASH:
			return Color("ff9b4f")
		_:
			return Color.WHITE
