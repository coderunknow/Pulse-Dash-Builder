## v5 UPGRADE: Added hit-stop (frame freeze) system via apply_hit_stop(). Added
## get_trail_color() for dynamic skin-driven trail colors. Pre-allocated reusable
## Vector2 members to avoid per-frame allocations in hot paths. Verified coyote
## time + jump buffer are frame-accurate. AfterImagePool wiring confirmed via
## Main.gd (no changes needed in Player.gd itself — the pool is node-based).
## v5 shader wiring: apply_chromatic_aberration() spawns a fullscreen ColorRect
## on the scene root (NOT on the Player, which is hidden on death) with the
## chromatic_aberration.gdshader, then Tweens `amount` back to 0 over `duration`.
## Called from die() for impact emphasis. One-shot Tween — not in a hot loop.

class_name DashPlayer
extends CharacterBody2D

## One reusable controller for every Geometry Dash-style form. World collision
## remains on layer 1 and the player always lives on layer 2. The visual rotates
## independently from the collision shape to keep high-speed contacts stable.
##
## All eight modes share a single physics tick; mode-specific behaviour is
## selected via match statements in _update_mode_motion() and _on_action_pressed().

signal died(player: DashPlayer, reason: String)
signal portal_requested(player: DashPlayer, portal_type: int)
signal jumped(player: DashPlayer, world_position: Vector2)
signal mode_changed(player: DashPlayer, new_mode: int)
signal landed(player: DashPlayer, world_position: Vector2)

const WORLD_LAYER: int = 1
const PLAYER_LAYER: int = 2
const QUARTER_TURN: float = PI * 0.5
const TRAIL_SAMPLE_INTERVAL: float = 0.025
const TRAIL_MAX_POINTS: int = 12
const OPTIONAL_USER_CUBE_SKIN_PATH: String = "res://assets/runtime/cube_user_skin.png"
const OPTIONAL_CUBE_SKIN_PATH: String = "res://assets/runtime/cube_skin.png"

@export_category("Core movement")
@export var base_forward_speed: float = 450.0
@export var gravity: float = 1_800.0
@export var terminal_fall_speed: float = 1_500.0
@export var floor_snap_distance: float = 8.0

@export_category("Action tuning")
@export var cube_jump_speed: float = 680.0
@export var ufo_flap_speed: float = 560.0
@export var ship_thrust: float = 2_700.0
@export var wave_speed: float = 520.0
@export var robot_hold_acceleration: float = 1_300.0
@export var robot_hold_duration: float = 0.16

@export_category("Input forgiveness")
@export_range(0.01, 0.50, 0.01) var jump_buffer_duration: float = 0.14
@export_range(0.0, 0.25, 0.01) var coyote_duration: float = 0.08

@onready var collision_shape: CollisionShape2D = $CollisionShape2D
@onready var trail: Line2D = $Trail
@onready var visual: Polygon2D = $Visual
@onready var neon_border: Polygon2D = $NeonBorder
@onready var skin: Sprite2D = $Visual/Skin
@onready var core: Polygon2D = $Visual/Core
@onready var top_highlight: Polygon2D = $Visual/TopHighlight
@onready var bottom_shadow: Polygon2D = $Visual/BottomShadow
@onready var eye: Polygon2D = $Visual/Eye

var game_mode: int = GDGameTypes.GameMode.CUBE
var gravity_sign: float = 1.0
var speed_multiplier: float = 1.0
var is_mini: bool = false
var player_slot: int = 0
var _level_id: String = ""

var _was_on_floor: bool = false
var _hit_flash_remaining: float = 0.0
var _audio: Node = null
var _stats: Node = null

var _jump_buffer_remaining: float = 0.0
## Coyote time: frame-accurate grace period for jumping after leaving a ledge.
## Decrements each physics frame; a buffered press can still trigger a jump
## while this is > 0 even if the player is no longer on the floor.
var _coyote_remaining: float = 0.0
## Jump buffer: frame-accurate input queue. When the player presses action,
## this is set to jump_buffer_duration. It decrements each physics frame and
## triggers a jump on the first frame where the player is grounded (or in coyote).
var _robot_hold_remaining: float = 0.0
var _dash_remaining: float = 0.0
var _is_dead: bool = false
var _is_frozen: bool = false
var _active_orb: Node = null
var _has_optional_cube_skin: bool = false
var _mode_transition_grace_remaining: float = 0.0
var _is_externally_locked: bool = false
var _trail_history: Array[Vector2] = []
var _trail_sample_remaining: float = 0.0
var _trail_dirty: bool = false

## v5: Hit-stop (frame freeze) system. When > 0, _physics_process skips all
## motion, giving juicy impact feedback on death, orb pickup, etc.
var _hit_stop_remaining: float = 0.0

## v5: Reusable Vector2 to avoid per-frame allocation in spider raycast.
var _spider_direction: Vector2 = Vector2(0.0, 1.0)

## v5: Cached trail color for get_trail_color() — updated in _update_mode_visual().
var _cached_trail_color: Color = Color("52d8ff")

## v5: Pre-allocated PackedVector2Array for trail to avoid per-frame heap alloc.
var _trail_points_buf: PackedVector2Array = PackedVector2Array()

## v5: Cached ShaderMaterial for the death chromatic-aberration rect.
## Lazily created by apply_chromatic_aberration().
var _aberration_mat: ShaderMaterial = null


func _ready() -> void:
	collision_layer = PLAYER_LAYER
	collision_mask = WORLD_LAYER
	floor_snap_length = floor_snap_distance
	add_to_group(&"player")
	_load_optional_cube_skin()
	_trail_history = [global_position]
	_update_up_direction()
	_update_mode_visual()
	_audio = get_node_or_null("/root/AudioManager")
	_stats = get_node_or_null("/root/StatsTracker")
	set_process(true)


func _load_optional_cube_skin() -> void:
	var selected_path: String = ""
	var selected_scale: float = 0.09
	if ResourceLoader.exists(OPTIONAL_USER_CUBE_SKIN_PATH):
		selected_path = OPTIONAL_USER_CUBE_SKIN_PATH
		selected_scale = 0.25
	elif ResourceLoader.exists(OPTIONAL_CUBE_SKIN_PATH):
		selected_path = OPTIONAL_CUBE_SKIN_PATH
	if selected_path.is_empty():
		return
	var texture: Texture2D = load(selected_path) as Texture2D
	if texture == null:
		return
	skin.texture = texture
	skin.scale = Vector2.ONE * selected_scale
	_has_optional_cube_skin = true


func configure(slot: int, initial_state: Dictionary = {}) -> void:
	player_slot = slot
	if not initial_state.is_empty():
		restore_state(initial_state)
	else:
		_update_mode_visual()


func set_level_id(level_id: String) -> void:
	_level_id = level_id


func _process(delta: float) -> void:
	if _hit_flash_remaining > 0.0:
		_hit_flash_remaining = maxf(_hit_flash_remaining - delta, 0.0)
		if _hit_flash_remaining <= 0.0:
			visual.modulate = Color.WHITE
		else:
			var t: float = _hit_flash_remaining / 0.16
			visual.modulate = Color.WHITE.lerp(Color("ff5f6d"), t)


func _play_sfx(cue: int) -> void:
	if _audio != null and _audio.has_method("play_sfx"):
		_audio.play_sfx(cue)


func _input(event: InputEvent) -> void:
	if _is_dead or _is_frozen or _is_externally_locked:
		return
	if _is_action_press_event(event):
		_on_action_pressed()


func _physics_process(delta: float) -> void:
	if _is_dead or _is_frozen or _is_externally_locked:
		return

	# v5: Hit-stop early return — freezes all motion for juicy impact feedback.
	if _hit_stop_remaining > 0.0:
		_hit_stop_remaining = maxf(_hit_stop_remaining - delta, 0.0)
		return

	_dash_remaining = maxf(_dash_remaining - delta, 0.0)
	_mode_transition_grace_remaining = maxf(_mode_transition_grace_remaining - delta, 0.0)
	_update_timers(delta)
	_update_mode_motion(delta)
	move_and_slide()
	_handle_post_move_contacts(delta)
	_update_trail(delta)


## v5: Apply a hit-stop (frame freeze) effect. The player's _physics_process
## will early-return (skipping all motion) for the given duration in seconds.
## Typically 0.03-0.08s for subtle impact, 0.10-0.15s for heavy hits.
func apply_hit_stop(duration: float) -> void:
	_hit_stop_remaining = maxf(duration, 0.0)


## v5: Spawn a fullscreen ColorRect with chromatic_aberration.gdshader on the
## scene root (NOT on the Player — it gets hidden on death). Tweens `amount`
## from the passed value down to 0.0 over `duration`, then frees the rect.
## Safe to call multiple times — reuses an existing __AberrationRect if present.
## The Tween is bound to the rect itself (not the Player) so Player respawn /
## free cannot leave a dangling Callable.
func apply_chromatic_aberration(amount: float, duration: float = 0.3) -> void:
	var scene_root: Node = get_tree().current_scene
	if scene_root == null:
		return
	var rect: ColorRect = null
	var existing: Node = scene_root.get_node_or_null("__AberrationRect")
	if existing is ColorRect:
		rect = existing as ColorRect
	else:
		rect = ColorRect.new()
		rect.name = "__AberrationRect"
		rect.anchors_preset = Control.PRESET_FULL_RECT
		rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		rect.z_index = 100
		scene_root.add_child(rect)
	if rect.material is ShaderMaterial:
		_aberration_mat = rect.material as ShaderMaterial
	else:
		_aberration_mat = ShaderMaterial.new()
		_aberration_mat.shader = preload("res://assets/shaders/chromatic_aberration.gdshader")
		rect.material = _aberration_mat
	var clamped_amount: float = clampf(amount, 0.0, 1.0)
	_aberration_mat.set_shader_parameter("amount", clamped_amount)
	# Kill any in-flight tween on the rect so rapid re-deaths don't stack.
	if rect.has_meta(&"__ca_tween"):
		var prev_tween: Variant = rect.get_meta(&"__ca_tween")
		if prev_tween is Tween:
			(prev_tween as Tween).kill()
	# Bind the tween to the rect itself: when the rect is freed (scene change,
	# explicit clear, etc.) the tween is automatically killed — no Player-side
	# Callable can outlive the rect.
	var tween: Tween = rect.create_tween()
	rect.set_meta(&"__ca_tween", tween)
	tween.tween_property(rect, "material:shader_parameter/amount", 0.0, maxf(duration, 0.01))
	tween.tween_callback(rect.queue_free)


## v5: Get the current trail color (driven by game mode and skin).
## SkinManager.apply_skin_to_player() can override this via set_trail_color().
func get_trail_color() -> Color:
	return _cached_trail_color


## v5: Set the trail color externally (e.g. from SkinManager).
func set_trail_color(color: Color) -> void:
	_cached_trail_color = color
	var trail_col: Color = color
	trail_col.a = 0.62
	trail.default_color = trail_col


func die(reason: String) -> void:
	if _is_dead or _is_frozen:
		return
	_is_dead = true
	velocity = Vector2.ZERO
	visible = false
	set_physics_process(false)
	set_process_input(false)
	_play_sfx(GDGameTypes.SfxCue.DEATH)
	_hit_stop_remaining = 0.06
	apply_chromatic_aberration(0.8, 0.32)
	if _stats != null and _stats.has_method("record_death"):
		_stats.record_death()
	died.emit(self, reason)


func freeze_for_completion() -> void:
	_is_frozen = true
	velocity = Vector2.ZERO
	set_physics_process(false)
	set_process_input(false)
	visual.color = Color("ffe27a")


func set_external_lock(locked: bool) -> void:
	_is_externally_locked = locked
	if locked:
		velocity = Vector2.ZERO


func restore_state(state: Dictionary) -> void:
	global_position = _vector_from_data(state.get("position", [160.0, 450.0]), global_position)
	game_mode = int(state.get("game_mode", GDGameTypes.GameMode.CUBE))
	gravity_sign = float(state.get("gravity_sign", 1.0))
	speed_multiplier = maxf(float(state.get("speed_multiplier", 1.0)), 0.25)
	is_mini = bool(state.get("is_mini", false))
	velocity = Vector2.ZERO
	_jump_buffer_remaining = 0.0
	_coyote_remaining = 0.0
	_robot_hold_remaining = 0.0
	_dash_remaining = 0.0
	_hit_stop_remaining = 0.0
	_is_dead = false
	_is_frozen = false
	_is_externally_locked = false
	_was_on_floor = false
	_hit_flash_remaining = 0.0
	visual.modulate = Color.WHITE
	_trail_history = [global_position]
	_trail_sample_remaining = 0.0
	_trail_dirty = true
	visible = true
	set_physics_process(true)
	set_process_input(true)
	_apply_size()
	_update_up_direction()
	_update_mode_visual()


func make_checkpoint_state() -> Dictionary:
	return {
		"position": [global_position.x, global_position.y],
		"game_mode": game_mode,
		"gravity_sign": gravity_sign,
		"speed_multiplier": speed_multiplier,
		"is_mini": is_mini,
	}


func request_portal(portal_type: int) -> void:
	portal_requested.emit(self, portal_type)


func apply_portal(portal_type: int) -> void:
	match portal_type:
		GDGameTypes.PortalType.GRAVITY_NORMAL:
			_set_gravity_sign(1.0)
		GDGameTypes.PortalType.GRAVITY_INVERT:
			_set_gravity_sign(-1.0)
		GDGameTypes.PortalType.SIZE_MINI:
			is_mini = true
			_apply_size()
		GDGameTypes.PortalType.SIZE_NORMAL:
			is_mini = false
			_apply_size()
		GDGameTypes.PortalType.SPEED_HALF:
			speed_multiplier = 0.5
		GDGameTypes.PortalType.SPEED_NORMAL:
			speed_multiplier = 1.0
		GDGameTypes.PortalType.SPEED_DOUBLE:
			speed_multiplier = 2.0
		GDGameTypes.PortalType.SPEED_TRIPLE:
			speed_multiplier = 3.0
		GDGameTypes.PortalType.SPEED_QUAD:
			speed_multiplier = 4.0
		GDGameTypes.PortalType.MODE_CUBE:
			set_game_mode(GDGameTypes.GameMode.CUBE)
		GDGameTypes.PortalType.MODE_SHIP:
			set_game_mode(GDGameTypes.GameMode.SHIP)
		GDGameTypes.PortalType.MODE_BALL:
			set_game_mode(GDGameTypes.GameMode.BALL)
		GDGameTypes.PortalType.MODE_UFO:
			set_game_mode(GDGameTypes.GameMode.UFO)
		GDGameTypes.PortalType.MODE_WAVE:
			set_game_mode(GDGameTypes.GameMode.WAVE)
		GDGameTypes.PortalType.MODE_ROBOT:
			set_game_mode(GDGameTypes.GameMode.ROBOT)
		GDGameTypes.PortalType.MODE_SPIDER:
			set_game_mode(GDGameTypes.GameMode.SPIDER)
		GDGameTypes.PortalType.MODE_SWING:
			set_game_mode(GDGameTypes.GameMode.SWING)


func set_game_mode(new_mode: int) -> void:
	game_mode = clampi(new_mode, GDGameTypes.GameMode.CUBE, GDGameTypes.GameMode.SWING)
	_active_orb = null
	_robot_hold_remaining = 0.0
	if game_mode in [GDGameTypes.GameMode.SHIP, GDGameTypes.GameMode.WAVE]:
		_mode_transition_grace_remaining = 0.18
		_jump_against_gravity(420.0)
	_update_mode_visual()
	_play_sfx(GDGameTypes.SfxCue.PORTAL)
	mode_changed.emit(self, game_mode)


func register_orb(orb: Node) -> void:
	if not _is_dead and not _is_frozen:
		_active_orb = orb


func unregister_orb(orb: Node) -> void:
	if _active_orb == orb:
		_active_orb = null


func apply_pad(pad_type: int) -> void:
	_play_sfx(GDGameTypes.SfxCue.PAD)
	match pad_type:
		GDGameTypes.PadType.YELLOW:
			_jump_against_gravity(780.0)
		GDGameTypes.PadType.PINK:
			_jump_against_gravity(600.0)
		GDGameTypes.PadType.RED:
			_jump_against_gravity(930.0)
		GDGameTypes.PadType.BLUE:
			_toggle_gravity(560.0)


func apply_pad_bounce(strength: float) -> void:
	velocity.y = -gravity_sign * strength
	jumped.emit(self, global_position)


func apply_orb(orb_type: int) -> void:
	_play_sfx(GDGameTypes.SfxCue.ORB)
	apply_hit_stop(0.04)
	match orb_type:
		GDGameTypes.OrbType.YELLOW:
			_jump_against_gravity(700.0)
		GDGameTypes.OrbType.PINK:
			_jump_against_gravity(535.0)
		GDGameTypes.OrbType.RED:
			_jump_against_gravity(860.0)
		GDGameTypes.OrbType.BLUE:
			_toggle_gravity(520.0)
		GDGameTypes.OrbType.PURPLE:
			_toggle_gravity(700.0)
		GDGameTypes.OrbType.BLACK:
			_toggle_gravity(350.0)
		GDGameTypes.OrbType.DASH:
			_dash_remaining = 0.38
			velocity.x = maxf(velocity.x, _forward_speed() * 3.2)


func can_break_blocks() -> bool:
	return _dash_remaining > 0.0


func _update_timers(delta: float) -> void:
	if _is_action_held() and game_mode in [GDGameTypes.GameMode.CUBE, GDGameTypes.GameMode.ROBOT]:
		_jump_buffer_remaining = jump_buffer_duration
	else:
		_jump_buffer_remaining = maxf(_jump_buffer_remaining - delta, 0.0)

	var grounded: bool = is_on_floor() and velocity.y * gravity_sign >= 0.0
	if grounded:
		_coyote_remaining = coyote_duration
	else:
		_coyote_remaining = maxf(_coyote_remaining - delta, 0.0)
	_robot_hold_remaining = maxf(_robot_hold_remaining - delta, 0.0)


func _update_mode_motion(delta: float) -> void:
	var grounded: bool = is_on_floor() and velocity.y * gravity_sign >= 0.0
	var can_jump: bool = grounded or _coyote_remaining > 0.0

	match game_mode:
		GDGameTypes.GameMode.CUBE:
			if _jump_buffer_remaining > 0.0 and can_jump:
				_jump_against_gravity(cube_jump_speed)
				_jump_buffer_remaining = 0.0
				_coyote_remaining = 0.0
			_apply_gravity(delta)
		GDGameTypes.GameMode.ROBOT:
			if _jump_buffer_remaining > 0.0 and can_jump:
				_jump_against_gravity(cube_jump_speed)
				_jump_buffer_remaining = 0.0
				_coyote_remaining = 0.0
			if _is_action_held() and _robot_hold_remaining > 0.0:
				velocity.y -= gravity_sign * robot_hold_acceleration * delta
			_apply_gravity(delta)
		GDGameTypes.GameMode.SHIP:
			if _is_action_held():
				velocity.y -= gravity_sign * ship_thrust * delta
			_apply_gravity(delta)
		GDGameTypes.GameMode.UFO:
			_apply_gravity(delta)
		GDGameTypes.GameMode.BALL, GDGameTypes.GameMode.SWING, GDGameTypes.GameMode.SPIDER:
			_apply_gravity(delta)
		GDGameTypes.GameMode.WAVE:
			var wave_dir: float = -gravity_sign if _is_action_held() else gravity_sign
			velocity.y = wave_dir * wave_speed

	velocity.x = _forward_speed()


func _handle_post_move_contacts(delta: float) -> void:
	var broke_a_block: bool = false
	for collision_index: int in range(get_slide_collision_count()):
		var collision: KinematicCollision2D = get_slide_collision(collision_index)
		var collider: Object = collision.get_collider()
		if collider is BreakableBlock and can_break_blocks():
			(collider as BreakableBlock).break_block()
			broke_a_block = true

	if is_on_wall() and not is_on_floor() and not is_on_ceiling() and not broke_a_block:
		die("hit a solid block")
		return

	if _mode_transition_grace_remaining <= 0.0:
		if game_mode == GDGameTypes.GameMode.WAVE and (is_on_floor() or is_on_ceiling()):
			die("wave touched a surface")
			return
		if game_mode == GDGameTypes.GameMode.SHIP and (is_on_floor() or is_on_ceiling()):
			die("ship touched a surface")
			return

	var is_grounded: bool = is_on_floor()
	if is_grounded and not _was_on_floor:
		landed.emit(self, global_position)
	_was_on_floor = is_grounded

	if is_on_floor():
		_snap_visual_to_quarter_turn(delta)
		if game_mode == GDGameTypes.GameMode.CUBE and _jump_buffer_remaining > 0.0:
			_jump_against_gravity(cube_jump_speed)
			_jump_buffer_remaining = 0.0
	elif game_mode in [GDGameTypes.GameMode.CUBE, GDGameTypes.GameMode.ROBOT, GDGameTypes.GameMode.BALL, GDGameTypes.GameMode.SPIDER, GDGameTypes.GameMode.SWING]:
		visual.rotation = wrapf(visual.rotation + 8.0 * delta, -PI, PI)
	elif game_mode == GDGameTypes.GameMode.SHIP:
		visual.rotation = lerp(visual.rotation, clampf(velocity.y / 1_100.0, -0.7, 0.7), minf(delta * 10.0, 1.0))


func _on_action_pressed() -> void:
	if _active_orb != null and is_instance_valid(_active_orb) and _active_orb.has_method("activate"):
		_active_orb.call("activate", self)
		_active_orb = null
		return

	match game_mode:
		GDGameTypes.GameMode.CUBE:
			_jump_buffer_remaining = jump_buffer_duration
		GDGameTypes.GameMode.ROBOT:
			_jump_buffer_remaining = jump_buffer_duration
			_robot_hold_remaining = robot_hold_duration
		GDGameTypes.GameMode.UFO:
			_jump_against_gravity(ufo_flap_speed)
		GDGameTypes.GameMode.BALL, GDGameTypes.GameMode.SWING:
			if is_on_floor() or is_on_ceiling():
				_toggle_gravity(430.0)
		GDGameTypes.GameMode.SPIDER:
			if is_on_floor() or is_on_ceiling():
				_spider_flip()


func _apply_gravity(delta: float) -> void:
	velocity.y += gravity * gravity_sign * delta
	velocity.y = clampf(velocity.y, -terminal_fall_speed, terminal_fall_speed)


func _jump_against_gravity(strength: float) -> void:
	velocity.y = -gravity_sign * strength
	jumped.emit(self, global_position)
	_play_sfx(GDGameTypes.SfxCue.JUMP)
	if _stats != null and _stats.has_method("record_jump"):
		_stats.record_jump()


func _toggle_gravity(launch_strength: float) -> void:
	gravity_sign *= -1.0
	_update_up_direction()
	_jump_against_gravity(launch_strength)


func _set_gravity_sign(new_sign: float) -> void:
	gravity_sign = 1.0 if new_sign >= 0.0 else -1.0
	_update_up_direction()


func _spider_flip() -> void:
	gravity_sign *= -1.0
	_update_up_direction()
	_spider_direction.x = 0.0
	_spider_direction.y = gravity_sign
	var query: PhysicsRayQueryParameters2D = PhysicsRayQueryParameters2D.create(
		global_position,
		global_position + _spider_direction * 720.0,
		WORLD_LAYER,
	)
	query.exclude = [get_rid()]
	var hit: Dictionary = get_world_2d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		var collision_position: Vector2 = hit.get("position", global_position)
		global_position = collision_position - _spider_direction * _collision_half_height()
	velocity = Vector2.ZERO


func _apply_size() -> void:
	var size_scale: float = 0.65 if is_mini else 1.0
	collision_shape.scale = Vector2.ONE * size_scale
	visual.scale = Vector2.ONE * size_scale


func _update_up_direction() -> void:
	up_direction = Vector2(0.0, -gravity_sign)


func _update_mode_visual() -> void:
	var mode_color: Color = Color("52d8ff")
	var shape: PackedVector2Array = PackedVector2Array([
		Vector2(-19.0, -19.0), Vector2(19.0, -19.0),
		Vector2(19.0, 19.0), Vector2(-19.0, 19.0),
	])
	var border_shape: PackedVector2Array = PackedVector2Array([
		Vector2(-21.0, -21.0), Vector2(21.0, -21.0),
		Vector2(21.0, 21.0), Vector2(-21.0, 21.0),
		Vector2(-21.0, -21.0), Vector2(-19.0, -19.0),
		Vector2(-19.0, 19.0), Vector2(19.0, 19.0),
		Vector2(19.0, -19.0),
	])
	match game_mode:
		GDGameTypes.GameMode.SHIP:
			mode_color = Color("ffb65e")
			shape = PackedVector2Array([Vector2(-22.0, 14.0), Vector2(20.0, 0.0), Vector2(-22.0, -14.0)])
			border_shape = PackedVector2Array([Vector2(-24.0, 16.0), Vector2(22.0, 2.0), Vector2(-24.0, -16.0), Vector2(-22.0, -14.0), Vector2(20.0, 0.0), Vector2(-22.0, 14.0)])
		GDGameTypes.GameMode.BALL:
			mode_color = Color("d778ff")
			shape = _octagon(20.0)
			border_shape = _border_octagon(20.0, 22.0)
		GDGameTypes.GameMode.UFO:
			mode_color = Color("7cf5a4")
			shape = PackedVector2Array([Vector2(-20.0, 10.0), Vector2(-12.0, -12.0), Vector2(12.0, -12.0), Vector2(20.0, 10.0)])
			border_shape = PackedVector2Array([Vector2(-22.0, 12.0), Vector2(-14.0, -14.0), Vector2(14.0, -14.0), Vector2(22.0, 12.0), Vector2(20.0, 10.0), Vector2(-12.0, -12.0), Vector2(12.0, -12.0), Vector2(-20.0, 10.0)])
		GDGameTypes.GameMode.WAVE:
			mode_color = Color("f4f06b")
			shape = PackedVector2Array([Vector2(-20.0, 15.0), Vector2(0.0, -16.0), Vector2(20.0, 15.0), Vector2(0.0, 6.0)])
			border_shape = PackedVector2Array([Vector2(-22.0, 17.0), Vector2(0.0, -18.0), Vector2(22.0, 17.0), Vector2(0.0, 8.0), Vector2(20.0, 15.0), Vector2(0.0, -16.0), Vector2(-20.0, 15.0), Vector2(0.0, 6.0)])
		GDGameTypes.GameMode.ROBOT:
			mode_color = Color("ff7c91")
			shape = PackedVector2Array([Vector2(-17.0, -18.0), Vector2(17.0, -18.0), Vector2(20.0, 18.0), Vector2(-20.0, 18.0)])
			border_shape = PackedVector2Array([Vector2(-19.0, -20.0), Vector2(19.0, -20.0), Vector2(22.0, 20.0), Vector2(-22.0, 20.0), Vector2(-17.0, -18.0), Vector2(17.0, -18.0), Vector2(20.0, 18.0), Vector2(-20.0, 18.0)])
		GDGameTypes.GameMode.SPIDER:
			mode_color = Color("9c7cff")
			shape = PackedVector2Array([Vector2(-20.0, 0.0), Vector2(-8.0, -18.0), Vector2(8.0, -18.0), Vector2(20.0, 0.0), Vector2(8.0, 18.0), Vector2(-8.0, 18.0)])
			border_shape = PackedVector2Array([Vector2(-22.0, 2.0), Vector2(-10.0, -20.0), Vector2(10.0, -20.0), Vector2(22.0, 2.0), Vector2(10.0, 20.0), Vector2(-10.0, 20.0), Vector2(-8.0, -18.0), Vector2(8.0, -18.0), Vector2(20.0, 0.0), Vector2(8.0, 18.0), Vector2(-8.0, 18.0), Vector2(-20.0, 0.0)])
		GDGameTypes.GameMode.SWING:
			mode_color = Color("7ce8ff")
			shape = _octagon(18.0)
			border_shape = _border_octagon(18.0, 20.0)
	# v5.2: Neon-outlined style — dark interior, bright border.
	var use_optional_cube_skin: bool = game_mode == GDGameTypes.GameMode.CUBE and _has_optional_cube_skin
	skin.visible = use_optional_cube_skin
	visual.polygon = PackedVector2Array() if use_optional_cube_skin else shape
	# Interior: very dark (near black) with slight mode_color tint
	var interior_color: Color = Color(mode_color.r * 0.10, mode_color.g * 0.10, mode_color.b * 0.10, 1.0)
	visual.color = interior_color if player_slot == 0 else Color(mode_color.r * 0.12, mode_color.g * 0.12, mode_color.b * 0.12, 1.0)
	# Neon border: bright mode-colored outline
	neon_border.visible = not use_optional_cube_skin
	neon_border.polygon = PackedVector2Array() if use_optional_cube_skin else border_shape
	neon_border.color = mode_color if player_slot == 0 else mode_color.lightened(0.22)
	core.visible = not use_optional_cube_skin and game_mode in [GDGameTypes.GameMode.CUBE, GDGameTypes.GameMode.ROBOT, GDGameTypes.GameMode.UFO]
	top_highlight.visible = core.visible
	bottom_shadow.visible = core.visible
	eye.visible = core.visible
	# Trail color
	var trail_color: Color = mode_color if not use_optional_cube_skin else Color("ffd15f")
	trail_color.a = 0.62
	_cached_trail_color = trail_color
	trail.default_color = trail_color


func _update_trail(delta: float) -> void:
	_trail_sample_remaining -= delta
	if _trail_sample_remaining <= 0.0:
		_trail_sample_remaining = TRAIL_SAMPLE_INTERVAL
		_trail_history.push_front(global_position)
		if _trail_history.size() > TRAIL_MAX_POINTS:
			_trail_history.pop_back()
		_trail_dirty = true

	if not _trail_dirty:
		return
	_trail_dirty = false
	var history_size: int = _trail_history.size()
	if _trail_points_buf.size() != history_size:
		_trail_points_buf.resize(history_size)
	for i: int in range(history_size):
		_trail_points_buf[i] = to_local(_trail_history[i])
	trail.points = _trail_points_buf


func _snap_visual_to_quarter_turn(delta: float) -> void:
	var target_rotation: float = snappedf(visual.rotation, QUARTER_TURN)
	visual.rotation = rotate_toward(visual.rotation, target_rotation, 22.0 * delta)


func _forward_speed() -> float:
	var dash_multiplier: float = 3.2 if _dash_remaining > 0.0 else 1.0
	return base_forward_speed * speed_multiplier * dash_multiplier


func _collision_half_height() -> float:
	return 21.0 * (0.65 if is_mini else 1.0)


func _is_action_held() -> bool:
	return Input.is_action_pressed(&"ui_accept") \
		or Input.is_physical_key_pressed(KEY_SPACE) \
		or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)


func _is_action_press_event(event: InputEvent) -> bool:
	if event.is_action_pressed(&"ui_accept"):
		return true
	if event is InputEventKey:
		var key_event: InputEventKey = event as InputEventKey
		return key_event.pressed and not key_event.echo and key_event.physical_keycode == KEY_SPACE
	if event is InputEventMouseButton:
		var mouse_event: InputEventMouseButton = event as InputEventMouseButton
		return mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_LEFT
	return false


func _vector_from_data(data: Variant, fallback: Vector2) -> Vector2:
	if data is Array and data.size() >= 2:
		return Vector2(float(data[0]), float(data[1]))
	return fallback


func _octagon(radius: float) -> PackedVector2Array:
	var points: PackedVector2Array = PackedVector2Array()
	for point_index: int in range(8):
		var angle: float = -PI * 0.5 + TAU * float(point_index) / 8.0
		points.append(Vector2(cos(angle), sin(angle)) * radius)
	return points


## v5.2: Border octagon — creates a thick border ring between inner and outer radii.
func _border_octagon(inner_radius: float, outer_radius: float) -> PackedVector2Array:
	var points: PackedVector2Array = PackedVector2Array()
	# Outer ring forward
	for point_index: int in range(8):
		var angle: float = -PI * 0.5 + TAU * float(point_index) / 8.0
		points.append(Vector2(cos(angle), sin(angle)) * outer_radius)
	# Last outer vertex connects to first inner vertex
	var first_inner_angle: float = -PI * 0.5
	points.append(Vector2(cos(first_inner_angle), sin(first_inner_angle)) * inner_radius)
	# Inner ring backward
	for point_index: int in range(7, -1, -1):
		var angle: float = -PI * 0.5 + TAU * float(point_index) / 8.0
		points.append(Vector2(cos(angle), sin(angle)) * inner_radius)
	return points
