## ParallaxBackdrop — 4-layer procedural parallax background.
## Layers: vertical stripes, grid lines, glow orbs, mountain silhouettes.
class_name ParallaxBackdrop
extends Node2D

var _level_length: float = 4800.0
var _seed: int = 0
var _theme: int = 0
var _layers: Array[Node2D] = []

func _ready() -> void:
	for i in 4:
		var layer := Node2D.new()
		layer.z_index = -5 + i
		add_child(layer)
		_layers.append(layer)

func rebuild(level_length: float, seed_val: int) -> void:
	_level_length = level_length
	_seed = seed_val
	queue_redraw()
	for layer in _layers:
		layer.queue_redraw()

func set_theme(theme: int, _animate: bool = false) -> void:
	_theme = theme
	queue_redraw()

func _draw() -> void:
	var palette := GDGameTypes.background_theme_palette(_theme)
	var base_color: Color = palette.get("base", Color("0a1228"))
	var accent_color: Color = palette.get("accent", Color("52d8ff"))
	var fog_color: Color = palette.get("fog", Color(0.04, 0.07, 0.16))
	var rng := RandomNumberGenerator.new()
	rng.seed = _seed

	# Layer 0: Vertical stripes
	var stripe_spacing := 120.0
	var stripe_count := int(_level_length / stripe_spacing) + 2
	for i in stripe_count:
		var x := i * stripe_spacing
		var alpha := 0.06 + rng.randf() * 0.04
		draw_line(Vector2(x, 0), Vector2(x, 648), Color(accent_color.r, accent_color.g, accent_color.b, alpha), 1.0)

	# Layer 1: Grid lines (horizontal)
	var grid_spacing := 80.0
	var grid_count := int(648.0 / grid_spacing) + 1
	for i in grid_count:
		var y := i * grid_spacing
		draw_line(Vector2(0, y), Vector2(_level_length, y), Color(accent_color.r, accent_color.g, accent_color.b, 0.04), 1.0)

	# Layer 2: Glow orbs
	for i in 12:
		var ox := rng.randf() * _level_length
		var oy := rng.randf() * 300.0 + 50.0
		var radius := rng.randf() * 40.0 + 20.0
		draw_circle(Vector2(ox, oy), radius, Color(accent_color.r, accent_color.g, accent_color.b, 0.03))

	# Layer 3: Mountain silhouettes
	var mountain_points := PackedVector2Array()
	mountain_points.append(Vector2(0, 300))
	var mx := 0.0
	while mx < _level_length:
		var peak_h := rng.randf() * 120.0 + 80.0
		var width := rng.randf() * 200.0 + 100.0
		mountain_points.append(Vector2(mx + width * 0.5, 300.0 - peak_h))
		mountain_points.append(Vector2(mx + width, 300))
		mx += width
	mountain_points.append(Vector2(_level_length, 300))
	mountain_points.append(Vector2(_level_length, 648))
	mountain_points.append(Vector2(0, 648))
	draw_colored_polygon(mountain_points, Color(fog_color.r, fog_color.g, fog_color.b, 0.3))
