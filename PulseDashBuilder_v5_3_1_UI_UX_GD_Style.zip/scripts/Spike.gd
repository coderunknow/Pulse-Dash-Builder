extends Area2D
@onready var visual: Polygon2D = $Visual
@onready var outline: Polygon2D = $Outline
@onready var danger_glow: Polygon2D = $DangerGlow
var _glow_phase: float = 0.0
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	_glow_phase += delta * 3.0
	if danger_glow:
		danger_glow.modulate.a = 0.06 + sin(_glow_phase) * 0.04
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		(body as DashPlayer).die("spike")
