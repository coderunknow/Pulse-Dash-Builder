## SkinManager — Static utility for cube skin glow configuration.
class_name SkinManager
extends RefCounted

static func get_glow_config(skin_id: String) -> Dictionary:
	match skin_id:
		"default":
			return {"color": Color("52d8ff"), "intensity": 1.0, "pulse_speed": 2.0, "trail_width": 5.0}
		"fire":
			return {"color": Color("ff6b4a"), "intensity": 1.2, "pulse_speed": 3.0, "trail_width": 6.0}
		"toxic":
			return {"color": Color("4aff6b"), "intensity": 1.1, "pulse_speed": 2.5, "trail_width": 5.0}
		_:
			return {"color": Color("52d8ff"), "intensity": 1.0, "pulse_speed": 2.0, "trail_width": 5.0}

static func apply_skin_to_player(_player: Node, _skin_id: String) -> void:
	pass
