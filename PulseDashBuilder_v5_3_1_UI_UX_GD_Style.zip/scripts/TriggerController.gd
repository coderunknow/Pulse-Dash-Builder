## GDTriggerController — Autoload managing trigger resolution and target registry.
class_name GDTriggerController
extends Node

signal trigger_fired(trigger: Node, player: Node)

var _targets: Dictionary = {}
var _camera: Camera2D = null
var _parallax: Node2D = null
var _sky_rect: ColorRect = null
var _particle_pool: Node2D = null
var _camera_offset: Vector2 = Vector2.ZERO
var _trigger_count: int = 0
var _active_tweens: Array[Tween] = []

func set_camera(cam: Camera2D) -> void:
	_camera = cam

func set_parallax(p: Node2D) -> void:
	_parallax = p

func set_sky_color_rect(r: ColorRect) -> void:
	_sky_rect = r

func set_particle_pool(p: Node2D) -> void:
	_particle_pool = p

func register_target(node: Node2D) -> void:
	var id := str(node.get_meta("object_id", ""))
	if id.is_empty():
		id = node.name
	_targets[id] = node

func get_camera_offset() -> Vector2:
	return _camera_offset

func get_trigger_count() -> int:
	return _trigger_count

func increment_trigger_count() -> void:
	_trigger_count += 1

func clear_all() -> void:
	_targets.clear()
	_camera_offset = Vector2.ZERO
	_trigger_count = 0
	for tw in _active_tweens:
		if is_instance_valid(tw):
			tw.kill()
	_active_tweens.clear()

func get_target(id: String) -> Node2D:
	if _targets.has(id):
		return _targets[id]
	return null
