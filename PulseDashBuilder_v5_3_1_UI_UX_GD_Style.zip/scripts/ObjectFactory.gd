## GDObjectFactory — Static factory that spawns world objects from JSON dictionaries.
class_name GDObjectFactory
extends RefCounted

const SCENE_DIR: String = "res://scenes/"

static func spawn(data: Dictionary, parent: Node, callbacks: Dictionary) -> Node:
	var kind: String = str(data.get("kind", "block"))
	var pos_arr = data.get("position", [0, 0])
	var pos := Vector2(float(pos_arr[0]) if pos_arr.size() > 0 else 0.0, float(pos_arr[1]) if pos_arr.size() > 1 else 0.0)
	var rot: float = float(data.get("rotation", 0.0))
	var obj_id: String = str(data.get("id", ""))
	var color_tok: String = str(data.get("color", ""))
	var node: Node = null

	match kind:
		"block", "moving_block":
			node = _load_scene("Block.tscn", parent)
			if node:
				var size_arr = data.get("size", [128, 64])
				var w: float = float(size_arr[0]) if size_arr.size() > 0 else 128.0
				var h: float = float(size_arr[1]) if size_arr.size() > 1 else 64.0
				_scale_block(node, w, h)
		"spike":
			node = _load_scene("Spike.tscn", parent)
		"sawblade":
			node = _load_scene("Sawblade.tscn", parent)
		"hazard_block":
			node = _load_scene("HazardBlock.tscn", parent)
		"bouncy_block":
			node = _load_scene("BouncyBlock.tscn", parent)
		"breakable":
			node = _load_scene("BreakableBlock.tscn", parent)
		"orb":
			node = _load_scene("JumpOrb.tscn", parent)
			if node:
				node.set_meta("orb_type", int(data.get("orb_type", 0)))
		"pad":
			node = _load_scene("JumpPad.tscn", parent)
			if node:
				node.set_meta("pad_type", int(data.get("pad_type", 0)))
		"portal":
			node = _load_scene("Portal.tscn", parent)
			if node:
				node.set("portal_type", int(data.get("portal_type", 0)))
		"coin":
			node = _load_scene("Coin.tscn", parent)
			if node:
				node.coin_id = obj_id
				if callbacks.has("on_coin"):
					node.collected.connect(callbacks["on_coin"])
				if callbacks.has("run_coins"):
					pass  # tracked in Main
		"finish":
			node = _load_scene("FinishGate.tscn", parent)
			if node and callbacks.has("on_finish"):
				node.finished.connect(callbacks["on_finish"])
		"trigger":
			node = _load_scene("Trigger.tscn", parent)
			if node:
				var action_str: String = str(data.get("action", "color"))
				node.trigger_action = _trigger_action_from_string(action_str)
				node.target_id = str(data.get("target_id", ""))
				node.duration = float(data.get("duration", 0.5))
				node.text_value = str(data.get("text", ""))
				node.pulse_strength = float(data.get("pulse_strength", 1.0))
				node.shake_strength = float(data.get("shake_strength", 4.0))
				node.shake_duration = float(data.get("shake_duration", 0.2))
				var cv = data.get("color", null)
				if cv is String:
					node.color_value = GDGameTypes.color_from_token(cv)
				elif cv is Array and cv.size() >= 3:
					node.color_value = Color(float(cv[0]), float(cv[1]), float(cv[2]))
		"moving_platform":
			node = _load_scene("MovingPlatform.tscn", parent)
		"teleport_pad":
			node = _load_scene("TeleportPad.tscn", parent)
			if node:
				var tp = data.get("target_position", [0, 0])
				node.target_position = Vector2(float(tp[0]), float(tp[1]))
		"wind_zone":
			node = _load_scene("WindZone.tscn", parent)
		"key":
			node = _load_scene("KeyLock.tscn", parent)
			if node:
				node.lock_id = str(data.get("lock_id", ""))
				node.is_key = true
		"lock":
			node = _load_scene("KeyLock.tscn", parent)
			if node:
				node.lock_id = str(data.get("lock_id", ""))
				node.is_key = false
		"oscillating_spike":
			node = _load_scene("OscillatingSpike.tscn", parent)
		"path_spike":
			node = _load_scene("PathMovingSpike.tscn", parent)
		_:
			node = _load_scene("Block.tscn", parent)

	if node == null:
		return null

	node.global_position = pos
	node.rotation = rot
	if not obj_id.is_empty():
		node.set_meta("object_id", obj_id)

	# Apply color if specified
	if not color_tok.is_empty() and node.has_method("_refresh_visual"):
		var c := GDGameTypes.color_from_token(color_tok)
		if node.has("accent_color"):
			node.accent_color = c
			node._refresh_visual()

	return node

static func _load_scene(scene_name: String, parent: Node) -> Node:
	var path := SCENE_DIR + scene_name
	if not ResourceLoader.exists(path):
		return null
	var packed := load(path) as PackedScene
	if packed == null:
		return null
	var instance := packed.instantiate()
	parent.add_child(instance)
	return instance

static func _scale_block(node: Node, w: float, h: float) -> void:
	var base_w := 128.0
	var base_h := 64.0
	var sx := w / base_w
	var sy := h / base_h
	node.scale = Vector2(sx, sy)
	var shape_node := node.get_node_or_null("CollisionShape2D")
	if shape_node and shape_node.shape is RectangleShape2D:
		shape_node.shape.size = Vector2(w, h)

static func _apply_neon_glow(node: Node, color: Color, intensity: float, _pulse_speed: float) -> void:
	# Apply a subtle modulate tint to simulate neon glow
	if node == null:
		return
	var visual := node.get_node_or_null("NeonBorder")
	if visual and visual is Polygon2D:
		visual.color = Color(color.r, color.g, color.b, clampf(intensity, 0.0, 1.0))

static func _trigger_action_from_string(s: String) -> int:
	match s.to_lower():
		"color": return GDGameTypes.TriggerAction.COLOR
		"move": return GDGameTypes.TriggerAction.MOVE
		"rotate": return GDGameTypes.TriggerAction.ROTATE
		"alpha": return GDGameTypes.TriggerAction.ALPHA
		"toggle": return GDGameTypes.TriggerAction.TOGGLE
		"pulse": return GDGameTypes.TriggerAction.PULSE
		"shake": return GDGameTypes.TriggerAction.SHAKE
		"spawn": return GDGameTypes.TriggerAction.SPAWN
		"camera_zoom": return GDGameTypes.TriggerAction.CAMERA_ZOOM
		"camera_move": return GDGameTypes.TriggerAction.CAMERA_MOVE
		"collision_toggle": return GDGameTypes.TriggerAction.COLLISION_TOGGLE
		"background": return GDGameTypes.TriggerAction.BACKGROUND
		"speed": return GDGameTypes.TriggerAction.SPEED
		"counter": return GDGameTypes.TriggerAction.COUNTER
		_: return GDGameTypes.TriggerAction.COLOR
