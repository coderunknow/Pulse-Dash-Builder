extends StaticBody2D
@export var move_vector: Vector2 = Vector2(200, 0)
@export var speed: float = 1.0
var _time: float = 0.0
var _start_pos: Vector2 = Vector2.ZERO
func _ready() -> void:
	_start_pos = position
func _physics_process(delta: float) -> void:
	_time += delta * speed
	var new_pos := _start_pos + move_vector * sin(_time)
	position = new_pos
