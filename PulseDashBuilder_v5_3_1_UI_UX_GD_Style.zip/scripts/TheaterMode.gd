## TheaterMode.gd — Replay-theater controller that plays back saved replays
## with play/pause/seek/speed control and optional cinematic camera zoom.
## Uses ReplayRecorder under the hood for tick-based playback.
##
## Usage: add to a theater scene. Load replay data via load_replay(),
## then call play(). The theater drives a ghost player node.

extends Node2D

## Emitted when playback reaches the end of the replay.
signal playback_finished()

## The ghost player node that receives playback input.
@export var ghost_player: Node = null

## Camera to control for cinematic zoom interpolation.
@export var theater_camera: Camera2D = null

## When true, camera zoom is interpolated for dramatic effect during playback.
@export var cinematic: bool = false

## Base zoom level for cinematic mode.
@export_range(0.3, 2.0, 0.1) var cinematic_base_zoom: float = 1.0

## Zoom-in intensity during high-action moments (near start/end).
@export_range(1.0, 3.0, 0.1) var cinematic_zoom_peak: float = 1.6

## The replay recorder used for playback.
var _recorder: ReplayRecorder = null

## Current playhead position in seconds.
var _playhead: float = 0.0

## Total replay duration in seconds.
var _total_time: float = 0.0

## Whether playback is currently running.
var _playing: bool = false

## Playback speed multiplier.
var _speed: float = 1.0

## Reusable Vector2 buffer for camera zoom (zero GC).
var _zoom_buf: Vector2 = Vector2.ONE


func _ready() -> void:
	_recorder = ReplayRecorder.new()
	set_process(false)


## Load replay data from a Dictionary (e.g. from ReplayRecorder.make_ghost_data()
## or deserialized JSON). Sets up the internal recorder for playback.
func load_replay(replay_data: Dictionary) -> void:
	if _playing:
		pause()
	_playhead = 0.0
	var version: int = int(replay_data.get("version", 1))
	if version >= 2:
		# Binary format — deserialize from base64
		var ts_b64: String = str(replay_data.get("ts", ""))
		var fl_b64: String = str(replay_data.get("fl", ""))
		if ts_b64.is_empty():
			return
		var ts_bytes: PackedByteArray = Marshalls.base64_to_raw(ts_b64)
		if ts_bytes.is_empty() or ts_bytes.size() % 4 != 0:
			return
		_recorder._timestamps = PackedFloat32Array()
		_recorder._timestamps.resize(ts_bytes.size() / 4)
		_recorder._timestamps.from_byte_array(ts_bytes)
		_recorder._flags = PackedByteArray()
		if not fl_b64.is_empty():
			_recorder._flags = Marshalls.base64_to_raw(fl_b64)
		_total_time = float(replay_data.get("duration", 0.0))
	else:
		# Legacy v1 format — frame array
		var frames_data: Variant = replay_data.get("frames", [])
		if frames_data is Array:
			_recorder.load_from_json(frames_data as Array)
			_total_time = _recorder.recording_duration()


## Start playback at the current speed.
func play(speed: float = 1.0) -> void:
	if _total_time <= 0.0:
		return
	_speed = clampf(speed, 0.25, 4.0)
	_playing = true
	_recorder.playback(ghost_player, _speed)
	set_process(true)


## Pause playback. Resume with play().
func pause() -> void:
	_playing = false
	_recorder.stop_playback()
	set_process(false)


## Set playback speed (0.25 / 0.5 / 1.0 / 2.0 typical values).
func set_speed(s: float) -> void:
	_speed = clampf(s, 0.25, 4.0)
	if _playing:
		_recorder.playback(ghost_player, _speed)


## Seek to a specific time position. Restarts playback from that point.
func seek_to(t: float) -> void:
	t = clampf(t, 0.0, _total_time)
	if _playing:
		_recorder.stop_playback()
	_playhead = t
	if _playing or t > 0.0:
		_recorder.playback(ghost_player, _speed)


## Returns true if playback is currently active.
func is_playing() -> bool:
	return _playing


## Returns the current playhead position in seconds.
func get_playhead_time() -> float:
	return _playhead


## Returns the total replay duration in seconds.
func get_total_time() -> float:
	return _total_time


func _process(delta: float) -> void:
	if not _playing:
		return
	_playhead += delta * _speed
	# Tick the replay recorder
	var finished: bool = _recorder.tick_playback()
	if finished or _playhead >= _total_time:
		_playhead = _total_time
		_playing = false
		_recorder.stop_playback()
		set_process(false)
		playback_finished.emit()
		return
	# Cinematic camera zoom
	if cinematic and theater_camera != null and is_instance_valid(theater_camera):
		_update_cinematic_zoom()


## Update camera zoom for dramatic cinematic effect.
## Zooms in near the start (first 5%) and near the end (last 10%).
func _update_cinematic_zoom() -> void:
	if _total_time <= 0.0:
		return
	var progress: float = _playhead / _total_time
	var zoom_factor: float = cinematic_base_zoom
	# Zoom in during first 5%
	if progress < 0.05:
		var t: float = 1.0 - (progress / 0.05)
		zoom_factor = lerpf(cinematic_base_zoom, cinematic_zoom_peak, t)
	# Zoom in during last 10%
	elif progress > 0.90:
		var t: float = (progress - 0.90) / 0.10
		zoom_factor = lerpf(cinematic_base_zoom, cinematic_zoom_peak, t)
	_zoom_buf.x = zoom_factor
	_zoom_buf.y = zoom_factor
	theater_camera.zoom = _zoom_buf


## v5 UPGRADE: New script — replay theater controller with play/pause/seek/
## speed API, cinematic camera zoom, zero-GC _process loop, and full
## ReplayRecorder integration for v2 binary and v1 legacy formats.
