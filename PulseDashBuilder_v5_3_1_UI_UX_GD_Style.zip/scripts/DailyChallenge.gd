## DailyChallenge — Autoload providing a seeded daily level.
class_name GDDailyChallenge
extends Node

var _daily_seed: int = 0
var _daily_level: Dictionary = {}

func _ready() -> void:
	_generate_daily()

func _generate_daily() -> void:
	var date: Dictionary = Time.get_datetime_dict_from_system()
	_daily_seed = int(date["year"]) * 10000 + int(date["month"]) * 100 + int(date["day"])
	_daily_level = {
		"id": "daily_%d" % _daily_seed,
		"name": "Daily Challenge",
		"bpm": 140 + (_daily_seed % 40),
		"length": 4800 + (_daily_seed % 3000),
		"background": ["neon", "sunset", "forest", "ocean", "void", "lava"][_daily_seed % 6],
		"difficulty": "normal",
		"author": "Daily",
		"format_version": 3,
		"start": [0.0, 400.0],
		"objects": [],
	}

func get_daily_level() -> Dictionary:
	return _daily_level

func get_seed() -> int:
	return _daily_seed
