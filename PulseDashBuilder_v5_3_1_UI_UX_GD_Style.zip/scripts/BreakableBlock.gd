class_name BreakableBlock
extends StaticBody2D
var broken: bool = false
func break_block() -> void:
	broken = true
	visible = false
	set_deferred("collision_layer", 0)
