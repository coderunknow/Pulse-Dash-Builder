extends Area2D
signal collected(coin_id: String)
var coin_id: String = ""
var _collected: bool = false
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _on_body_entered(body: Node) -> void:
	if _collected: return
	if body is DashPlayer:
		_collected = true
		collected.emit(coin_id)
		queue_free()
