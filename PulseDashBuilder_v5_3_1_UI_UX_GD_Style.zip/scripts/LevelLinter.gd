## v5 UPGRADE: Enhanced level verification with 6+ checks. Adds a new
## lint_structured() that returns typed Array[Dictionary] of
## {severity, code, message, object_index}. The legacy lint() API is preserved
## (still returns Array[String]) for backward compatibility — it now delegates
## to lint_structured() and flattens the messages. New checks: missing finish,
## duplicate IDs, dangling target_id, unreachable finish heuristic, player start
## overlapping hazard, speed portal sanity. format_report() converts structured
## results to a human-readable string.

class_name LevelLinter
extends RefCounted

## Enhanced offline level lint / verification.
## Used by editor before save/publish and in Main before starting custom levels.

## v5: Check codes
const CODE_MISSING_FINISH := "MISSING_FINISH"
const CODE_DUPLICATE_ID := "DUPLICATE_ID"
const CODE_DANGLING_TARGET := "DANGLING_TARGET"
const CODE_UNREACHABLE_FINISH := "UNREACHABLE_FINISH"
const CODE_START_ON_HAZARD := "START_ON_HAZARD"
const CODE_SPEED_PORTAL_SANITY := "SPEED_PORTAL_SANITY"
const CODE_SHORT_LEVEL := "SHORT_LEVEL"
const CODE_LONG_LEVEL := "LONG_LEVEL"


## v5: Run all lint checks on a level dictionary.
## Returns Array[Dictionary] where each entry has:
##   severity: String — "error", "warning", or "info"
##   code: String — machine-readable check code (see CODE_* consts)
##   message: String — human-readable description
##   object_index: int — index in objects array, or -1 if not object-specific
static func lint_structured(level: Dictionary) -> Array[Dictionary]:
	var results: Array[Dictionary] = []
	if not (level is Dictionary):
		results.append(_make_issue("error", "INVALID_DATA", "Level data is not a dictionary", -1))
		return results

	var objects: Array = level.get("objects", []) as Array
	var has_finish: bool = false
	var finish_x: float = -1.0
	var ids: Dictionary = {}              # id -> count
	var id_to_index: Dictionary = {}       # id -> first object index
	var target_ids: Array[Dictionary] = [] # {target_id, object_index}
	var has_speed_quad: bool = false
	var has_speed_normal_after_quad: bool = false
	var max_object_x: float = 0.0
	var start_pos: Vector2 = Vector2(160.0, 450.0)

	# Parse start position
	var start_data: Variant = level.get("start", [160.0, 450.0])
	if start_data is Array and start_data.size() >= 2:
		start_pos = Vector2(float(start_data[0]), float(start_data[1]))

	# First pass: collect metadata
	for obj_idx: int in range(objects.size()):
		var obj_v: Variant = objects[obj_idx]
		if not (obj_v is Dictionary):
			continue
		var obj: Dictionary = obj_v as Dictionary
		var kind: String = str(obj.get("kind", "")).to_lower()
		var pos: Vector2 = _vec2(obj.get("position", [0, 0]))

		if kind == "finish":
			has_finish = true
			finish_x = pos.x

		# Track rightmost object for unreachable heuristic
		if pos.x > max_object_x:
			max_object_x = pos.x

		# Collect IDs and check for duplicates
		var oid: String = str(obj.get("id", "")).strip_edges()
		if not oid.is_empty():
			ids[oid] = ids.get(oid, 0) + 1
			if not id_to_index.has(oid):
				id_to_index[oid] = obj_idx

		# Collect trigger target references
		if kind == "trigger":
			var tid: String = str(obj.get("target_id", "")).strip_edges()
			if not tid.is_empty():
				target_ids.append({"target_id": tid, "object_index": obj_idx})

		# Speed portal tracking
		if kind == "portal":
			var portal_type: String = str(obj.get("portal", ""))
			if portal_type == "speed_quad":
				has_speed_quad = true
			elif portal_type == "speed_normal" and has_speed_quad:
				has_speed_normal_after_quad = true

		# Player start overlapping hazard check (object index 0 region)
		if kind in ["spike", "sawblade", "hazard_block", "oscillating_spike", "path_spike"]:
			var obj_size: Vector2 = _vec2(obj.get("size", [40, 40]))
			var obj_radius: float = float(obj.get("radius", 20.0))
			var half_w: float = obj_size.x * 0.5 if kind in ["hazard_block"] else obj_radius
			var half_h: float = obj_size.y * 0.5 if kind in ["hazard_block"] else obj_radius
			if absf(pos.x - start_pos.x) < half_w + 20.0 and absf(pos.y - start_pos.y) < half_h + 20.0:
				results.append(_make_issue("error", CODE_START_ON_HAZARD,
					"Player start overlaps a hazard object — instant death", obj_idx))

	# ─── Checks ────────────────────────────────────────────────────────────

	# 1. Missing FinishGate
	if not has_finish:
		results.append(_make_issue("error", CODE_MISSING_FINISH,
			"Missing Finish Gate — level is not completable", -1))

	# 2. Duplicate object IDs
	for id_str: String in ids.keys():
		if ids[id_str] > 1:
			results.append(_make_issue("warning", CODE_DUPLICATE_ID,
				"Duplicate object id: '%s' (%d times)" % [id_str, ids[id_str]],
				int(id_to_index.get(id_str, -1))))

	# 3. Dangling target_id references
	for target_entry: Dictionary in target_ids:
		var tid: String = str(target_entry.get("target_id", ""))
		var obj_idx: int = int(target_entry.get("object_index", -1))
		if not ids.has(tid):
			# Allow some built-in dynamic target patterns
			if not tid.begins_with("tw_") and not tid.begins_with("fp_") and not tid.begins_with("sg_"):
				results.append(_make_issue("warning", CODE_DANGLING_TARGET,
					"Trigger targets non-existent id: '%s'" % tid, obj_idx))

	# 4. Unreachable finish heuristic
	if has_finish and finish_x > 0.0 and max_object_x > 0.0:
		if finish_x > max_object_x + 200.0:
			results.append(_make_issue("info", CODE_UNREACHABLE_FINISH,
				"Finish gate is %dpx past the last object — may be unreachable" % int(finish_x - max_object_x), -1))

	# 5. Speed portal sanity: warn if speed_quad with no speed_normal reset before finish
	if has_speed_quad and not has_speed_normal_after_quad and has_finish:
		results.append(_make_issue("warning", CODE_SPEED_PORTAL_SANITY,
			"Speed quad portal found but no speed_normal reset before finish — player may remain at 4x", -1))

	# 6. Length sanity
	var length: float = float(level.get("length", 4800.0))
	if length < 500.0:
		results.append(_make_issue("info", CODE_SHORT_LEVEL,
			"Level length is very short (< 500) — may feel incomplete", -1))
	elif length > 25000.0:
		results.append(_make_issue("warning", CODE_LONG_LEVEL,
			"Level length is extremely long (> 25k) — performance risk", -1))

	return results


## Legacy API — returns plain string array (backward compatible).
## Delegates to lint_structured() and flattens messages.
static func lint(level: Dictionary) -> Array[String]:
	var structured: Array[Dictionary] = lint_structured(level)
	var issues: Array[String] = []
	for r: Dictionary in structured:
		issues.append(str(r.get("message", "")))
	return issues


static func has_issues(level: Dictionary) -> bool:
	return lint_structured(level).size() > 0


## v5: Format structured lint results into a human-readable report string.
static func format_report(lint_results: Array[Dictionary]) -> String:
	if lint_results.is_empty():
		return "Level verification passed ✓"
	var lines: Array[String] = []
	for r: Dictionary in lint_results:
		var severity: String = str(r.get("severity", "info")).to_upper()
		var code: String = str(r.get("code", "???"))
		var message: String = str(r.get("message", ""))
		var idx: int = int(r.get("object_index", -1))
		var location: String = ""
		if idx >= 0:
			location = " [object %d]" % idx
		lines.append("[%s] (%s)%s: %s" % [severity, code, location, message])
	return "Level issues found:\n• " + "\n• ".join(lines)


## Legacy format function (backward compatible).
static func format_issues(issues: Array[String]) -> String:
	if issues.is_empty():
		return "Level verification passed ✓"
	return "Level issues found:\n• " + "\n• ".join(issues)


# ─── Helpers ────────────────────────────────────────────────────────────────

static func _make_issue(severity: String, code: String, message: String, object_index: int) -> Dictionary:
	return {
		"severity": severity,
		"code": code,
		"message": message,
		"object_index": object_index,
	}


static func _vec2(data: Variant) -> Vector2:
	if data is Array and data.size() >= 2:
		return Vector2(float(data[0]), float(data[1]))
	if data is Vector2 or data is Vector2i:
		return data
	return Vector2.ZERO
