class_name GeometryDashMain
extends Node2D

## Data-driven game director. Uses ObjectFactory to spawn world objects from
## JSON, delegates trigger resolution to TriggerController, delegates stats to
## StatsTracker, delegates achievements to AchievementManager, delegates audio
## to AudioManager. Owns the camera, beat clock, HUD, menu, editor, and stats
## dashboard.
##
## State machine: MENU → PLAYING → (DYING → PLAYING)* → COMPLETED → MENU, plus
## EDITING and PAUSED branches. All UI layers are toggled by visibility; the
## scene is never reloaded — respawn rebuilds only the dynamic world.

const DEFAULT_CAMERA_HEIGHT: float = 324.0
const PRACTICE_FLAG_COLOR: Color = Color("6df3ff")
const OPTIONAL_BACKGROUND_TEXTURE_PATH: String = "res://assets/placeholders/neon_background.png"
const EDITOR_GRID_CELL: float = 20.0
const EDITOR_PICK_RADIUS: float = 42.0
const EDITOR_HISTORY_LIMIT: int = 64

enum RunState {
	MENU,
	PLAYING,
	PAUSED,
	DYING,
	COMPLETED,
	EDITING,
	STATS,
}

@export var camera_lead: float = 260.0
@export var camera_follow_speed: float = 8.0
@export var fall_death_y: float = 900.0

# Autoloads
@onready var game_state: GDGameState = get_node("/root/GameState") as GDGameState
@onready var audio: GDAudioManager = get_node_or_null("/root/AudioManager") as GDAudioManager
@onready var stats: GDStatsTracker = get_node_or_null("/root/StatsTracker") as GDStatsTracker
@onready var achievements: GDAchievementManager = get_node_or_null("/root/AchievementManager") as GDAchievementManager
@onready var triggers: GDTriggerController = get_node_or_null("/root/TriggerController") as GDTriggerController

# Scene tree
@onready var background_art: TextureRect = $Background/BackgroundArt
@onready var sky_rect: ColorRect = $Background/Sky
@onready var backdrop: Node2D = $Backdrop
@onready var parallax: ParallaxBackdrop = $Parallax
@onready var world: Node2D = $World
@onready var player_container: Node2D = $PlayerContainer
@onready var practice_flags: Node2D = $PracticeFlags
@onready var camera_rig: Node2D = $CameraRig
@onready var camera_2d: Camera2D = $CameraRig/Camera2D
@onready var beat_clock: BeatClock = $BeatClock
@onready var bgm_player: AudioStreamPlayer = $BGMPlayer
@onready var particle_pool: ParticlePool = $ParticlePool
@onready var after_image_pool: AfterImagePool = $AfterImagePool
@onready var pulse_overlay: ColorRect = $PulseOverlay/ColorRect

# HUD
@onready var game_hud: CanvasLayer = $GameHUD
@onready var top_panel: PanelContainer = $GameHUD/TopPanel
@onready var level_name_label: Label = $GameHUD/TopPanel/Rows/LevelNameLabel
@onready var attempt_label: Label = $GameHUD/TopPanel/Rows/AttemptLabel
@onready var mode_label: Label = $GameHUD/TopPanel/Rows/ModeLabel
@onready var progress_bar: ProgressBar = $GameHUD/ProgressBar
@onready var progress_label: Label = $GameHUD/ProgressLabel
@onready var practice_label: Label = $GameHUD/PracticeLabel
@onready var coin_label: Label = $GameHUD/CoinLabel
@onready var best_label: Label = $GameHUD/BestLabel
@onready var trigger_label: Label = $GameHUD/TriggerLabel
@onready var practice_button: Button = $GameHUD/PracticeButton
@onready var menu_button: Button = $GameHUD/MenuButton
@onready var mode_toast: Label = $GameHUD/ModeToast
@onready var countdown_label: Label = $GameHUD/CountdownLabel
@onready var achievement_toast: Label = $GameHUD/AchievementToast
@onready var xp_toast: Label = $GameHUD/XpToast

# Menu
@onready var menu_layer: CanvasLayer = $MenuLayer
@onready var level_list: VBoxContainer = $MenuLayer/Panel/Rows/LevelScroll/LevelList
@onready var create_level_button: Button = $MenuLayer/Panel/Rows/CreateLevelButton
@onready var settings_button: Button = $MenuLayer/Panel/Rows/SettingsButton
@onready var stats_button: Button = $MenuLayer/Panel/Rows/StatsButton
@onready var menu_status_label: Label = $MenuLayer/Panel/Rows/StatusLabel

# Pause
@onready var pause_layer: CanvasLayer = $PauseLayer
@onready var pause_resume_button: Button = $PauseLayer/Panel/Rows/ResumeButton
@onready var pause_restart_button: Button = $PauseLayer/Panel/Rows/RestartButton
@onready var pause_menu_button: Button = $PauseLayer/Panel/Rows/MenuButton

# Completion
@onready var completion_layer: CanvasLayer = $CompletionLayer
@onready var completion_summary_label: Label = $CompletionLayer/Panel/Rows/SummaryLabel
@onready var completion_replay_button: Button = $CompletionLayer/Panel/Rows/ReplayButton
@onready var completion_library_button: Button = $CompletionLayer/Panel/Rows/LibraryButton

# Settings
@onready var settings_layer: CanvasLayer = $SettingsLayer
@onready var creator_toggle_button: Button = $SettingsLayer/Panel/Rows/CreatorToggleButton
@onready var master_slider: HSlider = $SettingsLayer/Panel/Rows/MasterSliderContainer/MasterSlider
@onready var sfx_slider: HSlider = $SettingsLayer/Panel/Rows/SfxSliderContainer/SfxSlider
@onready var bgm_slider: HSlider = $SettingsLayer/Panel/Rows/BgmSliderContainer/BgmSlider
@onready var mute_check: CheckBox = $SettingsLayer/Panel/Rows/MuteCheck
@onready var settings_back_button: Button = $SettingsLayer/Panel/Rows/BackButton

# Stats dashboard
@onready var stats_layer: CanvasLayer = $StatsLayer
@onready var stats_content_label: Label = $StatsLayer/Panel/Rows/Scroll/StatsContent
@onready var stats_back_button: Button = $StatsLayer/Panel/Rows/BackButton

# Editor
@onready var editor_layer: CanvasLayer = $EditorLayer
@onready var editor_panel: PanelContainer = $EditorLayer/Panel
@onready var editor_name_edit: LineEdit = $EditorLayer/Panel/Rows/NameEdit
@onready var editor_palette: OptionButton = $EditorLayer/Panel/Rows/Palette
@onready var editor_selected_label: Label = $EditorLayer/Panel/Rows/SelectedLabel
@onready var editor_save_button: Button = $EditorLayer/Panel/Rows/SaveButton
@onready var editor_cancel_button: Button = $EditorLayer/Panel/Rows/CancelButton
@onready var editor_help_label: Label = $EditorLayer/Panel/Rows/HelpLabel
@onready var editor_inspector_label: Label = $EditorLayer/Panel/Rows/InspectorLabel
@onready var editor_id_edit: LineEdit = $EditorLayer/Panel/Rows/IdEdit
@onready var editor_color_edit: ColorPickerButton = $EditorLayer/Panel/Rows/ColorEdit
@onready var editor_width_edit: SpinBox = $EditorLayer/Panel/Rows/WidthEdit
@onready var editor_height_edit: SpinBox = $EditorLayer/Panel/Rows/HeightEdit
@onready var editor_rotation_edit: SpinBox = $EditorLayer/Panel/Rows/RotationEdit   # NEW v4.1 for GD rotation
@onready var editor_level_settings_button: Button = $EditorLayer/Panel/Rows/LevelSettingsButton
@onready var editor_rows: VBoxContainer = $EditorLayer/Panel/Rows

var _trigger_fields: VBoxContainer = null
var _trigger_action_edit: OptionButton = null
var _trigger_target_edit: LineEdit = null
var _trigger_value_edit: SpinBox = null
var _trigger_vector_x_edit: SpinBox = null
var _trigger_vector_y_edit: SpinBox = null
var _trigger_vector_row: HBoxContainer = null
var _trigger_duration_edit: SpinBox = null
var _trigger_easing_edit: OptionButton = null
var _trigger_text_edit: LineEdit = null
var _trigger_value_label: Label = null
var _trigger_vector_label: Label = null
var _trigger_duration_label: Label = null
var _trigger_easing_label: Label = null
var _trigger_text_label: Label = null

const TRIGGER_ACTION_TOKENS: Array[String] = ["color", "move", "rotate", "alpha", "toggle", "pulse", "shake", "spawn", "camera_zoom", "camera_move", "collision_toggle", "background", "speed", "counter"]

# === v4.1+ Professional Editor Overlay ===
var _editor_overlay: EditorOverlay = null
var _editor_drag_select_start: Vector2 = Vector2.ZERO
var _editor_is_drag_selecting: bool = false
var _editor_last_mouse_world: Vector2 = Vector2.ZERO

func _ensure_editor_overlay() -> void:
	if _editor_overlay == null:
		_editor_overlay = EditorOverlay.new()
		add_child(_editor_overlay)
		# Make sure it stays on top
		_editor_overlay.z_index = 300
	_editor_overlay.visible = (_run_state == RunState.EDITING)

func _update_editor_overlay() -> void:
	if _editor_overlay == null or not _editor_overlay.visible:
		return
	var objects: Array = _editor_draft.get("objects", [])
	var lines: Array = []
	# Build trigger target lines (editor only)
	for obj in objects:
		if not (obj is Dictionary): continue
		if str(obj.get("kind", "")) != "trigger": continue
		var tid := str(obj.get("target_id", ""))
		if tid.is_empty(): continue
		var from := _vector_from_data(obj.get("position", [0,0]), Vector2.ZERO)
		for t in objects:
			if str(t.get("id", "")) == tid:
				var to := _vector_from_data(t.get("position", [0,0]), Vector2.ZERO)
				lines.append({"from": [from.x, from.y], "to": [to.x, to.y]})
				break
	var active_rot := -1
	if _editor_rotation_handle_active and _editor_rotation_object_index >= 0:
		active_rot = _editor_rotation_object_index
	_editor_overlay.update_data(objects, _editor_selected_indices, lines, active_rot)
	_editor_overlay.show_grid = _editor_snap_enabled

	# Modern rubber-band selection box
	if _editor_is_drag_selecting:
		_editor_overlay.set_drag_selection(true, _editor_drag_select_start, _editor_last_mouse_world)
	else:
		_editor_overlay.set_drag_selection(false)

	_editor_overlay.queue_redraw()

# Level settings dialog
@onready var level_settings_layer: CanvasLayer = $LevelSettingsLayer
@onready var ls_bpm_edit: SpinBox = $LevelSettingsLayer/Panel/Rows/BpmEdit
@onready var ls_length_edit: SpinBox = $LevelSettingsLayer/Panel/Rows/LengthEdit
@onready var ls_theme_option: OptionButton = $LevelSettingsLayer/Panel/Rows/ThemeOption
@onready var ls_difficulty_option: OptionButton = $LevelSettingsLayer/Panel/Rows/DifficultyOption
@onready var ls_apply_button: Button = $LevelSettingsLayer/Panel/Rows/ApplyButton
@onready var ls_cancel_button: Button = $LevelSettingsLayer/Panel/Rows/CancelButton

var _run_state: RunState = RunState.MENU
var _current_level: Dictionary = {}
var _players: Array[DashPlayer] = []
var _attempt_count: int = 1
var _practice_enabled: bool = false
var _practice_checkpoints: Array[Dictionary] = []
var _run_coin_ids: Array[String] = []
var _mirror_enabled: bool = false
var _editor_draft: Dictionary = {}
var _editor_selected_token: String = "block"
var _intro_remaining: float = 0.0
var _intro_go_remaining: float = 0.0
var _hud_info_fade_timer: float = 0.0
var _hud_info_fading: bool = false
var _toast_remaining: float = 0.0
var _camera_shake_remaining: float = 0.0
var _camera_shake_strength: float = 0.0
var _camera_shake_duration: float = 0.16
var _achievement_toast_remaining: float = 0.0
var _xp_toast_remaining: float = 0.0
# v5.3: Cross-level counters for the new notify_* hooks. Static so they
# survive the in-place world rebuilds in start_level() / _show_menu() which
# do not recreate the Main node itself (Main is the scene root).
static var _par_beats_count: int = 0
static var _lint_clean_passes: int = 0
var _editor_history: Array[Dictionary] = []
var _editor_redo_stack: Array[Dictionary] = []
var _editor_clipboard: Dictionary = {}
var _editor_inspector_updating: bool = false
var _editor_inspected_index: int = -1

# Race condition guard for dual-mode death + finish in same frame
var _pending_finish_player: DashPlayer = null

# === v4 Editor multi-select + drag ===
var _editor_selected_indices: Array[int] = []
var _editor_drag_start_world: Vector2 = Vector2.ZERO
var _editor_is_dragging: bool = false
var _editor_drag_offset: Vector2 = Vector2.ZERO

# === v4.1 Editor UX state ===
var _editor_snap_enabled: bool = true
var _editor_zoom: float = 1.0
var _editor_rotation_handle_active: bool = false
var _editor_rotation_start_angle: float = 0.0
var _editor_rotation_object_index: int = -1
var _editor_rotation_initial_rot: float = 0.0
var _editor_last_rot_handle_hit: int = -1   # for visual feedback on hover

# === v4 Replay recording (input log) ===
var _replay_frames: Array[Dictionary] = []
var _replay_recording: bool = false
var _replay_start_time: float = 0.0

# === v4 Theater mode state ===
var _theater_mode: bool = false
var _theater_camera_pos: Vector2 = Vector2.ZERO
var _theater_progress: float = 0.0


func _ready() -> void:
	add_to_group(&"game_controller")
	camera_2d.add_to_group(&"main_camera")
	# Wire AudioManager to Main's BGM player.
	if audio != null:
		audio.set_bgm_player(bgm_player)
	# Wire TriggerController.
	if triggers != null:
		triggers.set_camera(camera_2d)
		triggers.set_parallax(parallax)
		triggers.set_sky_color_rect(sky_rect)
		triggers.set_particle_pool(particle_pool)
		triggers.set_meta("spawn_callback", Callable(self, "_spawn_runtime_object"))
		triggers.trigger_fired.connect(_on_trigger_fired)
	# Wire AchievementManager to toast display.
	if achievements != null:
		achievements.unlocked.connect(_on_achievement_unlocked)
		# v5.3: Also listen for the XP-awarded signal to show a "+N XP" popup
		# alongside the existing achievement name toast.
		achievements.achievement_unlocked_xp.connect(_on_achievement_xp)
	# Connect UI signals.
	practice_button.pressed.connect(_toggle_practice)
	menu_button.pressed.connect(_toggle_pause)
	pause_resume_button.pressed.connect(_toggle_pause)
	pause_restart_button.pressed.connect(_restart_current_level)
	pause_menu_button.pressed.connect(_show_menu)
	completion_replay_button.pressed.connect(_restart_current_level)
	completion_library_button.pressed.connect(_show_menu)
	create_level_button.pressed.connect(_open_editor)
	settings_button.pressed.connect(_open_settings)
	stats_button.pressed.connect(_open_stats)
	creator_toggle_button.pressed.connect(_toggle_creator_setting)
	settings_back_button.pressed.connect(_close_settings)
	stats_back_button.pressed.connect(_close_stats)
	master_slider.value_changed.connect(_on_master_slider_changed)
	sfx_slider.value_changed.connect(_on_sfx_slider_changed)
	bgm_slider.value_changed.connect(_on_bgm_slider_changed)
	mute_check.toggled.connect(_on_mute_toggled)
	editor_save_button.pressed.connect(_save_editor_level)
	editor_cancel_button.pressed.connect(_cancel_editor)
	editor_palette.item_selected.connect(_on_editor_palette_selected)
	editor_id_edit.text_changed.connect(_on_editor_id_changed)
	editor_color_edit.color_changed.connect(_on_editor_color_changed)
	editor_width_edit.value_changed.connect(_on_editor_width_changed)
	editor_height_edit.value_changed.connect(_on_editor_height_changed)
	if editor_rotation_edit:
		editor_rotation_edit.value_changed.connect(_on_editor_rotation_changed)
	editor_level_settings_button.pressed.connect(_open_level_settings)
	_setup_trigger_inspector()
	ls_apply_button.pressed.connect(_apply_level_settings)
	ls_cancel_button.pressed.connect(_cancel_level_settings)
	beat_clock.beat.connect(_on_beat)
	_load_optional_visual_assets()
	_populate_editor_palette()
	_populate_level_settings_options()
	_sync_audio_sliders()
	_show_menu()


func _exit_tree() -> void:
	# Guarantee durable saves when the application quits.
	if game_state != null and game_state.has_method("flush"):
		game_state.flush()
	if audio != null and audio.has_method("flush"):
		audio.flush()


func _load_optional_visual_assets() -> void:
	background_art.visible = false
	if not ResourceLoader.exists(OPTIONAL_BACKGROUND_TEXTURE_PATH):
		return
	var texture: Texture2D = load(OPTIONAL_BACKGROUND_TEXTURE_PATH) as Texture2D
	if texture == null:
		return
	background_art.texture = texture
	background_art.visible = true


func _sync_audio_sliders() -> void:
	if audio == null:
		return
	master_slider.value = audio.master_volume
	sfx_slider.value = audio.sfx_volume
	bgm_slider.value = audio.bgm_volume
	mute_check.button_pressed = audio.muted


func _on_master_slider_changed(value: float) -> void:
	if audio != null:
		audio.set_master_volume(value)


func _on_sfx_slider_changed(value: float) -> void:
	if audio != null:
		audio.set_sfx_volume(value)


func _on_bgm_slider_changed(value: float) -> void:
	if audio != null:
		audio.set_bgm_volume(value)


func _on_mute_toggled(value: bool) -> void:
	if audio != null:
		audio.set_muted(value)


func _process(delta: float) -> void:
	var pulse_alpha: float = beat_clock.get_pulse() * 0.14
	var pulse_color: Color = Color(0.16, 0.70, 1.0, pulse_alpha)
	pulse_overlay.color = pulse_color
	_update_mode_toast(delta)
	_update_achievement_toast(delta)
	_update_xp_toast(delta)

	if _run_state != RunState.PLAYING:
		return

	if _intro_remaining > 0.0 or _intro_go_remaining > 0.0:
		_update_intro_countdown(delta)
		return

	var primary: DashPlayer = _primary_player()
	if primary == null:
		return

	after_image_pool.maybe_spawn(primary, primary.speed_multiplier, delta)

	# Camera follows primary; offset by TriggerController (camera_move trigger)
	var trigger_offset: Vector2 = triggers.get_camera_offset() if triggers != null else Vector2.ZERO
	var desired_camera_position: Vector2 = Vector2(
		primary.global_position.x + camera_lead + trigger_offset.x,
		DEFAULT_CAMERA_HEIGHT + trigger_offset.y
	)
	var blend: float = 1.0 - exp(-camera_follow_speed * delta)
	camera_rig.global_position = camera_rig.global_position.lerp(desired_camera_position, blend)
	_apply_camera_shake(delta)
	_update_game_hud(primary)
	_update_hud_info_fade(delta)

	for player: DashPlayer in _players:
		if is_instance_valid(player) and player.global_position.y > fall_death_y:
			player.die("fell below the level")


func _update_intro_countdown(delta: float) -> void:
	if _intro_remaining > 0.0:
		var old_phase: int = ceili(_intro_remaining)
		_intro_remaining = maxf(_intro_remaining - delta, 0.0)
		var new_phase: int = ceili(_intro_remaining) if _intro_remaining > 0.0 else 0
		if old_phase != new_phase and new_phase >= 1:
			_play_sfx(GDGameTypes.SfxCue.COUNTDOWN_TICK)
		if _intro_remaining > 0.0:
			countdown_label.text = "%d" % maxi(new_phase, 1)
			return
		countdown_label.text = "GO!"
		_play_sfx(GDGameTypes.SfxCue.COUNTDOWN_GO)
		_intro_go_remaining = 0.45
		for player: DashPlayer in _players:
			if is_instance_valid(player):
				player.set_external_lock(false)
		return

	_intro_go_remaining = maxf(_intro_go_remaining - delta, 0.0)
	if _intro_go_remaining <= 0.0:
		countdown_label.visible = false
		# Start HUD info panel auto-hide countdown (GD-style)
		if _hud_info_fade_timer <= 0.0 and not _hud_info_fading:
			_hud_info_fade_timer = 2.5


func _show_mode_toast(message: String, color: Color = Color("6df3ff")) -> void:
	mode_toast.text = message
	mode_toast.modulate = color
	mode_toast.visible = true
	_toast_remaining = 1.25


func _update_mode_toast(delta: float) -> void:
	if _toast_remaining <= 0.0:
		return
	_toast_remaining = maxf(_toast_remaining - delta, 0.0)
	var toast_color: Color = mode_toast.modulate
	toast_color.a = clampf(_toast_remaining / 0.35, 0.0, 1.0)
	mode_toast.modulate = toast_color
	if _toast_remaining <= 0.0:
		mode_toast.visible = false


func _show_achievement_toast(message: String) -> void:
	achievement_toast.text = "★  %s" % message
	achievement_toast.visible = true
	_achievement_toast_remaining = 2.6
	_play_sfx(GDGameTypes.SfxCue.ACHIEVEMENT)


func _update_achievement_toast(delta: float) -> void:
	if _achievement_toast_remaining <= 0.0:
		return
	_achievement_toast_remaining = maxf(_achievement_toast_remaining - delta, 0.0)
	var c: Color = achievement_toast.modulate
	c.a = clampf(_achievement_toast_remaining / 0.5, 0.0, 1.0)
	achievement_toast.modulate = c
	if _achievement_toast_remaining <= 0.0:
		achievement_toast.visible = false


func _play_sfx(cue: int) -> void:
	if audio != null:
		audio.play_sfx(cue)


func _trigger_camera_shake(strength: float, duration: float = 0.16) -> void:
	var clamped_duration: float = maxf(duration, 0.01)
	_camera_shake_strength = maxf(_camera_shake_strength, maxf(strength, 0.0))
	if clamped_duration >= _camera_shake_remaining:
		_camera_shake_duration = clamped_duration
	_camera_shake_remaining = maxf(_camera_shake_remaining, clamped_duration)


func _apply_camera_shake(delta: float) -> void:
	if _camera_shake_remaining <= 0.0:
		return
	_camera_shake_remaining = maxf(_camera_shake_remaining - delta, 0.0)
	var ratio: float = clampf(_camera_shake_remaining / maxf(_camera_shake_duration, 0.01), 0.0, 1.0)
	camera_rig.global_position += Vector2(
		randf_range(-_camera_shake_strength, _camera_shake_strength),
		randf_range(-_camera_shake_strength, _camera_shake_strength),
	) * ratio
	if _camera_shake_remaining <= 0.0:
		_camera_shake_strength = 0.0
		_camera_shake_duration = 0.16


func _unhandled_input(event: InputEvent) -> void:
	if _run_state == RunState.EDITING:
		_handle_editor_input(event)
		return

	if not (event is InputEventKey):
		return

	var key_event: InputEventKey = event as InputEventKey
	if not key_event.pressed or key_event.echo:
		return
	if _run_state == RunState.COMPLETED:
		if key_event.keycode == KEY_ESCAPE or key_event.is_action_pressed(&"ui_accept"):
			_show_menu()
		return
	if _run_state == RunState.PAUSED:
		if key_event.keycode == KEY_ESCAPE:
			_toggle_pause()
		return
	if _run_state != RunState.PLAYING:
		return

	match key_event.keycode:
		KEY_P:
			_toggle_practice()
		KEY_C:
			if _practice_enabled:
				_place_practice_checkpoint()
		KEY_X:
			if _practice_enabled:
				_remove_latest_checkpoint()
		KEY_R:
			if _practice_enabled:
				_respawn_from_checkpoint()
		KEY_M:
			if audio != null:
				audio.set_muted(not audio.muted)
				mute_check.button_pressed = audio.muted
		KEY_ESCAPE:
			_toggle_pause()


# ─── Level lifecycle ────────────────────────────────────────────────────────

func start_level(level: Dictionary) -> void:
	_current_level = game_state.normalize_level(level)
	game_state.select_level(_current_level)
	_run_state = RunState.PLAYING
	_attempt_count = 1
	_practice_enabled = false
	_practice_checkpoints.clear()
	_run_coin_ids.clear()
	_mirror_enabled = false
	camera_rig.scale = Vector2.ONE
	camera_2d.zoom = Vector2.ONE
	menu_layer.visible = false
	settings_layer.visible = false
	editor_layer.visible = false
	pause_layer.visible = false
	completion_layer.visible = false
	stats_layer.visible = false
	level_settings_layer.visible = false
	game_hud.visible = true
	top_panel.visible = true
	top_panel.modulate.a = 1.0
	_hud_info_fade_timer = 0.0
	_hud_info_fading = false
	practice_label.visible = false
	practice_button.text = "Practice: OFF"
	_clear_runtime_world()
	_apply_background_theme(GDGameTypes.background_theme_from_token(str(_current_level.get("background", "neon"))))
	parallax.rebuild(float(_current_level.get("length", 4_800.0)), hash(str(_current_level.get("id", ""))))
	_build_level_objects(_current_level)
	_spawn_players([_make_initial_player_state()])
	_intro_remaining = 3.0
	_intro_go_remaining = 0.0
	countdown_label.text = "3"
	countdown_label.visible = true
	for player: DashPlayer in _players:
		if is_instance_valid(player):
			player.set_external_lock(true)
			player.set_level_id(str(_current_level.get("id", "")))
	var initial_primary: DashPlayer = _primary_player()
	if initial_primary != null:
		camera_rig.global_position = Vector2(initial_primary.global_position.x + camera_lead, DEFAULT_CAMERA_HEIGHT)
	beat_clock.start_clock(float(_current_level.get("bpm", 140.0)))
	if audio != null and audio.get_bgm_track_names().size() > 0:
		audio.play_bgm()
	_update_game_hud(_primary_player())
	if stats != null:
		stats.start_run(str(_current_level.get("id", "")))
	# v4 replay
	_replay_frames.clear()
	_replay_recording = true
	_replay_start_time = Time.get_ticks_msec() / 1000.0
	if achievements != null:
		achievements.notify_first_run()


func _show_menu() -> void:
	_run_state = RunState.MENU
	beat_clock.stop_clock()
	if audio != null:
		audio.stop_bgm()
	if stats != null:
		stats.end_run()
	game_hud.visible = false
	settings_layer.visible = false
	editor_layer.visible = false
	pause_layer.visible = false
	completion_layer.visible = false
	stats_layer.visible = false
	level_settings_layer.visible = false
	countdown_label.visible = false
	achievement_toast.visible = false
	_intro_remaining = 0.0
	_intro_go_remaining = 0.0
	menu_layer.visible = true
	_clear_runtime_world()
	_populate_level_browser()


func _populate_level_browser() -> void:
	for child: Node in level_list.get_children():
		child.queue_free()

	var levels: Array[Dictionary] = game_state.get_all_levels()
	for level: Dictionary in levels:
		var level_button: Button = Button.new()
		var level_id: String = str(level.get("id", ""))
		var completed_suffix: String = "  ✓" if (stats != null and stats.is_level_completed(level_id)) else ""
		var source_prefix: String = "CUSTOM" if not bool(level.get("built_in", false)) else "OFFICIAL"
		var best: int = stats.get_best_progress(level_id) if stats != null else 0
		var best_suffix: String = "  •  best %d%%" % best if best > 0 else ""
		var diff: String = str(level.get("difficulty", "easy")).capitalize()
		level_button.text = "%s  •  %s  [%s]%s%s" % [source_prefix, str(level.get("name", "Untitled")), diff, completed_suffix, best_suffix]
		level_button.tooltip_text = "Author: %s | BPM: %d | Attempts: %d" % [str(level.get("author", "Player")), roundi(float(level.get("bpm", 140.0))), (stats.get_attempts(level_id) if stats != null else 0)]
		level_button.custom_minimum_size = Vector2(0.0, 36.0)
		level_button.pressed.connect(start_level.bind(level))
		level_list.add_child(level_button)

	create_level_button.visible = game_state.build_mode_enabled
	menu_status_label.text = "Creator is %s. Custom levels are saved permanently in user://geometry_dash_clone/levels." % ["ON" if game_state.build_mode_enabled else "OFF"]


# ─── Settings ───────────────────────────────────────────────────────────────

func _open_settings() -> void:
	settings_layer.visible = true
	menu_layer.visible = false
	_creator_toggle_text()
	_sync_audio_sliders()


func _close_settings() -> void:
	settings_layer.visible = false
	menu_layer.visible = true
	_populate_level_browser()


func _toggle_creator_setting() -> void:
	game_state.set_build_mode_enabled(not game_state.build_mode_enabled)
	_creator_toggle_text()


func _creator_toggle_text() -> void:
	creator_toggle_button.text = "Creator Mode: %s\n(When OFF, Create Level is hidden)" % ["ON" if game_state.build_mode_enabled else "OFF"]


# ─── Stats dashboard ────────────────────────────────────────────────────────

func _open_stats() -> void:
	stats_layer.visible = true
	menu_layer.visible = false
	_refresh_stats_dashboard()


func _close_stats() -> void:
	stats_layer.visible = false
	menu_layer.visible = true


func _refresh_stats_dashboard() -> void:
	if stats == null or achievements == null:
		stats_content_label.text = "Stats system unavailable."
		return
	var play_minutes: int = floori(stats.total_play_time / 60.0)
	var play_seconds: int = int(stats.total_play_time) % 60
	var lines: Array[String] = []
	lines.append("== Aggregate Stats ==")
	lines.append("Total completions: %d" % stats.total_completions)
	lines.append("Total deaths: %d" % stats.total_deaths)
	lines.append("Total jumps: %d" % stats.total_jumps)
	lines.append("Total coins collected: %d" % stats.total_coins)
	lines.append("Levels attempted: %d" % stats.total_levels_played)
	lines.append("Play time: %d:%02d" % [play_minutes, play_seconds])
	lines.append("")
	lines.append("== Achievements (%d / %d) ==" % [achievements.get_unlocked_count(), achievements.get_total_count()])
	for def: Dictionary in achievements.get_all_definitions():
		var id: String = str(def.get("id", ""))
		var name: String = str(def.get("name", id))
		var desc: String = str(def.get("description", ""))
		var mark: String = "[x]" if achievements.is_unlocked(id) else "[ ]"
		lines.append("%s  %s — %s" % [mark, name, desc])
	lines.append("")
	lines.append("== Per-Level Stats ==")
	for level: Dictionary in game_state.get_all_levels():
		var level_id: String = str(level.get("id", ""))
		var name: String = str(level.get("name", "Untitled"))
		var att: int = stats.get_attempts(level_id)
		var best: int = stats.get_best_progress(level_id)
		var comp: int = stats.get_completions(level_id)
		var deaths: int = stats.get_deaths(level_id)
		lines.append("%s — attempts %d  best %d%%  completed %d×  deaths %d" % [name, att, best, comp, deaths])
	stats_content_label.text = "\n".join(lines)


# ─── Pause / restart ────────────────────────────────────────────────────────

func _toggle_pause() -> void:
	if _run_state == RunState.PLAYING:
		if _intro_remaining > 0.0 or _intro_go_remaining > 0.0:
			return
		_run_state = RunState.PAUSED
		pause_layer.visible = true
		for player: DashPlayer in _players:
			if is_instance_valid(player):
				player.set_external_lock(true)
		return
	if _run_state == RunState.PAUSED:
		_run_state = RunState.PLAYING
		pause_layer.visible = false
		for player: DashPlayer in _players:
			if is_instance_valid(player):
				player.set_external_lock(false)


func _restart_current_level() -> void:
	if _current_level.is_empty():
		return
	start_level(_current_level)


# ─── Practice ───────────────────────────────────────────────────────────────

func _toggle_practice() -> void:
	if _run_state != RunState.PLAYING:
		return
	_practice_enabled = not _practice_enabled
	if not _practice_enabled:
		_practice_checkpoints.clear()
		_clear_practice_flags()
	practice_label.visible = _practice_enabled
	practice_button.text = "Practice: %s" % ["ON" if _practice_enabled else "OFF"]
	if _practice_enabled:
		_place_practice_checkpoint()


func _place_practice_checkpoint() -> void:
	var primary: DashPlayer = _primary_player()
	if primary == null:
		return
	var player_states: Array[Dictionary] = []
	for player: DashPlayer in _players:
		if is_instance_valid(player):
			player_states.append(player.make_checkpoint_state())
	_practice_checkpoints.append({
		"players": player_states,
		"coins": _run_coin_ids.duplicate(),
	})
	_rebuild_practice_flags()
	particle_pool.play_burst(primary.global_position, PRACTICE_FLAG_COLOR, 8, 70.0, 160.0, 120.0)
	_play_sfx(GDGameTypes.SfxCue.CHECKPOINT)
	_show_mode_toast("CHECKPOINT %d" % _practice_checkpoints.size(), PRACTICE_FLAG_COLOR)
	practice_label.text = "PRACTICE • %d checkpoint(s) • C place / X delete / R respawn" % _practice_checkpoints.size()
	if achievements != null:
		achievements.notify_practice_pro(_practice_checkpoints.size())


func _remove_latest_checkpoint() -> void:
	if _practice_checkpoints.is_empty():
		return
	_practice_checkpoints.pop_back()
	_rebuild_practice_flags()
	practice_label.text = "PRACTICE • %d checkpoint(s) • C place / X delete / R respawn" % _practice_checkpoints.size()


# ─── Player signals ─────────────────────────────────────────────────────────

func _on_player_died(player: DashPlayer, _reason: String) -> void:
	if _run_state != RunState.PLAYING:
		return
	_run_state = RunState.DYING
	_attempt_count += 1
	particle_pool.play_burst(player.global_position, Color("52d8ff"), 22, 150.0, 330.0, 900.0)
	_trigger_camera_shake(14.0, 0.22)
	# Record progress at moment of death.
	var primary: DashPlayer = _primary_player()
	if primary != null and stats != null:
		var length: float = maxf(float(_current_level.get("length", 4_800.0)), 1.0)
		var start_x: float = _vector_from_data(_current_level.get("start", [0.0, 0.0]), Vector2.ZERO).x
		var course_distance: float = maxf(length - start_x, 1.0)
		var progress: int = clampi(roundi((primary.global_position.x - start_x) / course_distance * 100.0), 0, 100)
		stats.record_progress(progress)
	# Latch any pending finish that happened in the same frame (dual mode race)
	if _pending_finish_player != null and is_instance_valid(_pending_finish_player):
		var finisher := _pending_finish_player
		_pending_finish_player = null
		# Defer the finish handling to after respawn restores PLAYING
		_on_finish_reached.call_deferred(finisher)
	# Deferred so the death SFX/particles emit this frame before the rebuild.
	_instant_respawn.call_deferred(true)


func _instant_respawn(record_new_attempt: bool = false) -> void:
	if _current_level.is_empty():
		return
	var states: Array[Dictionary] = []
	if _practice_enabled and not _practice_checkpoints.is_empty():
		var latest_checkpoint: Dictionary = _practice_checkpoints.back()
		states = _checkpoint_player_states(latest_checkpoint)
		_run_coin_ids = _checkpoint_coins(latest_checkpoint)
	else:
		states.append(_make_initial_player_state())
		_run_coin_ids.clear()

	_clear_runtime_world()
	parallax.rebuild(float(_current_level.get("length", 4_800.0)), hash(str(_current_level.get("id", ""))))
	_build_level_objects(_current_level)
	_spawn_players(states)
	var respawn_primary: DashPlayer = _primary_player()
	if respawn_primary != null:
		camera_rig.global_position = Vector2(respawn_primary.global_position.x + camera_lead, DEFAULT_CAMERA_HEIGHT)
	_rebuild_practice_flags()
	_intro_remaining = 0.0
	_intro_go_remaining = 0.0
	countdown_label.visible = false
	if record_new_attempt and stats != null:
		stats.start_run(str(_current_level.get("id", "")))
	_run_state = RunState.PLAYING
	# Re-show info panel briefly on respawn (GD-style attempt display)
	top_panel.visible = true
	top_panel.modulate.a = 1.0
	_hud_info_fade_timer = 2.0
	_hud_info_fading = false


func _respawn_from_checkpoint() -> void:
	if _run_state != RunState.PLAYING:
		return
	_instant_respawn(false)


func _on_portal_requested(player: DashPlayer, portal_type: int) -> void:
	if _run_state != RunState.PLAYING:
		return
	particle_pool.play_burst(player.global_position, Color("a77cff"), 12, 80.0, 270.0, 0.0)
	_trigger_camera_shake(4.0, 0.10)
	match portal_type:
		GDGameTypes.PortalType.DUAL_ON:
			_set_dual_mode(true, player)
		GDGameTypes.PortalType.DUAL_OFF:
			_set_dual_mode(false, player)
		GDGameTypes.PortalType.MIRROR_ON:
			_set_mirror(true)
		GDGameTypes.PortalType.MIRROR_OFF:
			_set_mirror(false)
		_:
			player.apply_portal(portal_type)


func _set_dual_mode(enabled: bool, source_player: DashPlayer) -> void:
	if enabled:
		if _players.size() > 1:
			return
		var secondary_state: Dictionary = source_player.make_checkpoint_state()
		secondary_state["gravity_sign"] = -source_player.gravity_sign
		secondary_state["position"] = [source_player.global_position.x + 20.0, 130.0 if source_player.gravity_sign > 0.0 else 480.0]
		_spawn_player(secondary_state, 1)
	else:
		if _players.size() <= 1:
			return
		var secondary: DashPlayer = _players[1]
		if is_instance_valid(secondary):
			secondary.queue_free()
		_players.remove_at(1)


func _set_mirror(enabled: bool) -> void:
	_mirror_enabled = enabled
	camera_rig.scale = Vector2(-1.0, 1.0) if enabled else Vector2.ONE


func _on_player_jumped(player: DashPlayer, world_position: Vector2) -> void:
	if _run_state == RunState.PLAYING:
		particle_pool.play_burst(world_position, _mode_color(player.game_mode), 6, 100.0, 210.0, 90.0)


func _on_player_landed(_player: DashPlayer, _world_position: Vector2) -> void:
	# Reserved for landing dust effects.
	pass


func _on_player_mode_changed(player: DashPlayer, new_mode: int) -> void:
	if _run_state != RunState.PLAYING:
		return
	var mode_name: String = GDGameTypes.game_mode_name(new_mode).to_upper()
	_show_mode_toast("MODE: %s" % mode_name, _mode_color(new_mode))
	particle_pool.play_burst(player.global_position, _mode_color(new_mode), 12, 80.0, 270.0, 0.0)


func _mode_color(mode: int) -> Color:
	match mode:
		GDGameTypes.GameMode.SHIP: return Color("ffb65e")
		GDGameTypes.GameMode.BALL: return Color("d778ff")
		GDGameTypes.GameMode.UFO: return Color("7cf5a4")
		GDGameTypes.GameMode.WAVE: return Color("f4f06b")
		GDGameTypes.GameMode.ROBOT: return Color("ff7c91")
		GDGameTypes.GameMode.SPIDER: return Color("9c7cff")
		GDGameTypes.GameMode.SWING: return Color("7ce8ff")
		_: return Color("ffd15f")


func _on_coin_collected(coin_id: String) -> void:
	if not _run_coin_ids.has(coin_id):
		_run_coin_ids.append(coin_id)
		var primary: DashPlayer = _primary_player()
		if primary != null:
			particle_pool.play_burst(primary.global_position, Color("ffd85a"), 10, 100.0, 240.0, 160.0)
		_play_sfx(GDGameTypes.SfxCue.COIN)
		_show_mode_toast("SECRET COIN COLLECTED", Color("ffd85a"))


func _on_finish_reached(_finisher: DashPlayer) -> void:
	if _run_state != RunState.PLAYING:
		# Race: death happened in same frame (dual). Latch for later resolution after respawn
		if _run_state == RunState.DYING:
			_pending_finish_player = _finisher
		return
	_run_state = RunState.COMPLETED
	for player: DashPlayer in _players:
		if is_instance_valid(player):
			player.freeze_for_completion()
	beat_clock.stop_clock()
	if stats != null:
		stats.record_progress(100)
		stats.record_completion(_run_coin_ids)
		stats.end_run()
	if achievements != null:
		if _attempt_count == 1:
			achievements.notify_flawless()
		achievements.notify_speed_demon_completed(str(_current_level.get("id", "")))
		achievements.check_finish_all(game_state.get_builtin_level_count())
		# v5.3: Par-time check — derive par from level length + intro buffer.
		# _replay_start_time is set in start_level() and includes the 3s
		# countdown intro, so par_time adds a 4s buffer on top of the
		# generous 400 px/s baseline. If the player finishes under par,
		# bump the static counter and notify so speedrunner can fire
		# after 5 under-par completions.
		var par_time_seconds: float = float(_current_level.get("length", 4_800.0)) / 400.0 + 4.0
		var elapsed_seconds: float = Time.get_ticks_msec() / 1000.0 - _replay_start_time
		if elapsed_seconds <= par_time_seconds:
			_par_beats_count += 1
			achievements.notify_speedrunner(_par_beats_count)
	practice_label.visible = false
	progress_bar.value = 100.0
	progress_label.text = "100%"
	completion_summary_label.text = "Attempts: %d  •  Secret coins: %d" % [_attempt_count, _run_coin_ids.size()]
	completion_layer.visible = true
	_show_mode_toast("LEVEL COMPLETE!", Color("ffd85a"))
	_play_sfx(GDGameTypes.SfxCue.FINISH)


# ─── Triggers ───────────────────────────────────────────────────────────────

func _on_trigger_fired(trigger: LevelTrigger, _player: DashPlayer) -> void:
	# TriggerController resolves the action; here we add SFX and shake.
	match trigger.trigger_action:
		GDGameTypes.TriggerAction.COLOR:
			_play_sfx(GDGameTypes.SfxCue.TRIGGER_COLOR)
		GDGameTypes.TriggerAction.PULSE:
			_play_sfx(GDGameTypes.SfxCue.TRIGGER_PULSE)
			_trigger_camera_shake(6.0 * trigger.pulse_strength, 0.18)
		GDGameTypes.TriggerAction.SHAKE:
			_play_sfx(GDGameTypes.SfxCue.TRIGGER_SHAKE)
			_trigger_camera_shake(trigger.shake_strength, trigger.shake_duration)
		GDGameTypes.TriggerAction.SPAWN:
			_play_sfx(GDGameTypes.SfxCue.TRIGGER_SPAWN)
			particle_pool.play_burst(trigger.global_position, trigger.color_value, 16, 150.0, 300.0, 0.0)
	var fired_count: int = triggers.get_trigger_count() if triggers != null else 0
	if achievements != null:
		achievements.notify_trigger_master(fired_count)
	if trigger_label != null:
		trigger_label.text = "TRIGGERS: %d" % fired_count


# ─── Spawn pipeline ─────────────────────────────────────────────────────────

func _spawn_players(states: Array[Dictionary]) -> void:
	for state_index: int in range(states.size()):
		_spawn_player(states[state_index], state_index)
	if _players.is_empty():
		_spawn_player(_make_initial_player_state(), 0)


func _spawn_player(state: Dictionary, slot: int) -> void:
	var player: DashPlayer = preload("res://scenes/Player.tscn").instantiate() as DashPlayer
	player_container.add_child(player)
	player.configure(slot, state)
	player.set_level_id(str(_current_level.get("id", "")))
	player.died.connect(_on_player_died)
	player.portal_requested.connect(_on_portal_requested)
	player.jumped.connect(_on_player_jumped)
	player.landed.connect(_on_player_landed)
	player.mode_changed.connect(_on_player_mode_changed)
	# v5.2: Apply skin-specific neon glow to the player's first Sprite2D / Polygon2D child.
	# SkinManager.get_glow_config() returns per-skin glow_color, glow_intensity,
	# and glow_pulse_speed so each skin can customize its neon shader uniforms.
	var _glow_cfg: Dictionary = SkinManager.get_glow_config(game_state.selected_skin)
	GDObjectFactory._apply_neon_glow(player, _glow_cfg.color, _glow_cfg.intensity, _glow_cfg.pulse_speed)
	_players.append(player)


func _primary_player() -> DashPlayer:
	if _players.is_empty() or not is_instance_valid(_players[0]):
		return null
	return _players[0]


func _make_initial_player_state() -> Dictionary:
	var start_position: Vector2 = _vector_from_data(_current_level.get("start", [160.0, 450.0]), Vector2(160.0, 450.0))
	return {
		"position": [start_position.x, start_position.y],
		"game_mode": GDGameTypes.GameMode.CUBE,
		"gravity_sign": 1.0,
		"speed_multiplier": 1.0,
		"is_mini": false,
	}


func _checkpoint_player_states(checkpoint: Dictionary) -> Array[Dictionary]:
	var output: Array[Dictionary] = []
	var states: Variant = checkpoint.get("players", [])
	if states is Array:
		for state: Variant in states:
			if state is Dictionary:
				output.append(state.duplicate(true))
	if output.is_empty():
		output.append(_make_initial_player_state())
	return output


func _checkpoint_coins(checkpoint: Dictionary) -> Array[String]:
	var output: Array[String] = []
	var coin_data: Variant = checkpoint.get("coins", [])
	if coin_data is Array:
		for coin_id: Variant in coin_data:
			output.append(str(coin_id))
	return output


# ─── Build level ────────────────────────────────────────────────────────────

# Builds the callbacks dictionary shared by initial level build and runtime
# spawn (TriggerController SPAWN action). Centralized to keep the two paths
# in sync.
func _make_level_callbacks() -> Dictionary:
	return {
		"level_id": str(_current_level.get("id", "")),
		"stats": stats,
		"run_coins": _run_coin_ids,
		"on_coin": _on_coin_collected,
		"on_finish": _on_finish_reached,
		"trigger_controller": triggers,
		"on_key_pickup": _on_key_pickup,
		"on_lock_open": _on_lock_open,
	}


func _build_level_objects(level: Dictionary) -> void:
	# _clear_runtime_world() already invoked triggers.clear_all() before this,
	# so we only build here. Registering targets/trigger callbacks is idempotent.
	var callbacks: Dictionary = _make_level_callbacks()
	var objects: Variant = level.get("objects", [])
	if not (objects is Array):
		return
	for object_data: Variant in objects:
		if object_data is Dictionary:
			var node: Node = GDObjectFactory.spawn(object_data as Dictionary, world, callbacks)
			if node != null and triggers != null and node is Node2D:
				triggers.register_target(node as Node2D)


# Spawn-time helper used by TriggerController for SPAWN actions.
func _spawn_runtime_object(data: Dictionary) -> void:
	var node: Node = GDObjectFactory.spawn(data, world, _make_level_callbacks())
	if node != null and triggers != null and node is Node2D:
		triggers.register_target(node as Node2D)


func _on_key_pickup(lock_id: String) -> void:
	_show_mode_toast("KEY ACQUIRED", Color("ffd85a"))
	# Find any matching lock nodes in the world and open them.
	for child: Node in world.get_children():
		if child is KeyLock and not (child as KeyLock).is_key:
			var kl: KeyLock = child as KeyLock
			if kl.lock_id == lock_id:
				kl.open_lock()


func _on_lock_open(_lock_id: String) -> void:
	_play_sfx(GDGameTypes.SfxCue.LOCK_OPEN)
	_show_mode_toast("LOCK OPENED", Color("76f6b0"))


func _apply_background_theme(theme: int) -> void:
	parallax.set_theme(theme, false)
	var palette: Dictionary = GDGameTypes.background_theme_palette(theme)
	sky_rect.color = palette["fog"]


# ─── Achievement toast ──────────────────────────────────────────────────────

func _on_achievement_unlocked(_id: String, display_name: String) -> void:
	_show_achievement_toast("Achievement: %s" % display_name)


# v5.3: Show a "+N XP" popup when an achievement is unlocked. Uses a dedicated
# XpToast Label (top-right corner, gold) so it never overlaps the existing
# mode_toast (top-center) or achievement_toast (bottom-center). Visible for ~2s
# with a 0.5s linear fade-out, matching the achievement name toast rhythm.
func _on_achievement_xp(_achievement_id: String, xp_awarded: int) -> void:
	_show_xp_toast(xp_awarded)


func _show_xp_toast(xp_awarded: int) -> void:
	xp_toast.text = "+%d XP" % xp_awarded
	xp_toast.visible = true
	# Reset alpha in case the previous toast was mid-fade-out.
	var c: Color = xp_toast.modulate
	c.a = 1.0
	xp_toast.modulate = c
	_xp_toast_remaining = 2.0


func _update_xp_toast(delta: float) -> void:
	if _xp_toast_remaining <= 0.0:
		return
	_xp_toast_remaining = maxf(_xp_toast_remaining - delta, 0.0)
	var c: Color = xp_toast.modulate
	c.a = clampf(_xp_toast_remaining / 0.5, 0.0, 1.0)
	xp_toast.modulate = c
	if _xp_toast_remaining <= 0.0:
		xp_toast.visible = false


# ─── HUD ────────────────────────────────────────────────────────────────────

func _update_game_hud(primary: DashPlayer) -> void:
	if primary == null:
		return
	var length: float = maxf(float(_current_level.get("length", 4_800.0)), 1.0)
	var start_position: Vector2 = _vector_from_data(_current_level.get("start", [0.0, 0.0]), Vector2.ZERO)
	var course_distance: float = maxf(length - start_position.x, 1.0)
	var progress: float = clampf((primary.global_position.x - start_position.x) / course_distance * 100.0, 0.0, 100.0)
	level_name_label.text = str(_current_level.get("name", "Untitled Level"))
	attempt_label.text = "ATTEMPT %d" % _attempt_count
	mode_label.text = "%s%s  •  %.1fx" % [GDGameTypes.game_mode_name(primary.game_mode).to_upper(), " MINI" if primary.is_mini else "", primary.speed_multiplier]
	progress_bar.value = progress
	progress_label.text = "%d%%" % roundi(progress)
	coin_label.text = "◈ %d" % _run_coin_ids.size()
	var level_id: String = str(_current_level.get("id", ""))
	var best: int = stats.get_best_progress(level_id) if stats != null else 0
	best_label.text = "BEST %d%%" % best
	if triggers != null:
		trigger_label.text = "TRIGGERS: %d" % triggers.get_trigger_count()
	if _practice_enabled:
		practice_label.text = "PRACTICE • %d checkpoint(s) • C place / X delete / R respawn" % _practice_checkpoints.size()


func _update_hud_info_fade(delta: float) -> void:
	# GD-style: info panel fades out a few seconds after gameplay starts
	if _hud_info_fade_timer > 0.0:
		_hud_info_fade_timer -= delta
		if _hud_info_fade_timer <= 0.0:
			_hud_info_fading = true
			_hud_info_fade_timer = 0.0
	if _hud_info_fading:
		var alpha: float = top_panel.modulate.a
		alpha = maxf(alpha - delta * 2.0, 0.0)  # Fade over ~0.5s
		top_panel.modulate.a = alpha
		if alpha <= 0.0:
			top_panel.visible = false
			_hud_info_fading = false


func _on_beat(_strength: float) -> void:
	if _run_state == RunState.PLAYING:
		progress_bar.modulate = Color(1.0, 1.0, 1.0, 1.12)


func _clear_runtime_world() -> void:
	for child: Node in world.get_children():
		child.queue_free()
	for child: Node in backdrop.get_children():
		child.queue_free()
	for child: Node in player_container.get_children():
		child.queue_free()
	_clear_practice_flags()
	_players.clear()
	if triggers != null:
		triggers.clear_all()


func _clear_practice_flags() -> void:
	for child: Node in practice_flags.get_children():
		child.queue_free()


func _rebuild_practice_flags() -> void:
	_clear_practice_flags()
	for checkpoint: Dictionary in _practice_checkpoints:
		var states: Array[Dictionary] = _checkpoint_player_states(checkpoint)
		if states.is_empty():
			continue
		var position: Vector2 = _vector_from_data(states[0].get("position", [0.0, 0.0]), Vector2.ZERO)
		var flag: Node2D = Node2D.new()
		flag.position = position
		var pole: Polygon2D = Polygon2D.new()
		pole.polygon = PackedVector2Array([Vector2(-2.0, -54.0), Vector2(2.0, -54.0), Vector2(2.0, 10.0), Vector2(-2.0, 10.0)])
		pole.color = PRACTICE_FLAG_COLOR
		var cloth: Polygon2D = Polygon2D.new()
		cloth.polygon = PackedVector2Array([Vector2(2.0, -54.0), Vector2(34.0, -45.0), Vector2(2.0, -28.0)])
		cloth.color = Color("ff83d0")
		flag.add_child(pole)
		flag.add_child(cloth)
		practice_flags.add_child(flag)


# ─── Editor ─────────────────────────────────────────────────────────────────

func _open_editor() -> void:
	if not game_state.build_mode_enabled:
		return
	_run_state = RunState.EDITING
	_current_level = game_state.make_blank_level()
	_editor_draft = _current_level.duplicate(true)
	_editor_selected_token = "block"
	_editor_history.clear()
	_editor_redo_stack.clear()
	_editor_zoom = 1.0
	_editor_snap_enabled = true
	editor_name_edit.text = str(_editor_draft.get("name", "Untitled Level"))
	editor_layer.visible = true
	menu_layer.visible = false
	settings_layer.visible = false
	level_settings_layer.visible = false
	game_hud.visible = false
	camera_rig.scale = Vector2.ONE
	camera_2d.zoom = Vector2.ONE
	camera_rig.global_position = Vector2(576.0, DEFAULT_CAMERA_HEIGHT)
	_clear_runtime_world()
	_apply_background_theme(GDGameTypes.background_theme_from_token(str(_editor_draft.get("background", "neon"))))
	parallax.rebuild(float(_editor_draft.get("length", 4_800.0)), 0)
	_build_level_objects(_editor_draft)
	_update_editor_selected_label()
	_update_editor_inspector()
	_ensure_editor_overlay()
	_update_editor_overlay()


func _cancel_editor() -> void:
	level_settings_layer.visible = false
	editor_layer.visible = false
	_show_menu()


func _save_editor_level() -> void:
	_editor_draft["name"] = editor_name_edit.text.strip_edges()
	if str(_editor_draft["name"]).is_empty():
		editor_help_label.text = "A level name is required before saving."
		return
	var lint_issues = LevelLinter.lint(_editor_draft)
	if lint_issues.size() > 0:
		editor_help_label.text = "Lint warnings: " + str(lint_issues.size())
	else:
		# v5.3: Zero-warning lint pass — bump the lint_master counter so
		# the AchievementManager can fire after 10 clean passes.
		_lint_clean_passes += 1
		if achievements != null:
			achievements.notify_lint_master(_lint_clean_passes)
	print(LevelLinter.format_issues(lint_issues))
	var saved_level: Dictionary = game_state.save_custom_level(_editor_draft)
	if saved_level.is_empty():
		editor_help_label.text = "Save failed. Check user:// write access."
		return
	if achievements != null:
		achievements.notify_level_saved()
	editor_layer.visible = false
	_show_menu()


func _populate_editor_palette() -> void:
	var entries: Array[Dictionary] = [
		{"label": "Solid Block", "token": "block"},
		{"label": "Moving Platform", "token": "moving_block"},
		{"label": "Hazard Block (damaging)", "token": "hazard_block"},
		{"label": "Bouncy Block", "token": "bouncy_block"},
		{"label": "Spike", "token": "spike"},
		{"label": "Oscillating Spike", "token": "oscillating_spike"},
		{"label": "Sawblade", "token": "sawblade"},
		{"label": "Breakable Block (Dash only)", "token": "breakable"},
		{"label": "Secret Coin", "token": "coin"},
		{"label": "Key", "token": "key"},
		{"label": "Lock", "token": "lock"},
		{"label": "Yellow Pad", "token": "pad_yellow"},
		{"label": "Pink Pad", "token": "pad_pink"},
		{"label": "Red Pad", "token": "pad_red"},
		{"label": "Blue Pad", "token": "pad_blue"},
		{"label": "Yellow Orb", "token": "orb_yellow"},
		{"label": "Pink Orb", "token": "orb_pink"},
		{"label": "Red Orb", "token": "orb_red"},
		{"label": "Blue Orb", "token": "orb_blue"},
		{"label": "Purple Orb", "token": "orb_purple"},
		{"label": "Black Orb", "token": "orb_black"},
		{"label": "Dash Orb", "token": "orb_dash"},
		{"label": "Portal: Cube", "token": "portal_cube"},
		{"label": "Portal: Ship", "token": "portal_ship"},
		{"label": "Portal: Ball", "token": "portal_ball"},
		{"label": "Portal: UFO", "token": "portal_ufo"},
		{"label": "Portal: Wave", "token": "portal_wave"},
		{"label": "Portal: Robot", "token": "portal_robot"},
		{"label": "Portal: Spider", "token": "portal_spider"},
		{"label": "Portal: Swing", "token": "portal_swing"},
		{"label": "Portal: Gravity Blue", "token": "portal_gravity_invert"},
		{"label": "Portal: Gravity Yellow", "token": "portal_gravity_normal"},
		{"label": "Portal: Mini", "token": "portal_mini"},
		{"label": "Portal: Normal", "token": "portal_normal"},
		{"label": "Portal: 0.5x", "token": "portal_speed_half"},
		{"label": "Portal: 1x", "token": "portal_speed_normal"},
		{"label": "Portal: 2x", "token": "portal_speed_double"},
		{"label": "Portal: 3x", "token": "portal_speed_triple"},
		{"label": "Portal: 4x", "token": "portal_speed_quad"},
		{"label": "Portal: Dual On", "token": "portal_dual_on"},
		{"label": "Portal: Dual Off", "token": "portal_dual_off"},
		{"label": "Portal: Mirror On", "token": "portal_mirror_on"},
		{"label": "Portal: Mirror Off", "token": "portal_mirror_off"},
		{"label": "Trigger: Color", "token": "trigger_color"},
		{"label": "Trigger: Move", "token": "trigger_move"},
		{"label": "Trigger: Rotate", "token": "trigger_rotate"},
		{"label": "Trigger: Alpha", "token": "trigger_alpha"},
		{"label": "Trigger: Toggle", "token": "trigger_toggle"},
		{"label": "Trigger: Pulse", "token": "trigger_pulse"},
		{"label": "Trigger: Shake", "token": "trigger_shake"},
		{"label": "Trigger: Spawn", "token": "trigger_spawn"},
		{"label": "Trigger: Camera Zoom", "token": "trigger_camera_zoom"},
		{"label": "Trigger: Camera Move", "token": "trigger_camera_move"},
		{"label": "Trigger: Collision Toggle", "token": "trigger_collision_toggle"},
		{"label": "Trigger: Background", "token": "trigger_background"},
		{"label": "Trigger: Speed", "token": "trigger_speed"},
		{"label": "Trigger: Counter", "token": "trigger_counter"},
		{"label": "Finish Gate", "token": "finish"},
		{"label": "Teleport Pad", "token": "teleport_pad"},
		{"label": "Wind Zone", "token": "wind_zone"},
		{"label": "Path Moving Spike (GD)", "token": "path_spike"},
	]
	for entry: Dictionary in entries:
		editor_palette.add_item(str(entry["label"]))
		editor_palette.set_item_metadata(editor_palette.get_item_count() - 1, str(entry["token"]))


func _populate_level_settings_options() -> void:
	ls_theme_option.clear()
	for t: int in [GDGameTypes.BackgroundTheme.NEON, GDGameTypes.BackgroundTheme.SUNSET, GDGameTypes.BackgroundTheme.AURORA, GDGameTypes.BackgroundTheme.VOID]:
		ls_theme_option.add_item(GDGameTypes.background_theme_name(t))
		ls_theme_option.set_item_metadata(ls_theme_option.get_item_count() - 1, t)
	ls_difficulty_option.clear()
	for d: String in ["easy", "medium", "hard", "demon"]:
		ls_difficulty_option.add_item(d.capitalize())
		ls_difficulty_option.set_item_metadata(ls_difficulty_option.get_item_count() - 1, d)


func _on_editor_palette_selected(_index: int) -> void:
	_editor_selected_token = str(editor_palette.get_item_metadata(editor_palette.get_selected()))
	_update_editor_selected_label()


func _update_editor_selected_label() -> void:
	var sel_count := _editor_selected_indices.size()
	var base := _editor_selected_token.replace("_", " ").to_upper()
	if sel_count > 1:
		editor_selected_label.text = "SELECTED: %s  •    %d objects" % [base, sel_count]
	else:
		editor_selected_label.text = "SELECTED: %s" % base

	# Professional status hint
	var snap_text := "SNAP: ON" if _editor_snap_enabled else "SNAP: OFF"
	var zoom_text := "%.1fx" % _editor_zoom
	editor_help_label.text = "LMB place/drag • RMB remove • Ctrl+click multi • R rotate • Ctrl+D dup • S snap • Wheel zoom  •        %s  •  %s" % [snap_text, zoom_text]


# Convert a screen mouse position to a world position, snapped to the editor grid.
func _mouse_world_position(snap: bool = true) -> Vector2:
	var canvas_transform: Transform2D = get_viewport().get_canvas_transform()
	var world_position: Vector2 = canvas_transform.affine_inverse() * get_viewport().get_mouse_position()
	if snap:
		world_position = Vector2(
			roundf(world_position.x / EDITOR_GRID_CELL) * EDITOR_GRID_CELL,
			roundf(world_position.y / EDITOR_GRID_CELL) * EDITOR_GRID_CELL
		)
	return world_position


func _handle_editor_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key_event: InputEventKey = event as InputEventKey
		if not key_event.pressed or key_event.echo:
			return
		if key_event.ctrl_pressed and key_event.keycode == KEY_Z and not key_event.shift_pressed:
			_editor_undo()
			return
		if key_event.ctrl_pressed and (key_event.keycode == KEY_Y or (key_event.shift_pressed and key_event.keycode == KEY_Z)):
			_editor_redo()
			return
		if key_event.ctrl_pressed and key_event.keycode == KEY_C:
			_editor_copy()
			return
		if key_event.ctrl_pressed and key_event.keycode == KEY_V:
			_editor_paste()
			return
		if key_event.ctrl_pressed and key_event.keycode == KEY_S:
			_save_editor_level()
			return
		if key_event.keycode == KEY_A and key_event.ctrl_pressed:
			_editor_select_all()
			return
		match key_event.keycode:
			KEY_ESCAPE:
				_editor_selected_indices.clear()
				_cancel_editor()
			KEY_A:
				camera_rig.global_position.x -= 240.0
			KEY_D:
				camera_rig.global_position.x += 240.0
			KEY_W:
				camera_rig.global_position.y -= 120.0
			KEY_S:
				camera_rig.global_position.y += 120.0
			KEY_DELETE, KEY_BACKSPACE:
				_editor_delete_selected()
			KEY_R:
				_editor_rotate_selected(PI / 4.0)
			KEY_S:
				_editor_snap_enabled = not _editor_snap_enabled
				editor_help_label.text = "Snap: %s" % ("ON" if _editor_snap_enabled else "OFF")
			KEY_D:
				if key_event.ctrl_pressed:
					_editor_duplicate_selected()
		return

	if event is InputEventMouseMotion:
		_editor_last_mouse_world = _mouse_world_position(false)

		if _editor_rotation_handle_active:
			_perform_rotation_drag(_editor_last_mouse_world)
		elif _editor_is_dragging and _editor_selected_indices.size() > 0:
			_editor_perform_drag(_editor_last_mouse_world)
		elif _editor_is_drag_selecting:
			_update_drag_select(_editor_last_mouse_world)
		_update_editor_inspector()
		_update_editor_overlay()
		return

	if not (event is InputEventMouseButton):
		return
	var mouse_event: InputEventMouseButton = event as InputEventMouseButton
	if editor_panel.get_global_rect().has_point(mouse_event.position):
		return

	var world_position: Vector2 = _mouse_world_position(false)

	if mouse_event.button_index == MOUSE_BUTTON_LEFT:
		if mouse_event.pressed:
			if _try_start_rotation_drag(world_position):
				return
			_editor_try_start_drag_or_select(world_position)
		else:
			if _editor_rotation_handle_active:
				_end_rotation_drag()
			elif _editor_is_drag_selecting:
				_editor_end_drag_select()
			else:
				_editor_end_drag()
	elif mouse_event.button_index == MOUSE_BUTTON_RIGHT:
		if mouse_event.pressed:
			_remove_editor_object_near(world_position)
	elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_UP:
		_editor_adjust_zoom(1.1)
	elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
		_editor_adjust_zoom(1.0 / 1.1)


func _editor_delete_at_cursor() -> void:
	_remove_editor_object_near(_mouse_world_position(false))


func _add_editor_object(world_position: Vector2) -> void:
	var object_data: Dictionary = _make_editor_object(_editor_selected_token, world_position)
	if object_data.is_empty():
		return
	_push_editor_history({"action": "add", "object": object_data.duplicate(true)})
	var objects: Array = _editor_draft.get("objects", [])
	objects.append(object_data)
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	_play_sfx(GDGameTypes.SfxCue.EDITOR_PLACE)


func _remove_editor_object_near(world_position: Vector2) -> void:
	var objects: Array = _editor_draft.get("objects", [])
	for index: int in range(objects.size() - 1, -1, -1):
		var object_data: Variant = objects[index]
		if not (object_data is Dictionary):
			continue
		if str(object_data.get("kind", "")) == "block":
			var block_size: Vector2 = _vector_from_data(object_data.get("size", [0.0, 0.0]), Vector2.ZERO)
			if block_size.x > 1_000.0:
				continue
		var object_position: Vector2 = _vector_from_data(object_data.get("position", [0.0, 0.0]), Vector2.ZERO)
		if object_position.distance_to(world_position) <= EDITOR_PICK_RADIUS:
			var removed: Dictionary = objects[index]
			_push_editor_history({"action": "remove", "object": removed.duplicate(true), "index": index})
			objects.remove_at(index)
			_editor_draft["objects"] = objects
			_rebuild_editor_preview()
			_play_sfx(GDGameTypes.SfxCue.EDITOR_REMOVE)
			return


func _editor_undo() -> void:
	if _editor_history.is_empty():
		editor_help_label.text = "Nothing to undo."
		return
	var command: Dictionary = _editor_history.pop_back()
	var action: String = str(command.get("action", ""))
	var objects: Array = _editor_draft.get("objects", [])
	if action == "add":
		var idx: int = int(command.get("index", -1))
		if idx >= 0 and idx < objects.size():
			objects.remove_at(idx)
		else:
			# Fallback content match if index invalid
			var target: Dictionary = command.get("object", {})
			for i: int in range(objects.size() - 1, -1, -1):
				if _objects_equal(objects[i], target):
					objects.remove_at(i)
					break
		_editor_redo_stack.append(command)
	elif action == "remove":
		var index: int = int(command.get("index", objects.size()))
		objects.insert(mini(index, objects.size()), command.get("object", {}))
		_editor_redo_stack.append(command)
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	editor_help_label.text = "Undid: %s" % action
	_play_sfx(GDGameTypes.SfxCue.EDITOR_UNDO)


func _editor_redo() -> void:
	if _editor_redo_stack.is_empty():
		editor_help_label.text = "Nothing to redo."
		return
	var command: Dictionary = _editor_redo_stack.pop_back()
	var action: String = str(command.get("action", ""))
	var objects: Array = _editor_draft.get("objects", [])
	if action == "add":
		var idx: int = int(command.get("index", objects.size()))
		objects.insert(mini(idx, objects.size()), command.get("object", {}))
		_editor_history.append(command)
	elif action == "remove":
		var index: int = int(command.get("index", objects.size() - 1))
		if index >= 0 and index < objects.size():
			objects.remove_at(index)
		_editor_history.append(command)
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	editor_help_label.text = "Redid: %s" % action
	_play_sfx(GDGameTypes.SfxCue.EDITOR_REDO)


func _editor_copy() -> void:
	var world_position: Vector2 = _mouse_world_position(false)
	var objects: Array = _editor_draft.get("objects", [])
	for index: int in range(objects.size() - 1, -1, -1):
		var object_data: Variant = objects[index]
		if not (object_data is Dictionary):
			continue
		var object_position: Vector2 = _vector_from_data(object_data.get("position", [0.0, 0.0]), Vector2.ZERO)
		if object_position.distance_to(world_position) <= EDITOR_PICK_RADIUS:
			_editor_clipboard = (object_data as Dictionary).duplicate(true)
			editor_help_label.text = "Copied %s." % str(object_data.get("kind", ""))
			return
	_editor_clipboard = {}
	editor_help_label.text = "Nothing to copy at cursor."


func _editor_paste() -> void:
	if _editor_clipboard.is_empty():
		editor_help_label.text = "Clipboard is empty. Ctrl+C copies first."
		return
	var world_position: Vector2 = _mouse_world_position(true)
	var new_object: Dictionary = _editor_clipboard.duplicate(true)
	new_object["position"] = [world_position.x, world_position.y]
	if str(new_object.get("kind", "")) == "coin":
		new_object["id"] = "coin_%d" % Time.get_ticks_msec()
	_push_editor_history({"action": "add", "object": new_object.duplicate(true)})
	var objects: Array = _editor_draft.get("objects", [])
	objects.append(new_object)
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	_play_sfx(GDGameTypes.SfxCue.EDITOR_PLACE)


func _push_editor_history(command: Dictionary) -> void:
	# Store index for "add" so undo/redo preserve exact position (fixes desync on repeated identical paste)
	if str(command.get("action", "")) == "add" and not command.has("index"):
		var objects: Array = _editor_draft.get("objects", [])
		command["index"] = objects.size()   # position it will be appended to
	_editor_history.append(command.duplicate(true))
	if _editor_history.size() > EDITOR_HISTORY_LIMIT:
		_editor_history.pop_front()
	_editor_redo_stack.clear()


# Deep structural equality for two level-object dictionaries. Uses Godot's
# recursive Dictionary == comparison which is type-aware (no string coercion).
func _objects_equal(first: Variant, second: Variant) -> bool:
	if not (first is Dictionary) or not (second is Dictionary):
		return false
	return (first as Dictionary).recursive_equal(second as Dictionary, 0)


func _make_editor_object(token: String, position: Vector2) -> Dictionary:
	var pos: Array = [position.x, position.y]
	var base: Dictionary = {"position": pos, "rotation": 0.0}
	match token:
		"block":
			base.merge({"kind": "block", "size": [80.0, 80.0], "color": "456fbd"}, true)
			return base
		"moving_block":
			base.merge({"kind": "moving_block", "size": [160.0, 32.0], "color": "4f9bd6", "axis": [1.0, 0.0], "distance": 200.0, "period": 3.0}, true)
			return base
		"hazard_block":
			base.merge({"kind": "hazard_block", "size": [80.0, 80.0], "color": "8a3a4a"}, true)
			return base
		"bouncy_block":
			base.merge({"kind": "bouncy_block", "size": [120.0, 32.0], "color": "7cf5a4", "bounce_strength": 820.0}, true)
			return base
		"spike":
			base.merge({"kind": "spike"}, true)
			return base
		"oscillating_spike":
			base.merge({"kind": "oscillating_spike", "axis": [1.0, 0.0], "distance": 200.0, "period": 3.0}, true)
			return base
		"sawblade":
			base.merge({"kind": "sawblade", "radius": 32.0, "rotation_speed": 4.0}, true)
			return base
		"breakable":
			base.merge({"kind": "breakable", "size": [80.0, 80.0]}, true)
			return base
		"coin":
			base.merge({"kind": "coin", "id": "coin_%d" % Time.get_ticks_msec(), "hidden": true}, true)
			return base
		"key":
			base.merge({"kind": "key", "lock_id": "lock_%d" % Time.get_ticks_msec()}, true)
			return base
		"lock":
			base.merge({"kind": "lock", "lock_id": "lock_default"}, true)
			return base
		"finish":
			base.merge({"kind": "finish"}, true)
			return base
	# Prefixed families: pad_*, orb_*, portal_*, trigger_*
	if token.begins_with("pad_"):
		base.merge({"kind": "pad", "pad": token.trim_prefix("pad_")}, true)
		return base
	if token.begins_with("orb_"):
		base.merge({"kind": "orb", "orb": token.trim_prefix("orb_")}, true)
		return base
	if token.begins_with("portal_"):
		base.merge({"kind": "portal", "portal": token.trim_prefix("portal_")}, true)
		return base
	if token.begins_with("trigger_"):
		var trig := _make_trigger_editor_object(token.trim_prefix("trigger_"), pos)
		trig["rotation"] = 0.0
		return trig
	base["kind"] = token   # fallback
	return base


func _make_trigger_editor_object(action_token: String, pos: Array) -> Dictionary:
	var obj: Dictionary = {"kind": "trigger", "action": action_token, "position": pos}
	match action_token:
		"color":
			obj["color"] = "52d8ff"
			obj["target_id"] = ""
		"move":
			obj["move_delta"] = [0.0, -120.0]
			obj["target_id"] = ""
			obj["duration"] = 0.4
			obj["easing"] = "linear"
		"rotate":
			obj["rotate_delta"] = 1.5708
			obj["target_id"] = ""
			obj["duration"] = 0.6
			obj["easing"] = "cubic_in_out"
		"alpha":
			obj["alpha_value"] = 0.0
			obj["target_id"] = ""
			obj["duration"] = 0.4
		"toggle":
			obj["target_id"] = ""
		"shake":
			obj["shake_strength"] = 14.0
			obj["shake_duration"] = 0.25
		"pulse":
			obj["pulse_strength"] = 1.0
			obj["color"] = "ffd15f"
		"spawn":
			obj["spawn_objects"] = [{"kind": "coin", "id": "spawned_%d" % Time.get_ticks_msec(), "position": [0.0, -100.0]}]
		"camera_zoom":
			obj["zoom_factor"] = 1.5
			obj["duration"] = 0.6
			obj["easing"] = "expo_out"
		"camera_move":
			obj["camera_offset"] = [0.0, -80.0]
			obj["duration"] = 0.6
		"collision_toggle":
			obj["target_id"] = ""
		"background":
			obj["background_theme"] = "void"
			obj["duration"] = 0.6
		"speed":
			obj["speed_factor"] = 2.0
			obj["duration"] = 2.0
		"counter":
			obj["counter_name"] = "default"
	return obj


func _setup_trigger_inspector() -> void:
	_trigger_fields = VBoxContainer.new()
	_trigger_fields.name = "TriggerFields"
	_trigger_fields.add_theme_constant_override("separation", 4)
	editor_rows.add_child(_trigger_fields)
	editor_rows.move_child(_trigger_fields, editor_rows.get_children().find(editor_level_settings_button))
	_trigger_action_edit = _add_trigger_option("Action")
	for action: String in TRIGGER_ACTION_TOKENS:
		_trigger_action_edit.add_item(action.replace("_", " ").capitalize())
		_trigger_action_edit.set_item_metadata(_trigger_action_edit.get_item_count() - 1, action)
	_trigger_target_edit = _add_trigger_line_edit("Target ID")
	_trigger_value_label = _add_trigger_label("Value")
	_trigger_value_edit = _add_trigger_spin_box(-3600.0, 3600.0, 0.1)
	_trigger_vector_label = _add_trigger_label("Vector")
	_trigger_vector_row = HBoxContainer.new()
	_trigger_fields.add_child(_trigger_vector_row)
	_trigger_vector_x_edit = SpinBox.new()
	_trigger_vector_x_edit.min_value = -3600.0
	_trigger_vector_x_edit.max_value = 3600.0
	_trigger_vector_x_edit.step = 1.0
	_trigger_vector_x_edit.suffix = " X"
	_trigger_vector_row.add_child(_trigger_vector_x_edit)
	_trigger_vector_y_edit = SpinBox.new()
	_trigger_vector_y_edit.min_value = -3600.0
	_trigger_vector_y_edit.max_value = 3600.0
	_trigger_vector_y_edit.step = 1.0
	_trigger_vector_y_edit.suffix = " Y"
	_trigger_vector_row.add_child(_trigger_vector_y_edit)
	_trigger_duration_label = _add_trigger_label("Duration")
	_trigger_duration_edit = _add_trigger_spin_box(0.0, 60.0, 0.05)
	_trigger_duration_edit.suffix = " sec"
	_trigger_easing_label = _add_trigger_label("Easing")
	_trigger_easing_edit = _add_trigger_option("")
	for easing: int in range(GDGameTypes.Easing.size()):
		_trigger_easing_edit.add_item(GDGameTypes.easing_name(easing))
		_trigger_easing_edit.set_item_metadata(_trigger_easing_edit.get_item_count() - 1, easing)
	_trigger_text_label = _add_trigger_label("Name")
	_trigger_text_edit = _add_trigger_line_edit("")
	_trigger_action_edit.item_selected.connect(_on_trigger_action_selected)
	_trigger_target_edit.text_changed.connect(_on_trigger_target_changed)
	_trigger_value_edit.value_changed.connect(_on_trigger_value_changed)
	_trigger_vector_x_edit.value_changed.connect(_on_trigger_vector_changed)
	_trigger_vector_y_edit.value_changed.connect(_on_trigger_vector_changed)
	_trigger_duration_edit.value_changed.connect(_on_trigger_duration_changed)
	_trigger_easing_edit.item_selected.connect(_on_trigger_easing_selected)
	_trigger_text_edit.text_changed.connect(_on_trigger_text_changed)
	_trigger_fields.visible = false


func _add_trigger_label(text_value: String) -> Label:
	var label: Label = Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", 11)
	_trigger_fields.add_child(label)
	return label


func _add_trigger_option(label_text: String) -> OptionButton:
	if not label_text.is_empty():
		_add_trigger_label(label_text)
	var option: OptionButton = OptionButton.new()
	_trigger_fields.add_child(option)
	return option


func _add_trigger_line_edit(placeholder: String) -> LineEdit:
	var line_edit: LineEdit = LineEdit.new()
	line_edit.placeholder_text = placeholder
	_trigger_fields.add_child(line_edit)
	return line_edit


func _add_trigger_spin_box(minimum: float, maximum: float, increment: float) -> SpinBox:
	var spin_box: SpinBox = SpinBox.new()
	spin_box.min_value = minimum
	spin_box.max_value = maximum
	spin_box.step = increment
	_trigger_fields.add_child(spin_box)
	return spin_box


func _set_trigger_field_visibility(action: String) -> void:
	var target_needed: bool = action in ["color", "move", "rotate", "alpha", "toggle", "collision_toggle"]
	var vector_needed: bool = action in ["move", "camera_move"]
	var duration_needed: bool = action in ["move", "rotate", "alpha", "shake", "camera_zoom", "camera_move", "background", "speed"]
	var easing_needed: bool = action in ["move", "rotate", "alpha", "camera_zoom", "camera_move", "background"]
	var value_name: String = ""
	var text_name: String = ""
	match action:
		"rotate": value_name = "Rotation (degrees)"
		"alpha": value_name = "Opacity (0-1)"
		"pulse": value_name = "Pulse strength"
		"shake": value_name = "Shake strength"
		"camera_zoom": value_name = "Zoom factor"
		"speed": value_name = "Speed factor"
		"background": text_name = "Background theme (neon, sunset, aurora, void)"
		"counter": text_name = "Counter name"
		"spawn": text_name = "Spawn objects are edited in level JSON"
	_trigger_target_edit.visible = target_needed
	_trigger_value_label.visible = not value_name.is_empty()
	_trigger_value_edit.visible = not value_name.is_empty()
	_trigger_vector_label.visible = vector_needed
	_trigger_vector_row.visible = vector_needed
	_trigger_duration_label.visible = duration_needed
	_trigger_duration_edit.visible = duration_needed
	_trigger_easing_label.visible = easing_needed
	_trigger_easing_edit.visible = easing_needed
	_trigger_text_label.text = text_name
	_trigger_text_label.visible = not text_name.is_empty()
	_trigger_text_edit.visible = action != "spawn" and not text_name.is_empty()


func _update_trigger_inspector(trigger: Dictionary) -> void:
	var action: String = str(trigger.get("action", "color"))
	_trigger_fields.visible = true
	for item: int in range(_trigger_action_edit.get_item_count()):
		if str(_trigger_action_edit.get_item_metadata(item)) == action:
			_trigger_action_edit.select(item)
			break
	_trigger_target_edit.text = str(trigger.get("target_id", ""))
	_trigger_duration_edit.value = float(trigger.get("duration", 0.4))
	var easing: int = GDGameTypes.easing_from_token(str(trigger.get("easing", "linear")))
	for item: int in range(_trigger_easing_edit.get_item_count()):
		if int(_trigger_easing_edit.get_item_metadata(item)) == easing:
			_trigger_easing_edit.select(item)
			break
	var vector_value: Vector2 = _vector_from_data(trigger.get("move_delta", trigger.get("camera_offset", [0.0, 0.0])), Vector2.ZERO)
	_trigger_vector_x_edit.value = vector_value.x
	_trigger_vector_y_edit.value = vector_value.y
	var scalar: float = 0.0
	match action:
		"rotate": scalar = rad_to_deg(float(trigger.get("rotate_delta", 0.0)))
		"alpha": scalar = float(trigger.get("alpha_value", 0.0))
		"pulse": scalar = float(trigger.get("pulse_strength", 1.0))
		"shake": scalar = float(trigger.get("shake_strength", 14.0))
		"camera_zoom": scalar = float(trigger.get("zoom_factor", 1.0))
		"speed": scalar = float(trigger.get("speed_factor", 1.0))
	_trigger_value_edit.value = scalar
	_trigger_text_edit.text = str(trigger.get("background_theme", trigger.get("counter_name", "")))
	_set_trigger_field_visibility(action)


func _rebuild_editor_preview() -> void:
	for child: Node in world.get_children():
		child.queue_free()
	for child: Node in backdrop.get_children():
		child.queue_free()
	if triggers != null:
		triggers.clear_all()
	_apply_background_theme(GDGameTypes.background_theme_from_token(str(_editor_draft.get("background", "neon"))))
	parallax.rebuild(float(_editor_draft.get("length", 4_800.0)), 0)
	_build_level_objects(_editor_draft)
	_update_editor_inspector()
	_update_editor_overlay()   # v4.1 polish: refresh visuals after rebuild


func _update_editor_inspector() -> void:
	_editor_inspector_updating = true
	var world_position: Vector2 = _mouse_world_position(false)
	var found: Dictionary = {}
	var found_index: int = -1
	var objects: Array = _editor_draft.get("objects", [])
	for index: int in range(objects.size() - 1, -1, -1):
		var object_data: Variant = objects[index]
		if not (object_data is Dictionary):
			continue
		var object_position: Vector2 = _vector_from_data(object_data.get("position", [0.0, 0.0]), Vector2.ZERO)
		if object_position.distance_to(world_position) <= EDITOR_PICK_RADIUS:
			found = object_data
			found_index = index
			break
	if found_index >= 0:
		_editor_inspected_index = found_index
	elif _editor_inspected_index >= 0 and _editor_inspected_index < objects.size() and objects[_editor_inspected_index] is Dictionary:
		found = objects[_editor_inspected_index] as Dictionary
	if found.is_empty():
		editor_inspector_label.text = "Inspector: hover an object to edit it"
		editor_id_edit.editable = false
		editor_color_edit.disabled = true
		editor_width_edit.editable = false
		editor_height_edit.editable = false
		if _trigger_fields != null:
			_trigger_fields.visible = false
		_editor_inspector_updating = false
		return
	var kind: String = str(found.get("kind", ""))
	editor_inspector_label.text = "Inspector: %s" % kind
	editor_id_edit.editable = kind in ["block", "moving_block", "hazard_block", "bouncy_block", "coin", "key", "lock"]
	editor_color_edit.disabled = not (kind in ["block", "moving_block", "hazard_block", "bouncy_block", "trigger", "spike", "sawblade"])
	editor_width_edit.editable = kind in ["block", "moving_block", "hazard_block", "bouncy_block", "breakable"]
	editor_height_edit.editable = kind in ["block", "moving_block", "hazard_block", "bouncy_block", "breakable"]
	if editor_rotation_edit:
		editor_rotation_edit.editable = true
		editor_rotation_edit.value = float(found.get("rotation", 0.0))
	editor_id_edit.text = str(found.get("id", found.get("target_id", found.get("lock_id", ""))))
	var current_color: Color = GDGameTypes.color_from_token(str(found.get("color", "ffffff")), Color.WHITE)
	editor_color_edit.color = current_color
	var size_vec: Vector2 = _vector_from_data(found.get("size", [80.0, 80.0]), Vector2(80.0, 80.0))
	editor_width_edit.value = size_vec.x
	editor_height_edit.value = size_vec.y
	if _trigger_fields != null:
		if kind == "trigger":
			_update_trigger_inspector(found)
		else:
			_trigger_fields.visible = false
	_editor_inspector_updating = false


func _on_editor_id_changed(new_text: String) -> void:
	if _editor_inspector_updating:
		return
	_apply_editor_inspector_change({"id_value": new_text})


func _on_editor_color_changed(color: Color) -> void:
	if _editor_inspector_updating:
		return
	_apply_editor_inspector_change({"color": GDGameTypes.color_to_hex(color)})


func _on_editor_width_changed(value: float) -> void:
	if _editor_inspector_updating:
		return
	_apply_editor_inspector_change({"size_x": value})


func _on_editor_height_changed(value: float) -> void:
	if _editor_inspector_updating:
		return
	_apply_editor_inspector_change({"size_y": value})

func _on_editor_rotation_changed(value: float) -> void:
	if _editor_inspector_updating:
		return
	_apply_editor_inspector_change({"rotation": value})


func _on_trigger_action_selected(index: int) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"action": str(_trigger_action_edit.get_item_metadata(index))})


func _on_trigger_target_changed(value: String) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"target_id": value.strip_edges()})


func _on_trigger_value_changed(value: float) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"trigger_value": value})


func _on_trigger_vector_changed(_value: float) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"trigger_vector": [_trigger_vector_x_edit.value, _trigger_vector_y_edit.value]})


func _on_trigger_duration_changed(value: float) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"duration": value})


func _on_trigger_easing_selected(index: int) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"easing": GDGameTypes.easing_token(int(_trigger_easing_edit.get_item_metadata(index)))})


func _on_trigger_text_changed(value: String) -> void:
	if not _editor_inspector_updating:
		_apply_editor_inspector_change({"trigger_text": value.strip_edges()})


func _apply_editor_inspector_change(change: Dictionary) -> void:
	var objects: Array = _editor_draft.get("objects", [])
	var index: int = _editor_inspected_index
	if index < 0 or index >= objects.size() or not (objects[index] is Dictionary):
		return
	var target: Dictionary = objects[index] as Dictionary
	if change.has("color"):
		target["color"] = str(change["color"])
	if change.has("size_x") or change.has("size_y"):
		var current_size: Vector2 = _vector_from_data(target.get("size", [80.0, 80.0]), Vector2(80.0, 80.0))
		if change.has("size_x"):
			current_size.x = float(change["size_x"])
		if change.has("size_y"):
			current_size.y = float(change["size_y"])
		target["size"] = [current_size.x, current_size.y]
	if change.has("id_value"):
		var id_value: String = str(change["id_value"]).strip_edges()
		if target.has("target_id"):
			target["target_id"] = id_value
		elif target.has("lock_id"):
			target["lock_id"] = id_value
		else:
			target["id"] = id_value
	if change.has("rotation"):
		target["rotation"] = float(change["rotation"])
	if str(target.get("kind", "")) == "trigger":
		_apply_trigger_inspector_change(target, change)
	objects[index] = target
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	return

func _apply_trigger_inspector_change(target: Dictionary, change: Dictionary) -> void:
	var action: String = str(change.get("action", target.get("action", "color")))
	if change.has("action"):
		target["action"] = action
	if change.has("target_id"):
		target["target_id"] = str(change["target_id"])
	if change.has("duration"):
		target["duration"] = float(change["duration"])
	if change.has("easing"):
		target["easing"] = str(change["easing"])
	if change.has("trigger_vector"):
		if action == "move":
			target["move_delta"] = change["trigger_vector"]
		elif action == "camera_move":
			target["camera_offset"] = change["trigger_vector"]
	if change.has("trigger_value"):
		var value: float = float(change["trigger_value"])
		match action:
			"rotate": target["rotate_delta"] = deg_to_rad(value)
			"alpha": target["alpha_value"] = clampf(value, 0.0, 1.0)
			"pulse": target["pulse_strength"] = maxf(value, 0.0)
			"shake": target["shake_strength"] = maxf(value, 0.0)
			"camera_zoom": target["zoom_factor"] = maxf(value, 0.05)
			"speed": target["speed_factor"] = maxf(value, 0.05)
	if change.has("trigger_text"):
		if action == "background":
			target["background_theme"] = str(change["trigger_text"]).to_lower()
		elif action == "counter":
			target["counter_name"] = str(change["trigger_text"])


# ─── Level settings dialog ──────────────────────────────────────────────────

func _open_level_settings() -> void:
	level_settings_layer.visible = true
	ls_bpm_edit.value = float(_editor_draft.get("bpm", 140.0))
	ls_length_edit.value = float(_editor_draft.get("length", 4_800.0))
	var theme: int = GDGameTypes.background_theme_from_token(str(_editor_draft.get("background", "neon")))
	for i: int in range(ls_theme_option.get_item_count()):
		if int(ls_theme_option.get_item_metadata(i)) == theme:
			ls_theme_option.select(i)
			break
	var diff: String = str(_editor_draft.get("difficulty", "easy"))
	for i: int in range(ls_difficulty_option.get_item_count()):
		if str(ls_difficulty_option.get_item_metadata(i)) == diff:
			ls_difficulty_option.select(i)
			break


func _apply_level_settings() -> void:
	_editor_draft["bpm"] = float(ls_bpm_edit.value)
	_editor_draft["length"] = float(ls_length_edit.value)
	var theme_idx: int = ls_theme_option.get_selected()
	if theme_idx >= 0:
		var theme: int = int(ls_theme_option.get_item_metadata(theme_idx))
		_editor_draft["background"] = GDGameTypes.background_theme_token(theme)
	var diff_idx: int = ls_difficulty_option.get_selected()
	if diff_idx >= 0:
		_editor_draft["difficulty"] = str(ls_difficulty_option.get_item_metadata(diff_idx))
	level_settings_layer.visible = false
	_rebuild_editor_preview()


func _cancel_level_settings() -> void:
	level_settings_layer.visible = false


# ─── Utilities ──────────────────────────────────────────────────────────────

func _vector_from_data(data: Variant, fallback: Vector2) -> Vector2:
	if data is Array and data.size() >= 2:
		return Vector2(float(data[0]), float(data[1]))
	return fallback


# ─── v4.1 GD Alignment: Rotation + Multi-Select + Drag + Selection Visuals ──

func _editor_rotate_selected(delta_rot: float) -> void:
	if _editor_selected_indices.is_empty():
		return
	var objects: Array = _editor_draft.get("objects", [])
	var rotated: Array = []
	for idx in _editor_selected_indices:
		if idx >= 0 and idx < objects.size():
			var obj: Dictionary = objects[idx]
			var cur_rot: float = float(obj.get("rotation", 0.0))
			obj["rotation"] = cur_rot + delta_rot
			rotated.append(obj.duplicate(true))
	if rotated.size() > 0:
		_push_editor_history({"action": "rotate_multi", "objects": rotated})
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	_update_editor_inspector()
	_play_sfx(GDGameTypes.SfxCue.EDITOR_PLACE)

func _editor_select_all() -> void:
	_editor_selected_indices.clear()
	var objects: Array = _editor_draft.get("objects", [])
	for i in range(objects.size()):
		_editor_selected_indices.append(i)
	_update_editor_inspector()

func _editor_delete_selected() -> void:
	if _editor_selected_indices.is_empty():
		return
	var objects: Array = _editor_draft.get("objects", [])
	var sorted = _editor_selected_indices.duplicate()
	sorted.sort()
	sorted.reverse()

	var removed_objects: Array = []
	for idx in sorted:
		if idx >= 0 and idx < objects.size():
			removed_objects.append(objects[idx].duplicate(true))
			objects.remove_at(idx)

	if removed_objects.size() > 0:
		_push_editor_history({"action": "remove_multi", "objects": removed_objects})

	_editor_draft["objects"] = objects
	_editor_selected_indices.clear()
	_rebuild_editor_preview()
	_play_sfx(GDGameTypes.SfxCue.EDITOR_REMOVE)

func _editor_try_start_drag_or_select(world_pos: Vector2) -> void:
	var objects: Array = _editor_draft.get("objects", [])
	var clicked_index: int = -1

	for i in range(objects.size() - 1, -1, -1):
		var obj: Dictionary = objects[i]
		var obj_pos: Vector2 = _vector_from_data(obj.get("position", [0,0]), Vector2.ZERO)
		var kind: String = str(obj.get("kind", ""))
		var obj_size: Vector2 = _vector_from_data(obj.get("size", [80,80]), Vector2(80,80))
		var radius: float = float(obj.get("radius", 32.0))

		var dist := world_pos.distance_to(obj_pos)
		var hit := false
		if kind in ["block", "moving_block", "hazard_block", "bouncy_block", "breakable"]:
			var half := obj_size / 2.0
			hit = abs(world_pos.x - obj_pos.x) < half.x + 8 and abs(world_pos.y - obj_pos.y) < half.y + 8
		elif kind in ["spike", "sawblade", "coin", "trigger", "teleport_pad", "wind_zone", "path_spike"]:
			hit = dist < max(radius + 14, 34)
		else:
			hit = dist < EDITOR_PICK_RADIUS

		if hit:
			clicked_index = i
			break

	var ctrl := Input.is_key_pressed(KEY_CTRL)

	if clicked_index == -1:
		# Start box selection
		if not ctrl:
			_editor_selected_indices.clear()
		_editor_is_drag_selecting = true
		_editor_drag_select_start = world_pos
		_editor_is_dragging = false
		_update_editor_inspector()
		_update_editor_overlay()
		return

	# Object clicked
	if ctrl:
		if _editor_selected_indices.has(clicked_index):
			_editor_selected_indices.erase(clicked_index)
		else:
			_editor_selected_indices.append(clicked_index)
	else:
		if not _editor_selected_indices.has(clicked_index):
			_editor_selected_indices = [clicked_index]

	_editor_is_dragging = true
	_editor_is_drag_selecting = false
	_editor_drag_start_world = world_pos
	_editor_drag_offset = world_pos - _vector_from_data(objects[clicked_index].get("position", [0,0]), Vector2.ZERO)
	_update_editor_inspector()
	_update_editor_overlay()

func _editor_perform_drag(world_pos: Vector2) -> void:
	if not _editor_is_dragging or _editor_selected_indices.is_empty():
		return

	var objects: Array = _editor_draft.get("objects", [])
	var delta: Vector2 = world_pos - _editor_drag_start_world

	for idx in _editor_selected_indices:
		if idx < 0 or idx >= objects.size():
			continue
		var obj: Dictionary = objects[idx]
		var old_pos: Vector2 = _vector_from_data(obj.get("position", [0,0]), Vector2.ZERO)
		var new_pos := old_pos + delta
		new_pos = Vector2(round(new_pos.x / 20.0) * 20.0, round(new_pos.y / 20.0) * 20.0)
		obj["position"] = [new_pos.x, new_pos.y]

	_editor_draft["objects"] = objects
	_rebuild_editor_preview()

func _editor_end_drag() -> void:
	if not _editor_is_dragging:
		return
	_editor_is_dragging = false

	if _editor_selected_indices.size() > 0:
		var objects: Array = _editor_draft.get("objects", [])
		var moved: Array = []
		for idx in _editor_selected_indices:
			if idx >= 0 and idx < objects.size():
				moved.append(objects[idx].duplicate(true))
		if moved.size() > 0:
			_push_editor_history({"action": "move_multi", "objects": moved})

	_rebuild_editor_preview()
	_update_editor_overlay()

# === v4.1 New Editor Helpers (rubber band + zoom + duplicate) ===

func _update_drag_select(current_world: Vector2) -> void:
	if not _editor_is_drag_selecting:
		return
	var objects: Array = _editor_draft.get("objects", [])
	var min_x := minf(_editor_drag_select_start.x, current_world.x)
	var max_x := maxf(_editor_drag_select_start.x, current_world.x)
	var min_y := minf(_editor_drag_select_start.y, current_world.y)
	var max_y := maxf(_editor_drag_select_start.y, current_world.y)

	_editor_selected_indices.clear()
	for i in range(objects.size()):
		var obj: Dictionary = objects[i]
		var p := _vector_from_data(obj.get("position", [0,0]), Vector2.ZERO)
		if p.x >= min_x and p.x <= max_x and p.y >= min_y and p.y <= max_y:
			_editor_selected_indices.append(i)
	_update_editor_overlay()

func _editor_end_drag_select() -> void:
	_editor_is_drag_selecting = false
	_update_editor_inspector()
	_update_editor_overlay()

func _editor_adjust_zoom(factor: float) -> void:
	_editor_zoom = clampf(_editor_zoom * factor, 0.3, 4.0)
	camera_2d.zoom = Vector2.ONE * _editor_zoom
	_update_editor_overlay()

func _editor_duplicate_selected() -> void:
	if _editor_selected_indices.is_empty():
		return
	var objects: Array = _editor_draft.get("objects", [])
	var new_objs: Array = []
	for idx in _editor_selected_indices:
		if idx >= 0 and idx < objects.size():
			var copy := (objects[idx] as Dictionary).duplicate(true)
			# Offset slightly
			var pos := _vector_from_data(copy.get("position", [0,0]), Vector2.ZERO)
			pos += Vector2(40, 20)
			copy["position"] = [pos.x, pos.y]
			if copy.has("id"):
				copy["id"] = str(copy["id"]) + "_dup"
			new_objs.append(copy)
			objects.append(copy)
	_editor_draft["objects"] = objects
	_editor_selected_indices = []
	for i in range(objects.size() - new_objs.size(), objects.size()):
		_editor_selected_indices.append(i)
	_push_editor_history({"action": "duplicate_multi", "objects": new_objs.duplicate(true)})
	_rebuild_editor_preview()
	_play_sfx(GDGameTypes.SfxCue.EDITOR_PLACE)

# === v4.1 Full Draggable Rotation Handle (modern professional gizmo) ===

func _try_start_rotation_drag(world_pos: Vector2) -> bool:
	if _editor_selected_indices.size() != 1:
		_editor_rotation_handle_active = false
		return false
	var objects: Array = _editor_draft.get("objects", [])
	var idx: int = _editor_selected_indices[0]
	if idx < 0 or idx >= objects.size():
		return false
	var obj: Dictionary = objects[idx]
	var pos: Vector2 = _vector_from_data(obj.get("position", [0,0]), Vector2.ZERO)
	var rot: float = float(obj.get("rotation", 0.0))
	var kind: String = str(obj.get("kind", ""))
	if kind == "finish":
		return false

	var dir := Vector2.RIGHT.rotated(rot)
	var handle_pos := pos + dir * 46.0
	if world_pos.distance_to(handle_pos) <= 18.0:
		_editor_rotation_handle_active = true
		_editor_rotation_object_index = idx
		_editor_rotation_start_angle = world_pos.angle_to_point(pos)
		_editor_rotation_initial_rot = rot
		_editor_last_rot_handle_hit = idx
		_update_editor_overlay()
		return true
	return false

func _perform_rotation_drag(world_pos: Vector2) -> void:
	if not _editor_rotation_handle_active or _editor_rotation_object_index < 0:
		return
	var objects: Array = _editor_draft.get("objects", [])
	if _editor_rotation_object_index >= objects.size():
		return
	var obj: Dictionary = objects[_editor_rotation_object_index]
	var pos: Vector2 = _vector_from_data(obj.get("position", [0,0]), Vector2.ZERO)
	var new_angle := world_pos.angle_to_point(pos)
	var delta := new_angle - _editor_rotation_start_angle
	var new_rot := _editor_rotation_initial_rot + delta
	# Snap to 15° increments for professional feel (like GD)
	new_rot = round(new_rot / (PI / 12.0)) * (PI / 12.0)
	obj["rotation"] = new_rot
	_editor_draft["objects"] = objects
	_rebuild_editor_preview()
	# Update inspector live
	if editor_rotation_edit:
		editor_rotation_edit.value = rad_to_deg(new_rot)

func _end_rotation_drag() -> void:
	if not _editor_rotation_handle_active:
		return
	if _editor_rotation_object_index >= 0:
		var objects: Array = _editor_draft.get("objects", [])
		if _editor_rotation_object_index < objects.size():
			var obj: Dictionary = objects[_editor_rotation_object_index]
			_push_editor_history({"action": "rotate", "index": _editor_rotation_object_index, "object": obj.duplicate(true)})
	_play_sfx(GDGameTypes.SfxCue.EDITOR_PLACE)
	_editor_rotation_handle_active = false
	_editor_rotation_object_index = -1
	_editor_last_rot_handle_hit = -1
	_update_editor_overlay()
