class_name KeyLock
extends Area2D
@export var lock_id: String = ""
@export var is_key: bool = false
signal key_picked_up(lock_id: String)
signal lock_opened(lock_id: String)
var _used: bool = false
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _on_body_entered(body: Node) -> void:
	if _used or not (body is DashPlayer): return
	_used = true
	if is_key:
		key_picked_up.emit(lock_id)
	else:
		lock_opened.emit(lock_id)
	queue_free()
