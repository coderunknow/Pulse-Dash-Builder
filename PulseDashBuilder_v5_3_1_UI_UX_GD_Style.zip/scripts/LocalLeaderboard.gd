## LocalLeaderboard.gd — Top-10 local leaderboard per level with persistent JSON storage.
## Stores time_ms, coins, deaths, and timestamp per entry. Sorted by time ascending.
## Robust save/load handles missing/corrupt files gracefully.
##
## Usage: instantiate in Main scene. Call submit_score() after level completion,
## get_top_scores() for leaderboard display.

extends Node

## Path to the persistent leaderboard save file.
const SAVE_PATH: String = "user://leaderboard_save.json"

## Maximum entries per level.
const MAX_ENTRIES: int = 10

## Internal data: { level_id: [ {time_ms, coins, deaths, timestamp}, ... ] }
var _data: Dictionary = {}

## Whether the save file has been loaded this session.
var _loaded: bool = false


func _ready() -> void:
	_safe_load()


## Submit a score for a level. Inserts into top-10 sorted by time_ms ascending.
## Returns the 1-based rank if the score made the top 10, or 0 if not.
func submit_score(level_id: String, time_ms: int, coins: int = 0, deaths: int = 0) -> int:
	_ensure_loaded()
	var entry: Dictionary = {
		"time_ms": time_ms,
		"coins": coins,
		"deaths": deaths,
		"timestamp": Time.get_unix_time_from_system(),
	}
	if not _data.has(level_id):
		_data[level_id] = []
	var scores: Array = _data[level_id] as Array
	scores.append(entry)
	_sort_scores(scores)
	# Cap at MAX_ENTRIES — drop worst (last)
	if scores.size() > MAX_ENTRIES:
		scores.resize(MAX_ENTRIES)
	_data[level_id] = scores
	_safe_save(_data)
	# Find rank
	for i: int in range(scores.size()):
		var s: Dictionary = scores[i] as Dictionary
		if s["timestamp"] == entry["timestamp"] and s["time_ms"] == time_ms:
			return i + 1
	return 0


## Get the top N scores for a level, each with a rank field.
func get_top_scores(level_id: String, limit: int = 10) -> Array[Dictionary]:
	_ensure_loaded()
	var result: Array[Dictionary] = []
	if not _data.has(level_id):
		return result
	var scores: Array = _data[level_id] as Array
	var count: int = mini(scores.size(), limit)
	for i: int in range(count):
		var s: Dictionary = (scores[i] as Dictionary).duplicate()
		s["rank"] = i + 1
		result.append(s)
	return result


## Get the single best (fastest) entry for a level, or empty Dictionary.
func get_best(level_id: String) -> Dictionary:
	_ensure_loaded()
	if not _data.has(level_id):
		return {}
	var scores: Array = _data[level_id] as Array
	if scores.is_empty():
		return {}
	return (scores[0] as Dictionary).duplicate()


## Clear all scores for a specific level.
func clear_level(level_id: String) -> void:
	_ensure_loaded()
	_data.erase(level_id)
	_safe_save(_data)


## Returns true if the level has any recorded scores.
func has_scores(level_id: String) -> bool:
	_ensure_loaded()
	if not _data.has(level_id):
		return false
	var scores: Array = _data[level_id] as Array
	return not scores.is_empty()


## Get the number of stored levels.
func level_count() -> int:
	_ensure_loaded()
	return _data.size()


# -- Private helpers --

## Sort scores array by time_ms ascending, then by coins descending, then by deaths ascending.
func _sort_scores(scores: Array) -> void:
	scores.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var ta: int = int(a.get("time_ms", 999999999))
		var tb: int = int(b.get("time_ms", 999999999))
		if ta != tb:
			return ta < tb
		# Tiebreaker: more coins = better
		var ca: int = int(a.get("coins", 0))
		var cb: int = int(b.get("coins", 0))
		if ca != cb:
			return ca > cb
		# Tiebreaker: fewer deaths = better
		var da: int = int(a.get("deaths", 999))
		var db: int = int(b.get("deaths", 999))
		return da < db
	)


## Robust load — handles missing, corrupt, or empty files.
func _safe_load() -> void:
	_loaded = true
	_data = {}
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var raw: String = file.get_as_text()
	file.close()
	if raw.strip_edges().is_empty():
		return
	var json: JSON = JSON.new()
	if json.parse(raw) != OK or not (json.data is Dictionary):
		return
	_data = json.data as Dictionary


## Save data to disk. Fails silently on write error.
func _safe_save(data: Dictionary) -> void:
	var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(data, "\t"))
	file.close()


## Ensure data is loaded before access.
func _ensure_loaded() -> void:
	if not _loaded:
		_safe_load()


## v5 UPGRADE: New script — top-10 local leaderboard per level with persistent
## JSON storage, time/coins/deaths sorting, and robust save/load.
