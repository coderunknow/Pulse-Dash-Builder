## v5 UPGRADE: Added visual trigger wiring system. When a trigger is selected,
## the overlay now auto-resolves target_id and target_group references against
## all level objects and draws glowing neon-cyan connection lines with arrowheads.
## The wiring is computed from the raw object data (no pre-computed lines array
## needed). Toggle via _show_trigger_wiring. Existing _draw_trigger_lines() and
## pre-computed line data are preserved for backward compatibility.

class_name EditorOverlay
extends Node2D

## Professional, clean, modern editor overlay for Geometry Dash-style editing.

@export var grid_color: Color = Color(0.28, 0.58, 0.92, 0.14)
@export var selection_color: Color = Color(0.12, 0.78, 0.96, 0.92)
@export var rotation_handle_color: Color = Color(1.0, 0.85, 0.2, 1.0)
@export var trigger_line_color: Color = Color(1.0, 0.58, 0.15, 0.88)

## v5: Neon cyan color for auto-resolved trigger wiring lines.
@export var wiring_color: Color = Color(0.0, 1.0, 1.0, 0.92)
## v5: Glow color (wider, semi-transparent) behind the wiring lines.
@export var wiring_glow_color: Color = Color(0.0, 1.0, 1.0, 0.18)

var _objects: Array = []
var _selected: Array[int] = []
var _trigger_lines: Array = []
var show_grid: bool = true
var show_trigger_lines: bool = true

## v5: When true, automatically draws glowing wiring lines from any selected
## trigger to its target objects (resolved by target_id / target_group).
var _show_trigger_wiring: bool = true

var _rot_radius: float = 46.0

# v5: Reusable array for resolved wiring targets (avoid per-frame alloc)
var _wiring_targets: Array[int] = []

# Rubber-band drag box state (for modern selection UX)
var _drag_box_active: bool = false
var _drag_start: Vector2 = Vector2.ZERO
var _drag_current: Vector2 = Vector2.ZERO

# Live rotation handle highlight (index of object being rotated)
var _active_rot_handle: int = -1

func _ready() -> void:
	z_index = 280

func update_data(objects: Array, selected: Array[int], lines: Array = [], active_rot: int = -1) -> void:
	_objects = objects
	_selected = selected.duplicate()
	_trigger_lines = lines.duplicate()
	_active_rot_handle = active_rot

func _draw() -> void:
	if show_grid:
		_draw_grid()
	_draw_selections()
	_draw_rotation_handles()
	if show_trigger_lines:
		_draw_trigger_lines()
	if _show_trigger_wiring:
		_draw_auto_trigger_wiring()
	if _drag_box_active:
		_draw_drag_box()


## v5: Auto-resolve trigger wiring from raw object data.
## For every selected trigger object, find all objects whose "id" matches the
## trigger's "target_id" or whose "groups" array contains the trigger's
## "target_group". Draws a glowing straight line with arrowhead at the target.
## Uses additive-blend-style neon cyan for visual clarity.
func _draw_auto_trigger_wiring() -> void:
	# Build id -> index map once per frame (reused across all selected triggers)
	var id_map: Dictionary = {}
	var obj_count: int = _objects.size()
	for i: int in range(obj_count):
		var obj_v: Variant = _objects[i]
		if not (obj_v is Dictionary):
			continue
		var oid: String = str(obj_v.get("id", "")).strip_edges()
		if not oid.is_empty():
			id_map[oid] = i

	# For each selected trigger, resolve and draw wiring
	for sel_idx: int in _selected:
		if sel_idx < 0 or sel_idx >= obj_count:
			continue
		var sel_obj: Variant = _objects[sel_idx]
		if not (sel_obj is Dictionary):
			continue
		var sel_dict: Dictionary = sel_obj as Dictionary
		var kind: String = str(sel_dict.get("kind", "")).to_lower()
		if kind != "trigger":
			continue

		var trigger_pos: Vector2 = _vec2(sel_dict.get("position", [0, 0]))
		var target_id: String = str(sel_dict.get("target_id", "")).strip_edges()
		var target_group: String = str(sel_dict.get("target_group", "")).strip_edges()

		# Collect target indices for this trigger
		_wiring_targets.clear()

		# Resolve by target_id
		if not target_id.is_empty():
			var found_idx: Variant = id_map.get(target_id, -1)
			if found_idx is int and found_idx >= 0:
				_wiring_targets.append(found_idx)

		# Resolve by target_group (match objects whose "groups" array contains it)
		if not target_group.is_empty():
			for j: int in range(obj_count):
				var obj_v2: Variant = _objects[j]
				if not (obj_v2 is Dictionary):
					continue
				var groups_v: Variant = obj_v2.get("groups", [])
				if groups_v is Array:
					for g: Variant in groups_v:
						if str(g) == target_group and j != sel_idx:
							if not _wiring_targets.has(j):
								_wiring_targets.append(j)

		# Draw wiring lines to each resolved target
		for t_idx: int in _wiring_targets:
			if t_idx < 0 or t_idx >= obj_count:
				continue
			var target_obj: Variant = _objects[t_idx]
			if not (target_obj is Dictionary):
				continue
			var target_pos: Vector2 = _vec2(target_obj.get("position", [0, 0]))

			# Draw glow (wider, semi-transparent)
			draw_line(trigger_pos, target_pos, wiring_glow_color, 6.0)
			# Draw main line
			draw_line(trigger_pos, target_pos, wiring_color, 2.0)

			# Draw arrowhead at target
			var diff: Vector2 = target_pos - trigger_pos
			if diff.length() > 1.0:
				var dir: Vector2 = diff.normalized()
				var ar: Vector2 = target_pos - dir * 5.0
				var sd: float = 9.0
				draw_line(ar, ar + dir.rotated(2.55) * sd, wiring_color, 2.0)
				draw_line(ar, ar + dir.rotated(-2.55) * sd, wiring_color, 2.0)

func _draw_grid() -> void:
	var cam := get_viewport().get_camera_2d()
	var cam_pos: Vector2 = cam.global_position if cam else Vector2.ZERO
	var zoom: float = cam.zoom.x if cam else 1.0
	var view_sz: Vector2 = get_viewport_rect().size / zoom * 2.3

	var half_w: float = view_sz.x * 0.5
	var half_h: float = view_sz.y * 0.5
	var sx: float = float(floor((cam_pos.x - half_w) / 20.0) * 20.0)
	var sy: float = float(floor((cam_pos.y - half_h) / 20.0) * 20.0)
	var ex: float = sx + view_sz.x + 100.0
	var ey: float = sy + view_sz.y + 100.0

	var light := grid_color
	var major := grid_color
	major.a = 0.28

	for x in range(int(sx), int(ex), 20):
		draw_line(Vector2(x, sy), Vector2(x, ey), light, 1.0)
	for y in range(int(sy), int(ey), 20):
		draw_line(Vector2(sx, y), Vector2(ex, y), light, 1.0)

	for x in range(int(sx), int(ex), 100):
		draw_line(Vector2(x, sy), Vector2(x, ey), major, 1.6)
	for y in range(int(sy), int(ey), 100):
		draw_line(Vector2(sx, y), Vector2(ex, y), major, 1.6)

func _draw_selections() -> void:
	for idx in _selected:
		if idx < 0 or idx >= _objects.size():
			continue
		var obj: Dictionary = _objects[idx]
		var pos: Vector2 = _vec2(obj.get("position", [0, 0]))
		var kind := str(obj.get("kind", ""))
		var obj_sz := _vec2(obj.get("size", [80, 80]))
		var rad := float(obj.get("radius", 32.0))

		var pts := PackedVector2Array()
		var half := obj_sz * 0.5
		var expand := 9.0

		if kind in ["block", "moving_block", "hazard_block", "bouncy_block", "breakable"]:
			pts = PackedVector2Array([
				pos + Vector2(-half.x - expand, -half.y - expand),
				pos + Vector2( half.x + expand, -half.y - expand),
				pos + Vector2( half.x + expand,  half.y + expand),
				pos + Vector2(-half.x - expand,  half.y + expand)
			])
		else:
			var r := rad + 19.0
			for i in 52:
				var a := TAU * float(i) / 52.0
				pts.append(pos + Vector2(cos(a), sin(a)) * r)

		if pts.size() < 3:
			continue

		var glow := selection_color
		glow.a = 0.16
		draw_polyline(pts + PackedVector2Array([pts[0]]), glow, 8.0)
		draw_polyline(pts + PackedVector2Array([pts[0]]), selection_color, 2.6)

func _draw_rotation_handles() -> void:
	for idx in _selected:
		if idx < 0 or idx >= _objects.size():
			continue
		var obj: Dictionary = _objects[idx]
		var pos: Vector2 = _vec2(obj.get("position", [0, 0]))
		var kind := str(obj.get("kind", ""))
		var rot := float(obj.get("rotation", 0.0))

		if kind == "finish":
			continue

		var is_active := (idx == _active_rot_handle)
		var dir := Vector2.RIGHT.rotated(rot)
		var hp := pos + dir * _rot_radius

		var line_col := rotation_handle_color
		var circle_col := rotation_handle_color
		var inner_col := Color(1, 1, 1, 0.9)
		var line_w := 2.0
		var outer_r := 10.0
		var inner_r := 8.5

		if is_active:
			line_col = Color(1.0, 0.95, 0.3, 1.0)
			circle_col = Color(1.0, 0.92, 0.25, 1.0)
			inner_col = Color(1, 1, 1, 1.0)
			line_w = 2.8
			outer_r = 11.5
			inner_r = 9.5

		draw_line(pos, hp, line_col, line_w)
		# Shadow ring
		draw_circle(hp, outer_r + 1.5, Color(0.02, 0.02, 0.04, 0.55))
		draw_circle(hp, outer_r, Color(0.06, 0.06, 0.08, 0.85))
		draw_circle(hp, inner_r, circle_col)
		draw_circle(hp, inner_r * 0.56, inner_col)

func _draw_trigger_lines() -> void:
	for ln_variant in _trigger_lines:
		if not (ln_variant is Dictionary):
			continue
		var ln: Dictionary = ln_variant as Dictionary
		var from_vec: Vector2 = _vec2(ln.get("from", [0, 0]))
		var to_vec: Vector2 = _vec2(ln.get("to", [0, 0]))

		var dir: Vector2 = (to_vec - from_vec).normalized()
		var lenv: float = from_vec.distance_to(to_vec)
		var cur: float = 0.0
		var dlen: float = 13.0
		var gap: float = 7.0

		while cur < lenv:
			var p1: Vector2 = from_vec + dir * cur
			var p2: Vector2 = from_vec + dir * minf(cur + dlen, lenv)
			draw_line(p1, p2, trigger_line_color, 2.3)
			cur += dlen + gap

		# Draw arrow head at the end
		var ar: Vector2 = to_vec - dir * 5.0
		var sd: float = 8.5
		draw_line(ar, ar + dir.rotated(2.55) * sd, trigger_line_color, 2.0)
		draw_line(ar, ar + dir.rotated(-2.55) * sd, trigger_line_color, 2.0)

func _vec2(data: Variant) -> Vector2:
	if data is Array and data.size() >= 2:
		return Vector2(float(data[0]), float(data[1]))
	if data is Vector2 or data is Vector2i:
		return data
	return Vector2.ZERO

# Public API for rubber-band box (modern multi-select UX)
func set_drag_selection(active: bool, start_pos: Vector2 = Vector2.ZERO, current_pos: Vector2 = Vector2.ZERO) -> void:
	_drag_box_active = active
	_drag_start = start_pos
	_drag_current = current_pos
	queue_redraw()

func _draw_drag_box() -> void:
	if not _drag_box_active:
		return
	var minp: Vector2 = Vector2(minf(_drag_start.x, _drag_current.x), minf(_drag_start.y, _drag_current.y))
	var maxp: Vector2 = Vector2(maxf(_drag_start.x, _drag_current.x), maxf(_drag_start.y, _drag_current.y))
	var rsize: Vector2 = maxp - minp
	if rsize.x < 2.0 or rsize.y < 2.0:
		return

	# Subtle modern fill
	var fill_col := Color(0.10, 0.72, 0.95, 0.09)
	draw_rect(Rect2(minp, rsize), fill_col, true)

	# Glow outer
	var glow := Color(0.12, 0.78, 0.96, 0.18)
	draw_rect(Rect2(minp - Vector2(3,3), rsize + Vector2(6,6)), glow, false, 6.0)

	# Sharp dashed border (professional look)
	var border := Color(0.12, 0.78, 0.96, 0.95)
	_draw_dashed_rect(Rect2(minp, rsize), border, 1.8, 7.0, 3.5)

func _draw_dashed_rect(rect: Rect2, col: Color, width: float, dash: float, gap: float) -> void:
	var tl := rect.position
	var tr := Vector2(rect.position.x + rect.size.x, rect.position.y)
	var br := rect.position + rect.size
	var bl := Vector2(rect.position.x, rect.position.y + rect.size.y)
	_draw_dashed_line(tl, tr, col, width, dash, gap)
	_draw_dashed_line(tr, br, col, width, dash, gap)
	_draw_dashed_line(br, bl, col, width, dash, gap)
	_draw_dashed_line(bl, tl, col, width, dash, gap)

func _draw_dashed_line(from: Vector2, to: Vector2, col: Color, width: float, dash_len: float, gap_len: float) -> void:
	var dir: Vector2 = (to - from).normalized()
	var total_len: float = from.distance_to(to)
	var cur: float = 0.0
	while cur < total_len:
		var p1: Vector2 = from + dir * cur
		var p2: Vector2 = from + dir * minf(cur + dash_len, total_len)
		draw_line(p1, p2, col, width)
		cur += dash_len + gap_len
