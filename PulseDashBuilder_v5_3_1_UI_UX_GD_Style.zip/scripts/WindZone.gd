extends Area2D
@export var wind_force: Vector2 = Vector2(0, -400)
func _ready() -> void:
	body_entered.connect(_on_entered)
	body_exited.connect(_on_exited)
func _on_entered(body: Node) -> void:
	if body is DashPlayer:
		body.set_meta("wind_force", wind_force)
func _on_exited(body: Node) -> void:
	if body is DashPlayer:
		body.remove_meta("wind_force")
