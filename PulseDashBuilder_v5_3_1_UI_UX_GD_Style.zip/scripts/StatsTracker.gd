## GDStatsTracker — Autoload singleton tracking per-level and global stats.
class_name GDStatsTracker
extends Node

const SAVE_PATH: String = "user://geometry_dash_clone/stats.json"

var total_play_time: float = 0.0
var total_completions: int = 0
var total_deaths: int = 0
var total_jumps: int = 0
var total_coins: int = 0
var total_levels_played: int = 0

var _per_level: Dictionary = {}  # level_id -> {attempts, best, completions, deaths}
var _current_level_id: String = ""
var _run_start_time: float = 0.0
var _current_best: int = 0

func _ready() -> void:
	_load()

func _load() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var json := JSON.new()
	if json.parse(f.get_as_text()) == OK and json.data is Dictionary:
		var d: Dictionary = json.data
		total_play_time = float(d.get("total_play_time", 0))
		total_completions = int(d.get("total_completions", 0))
		total_deaths = int(d.get("total_deaths", 0))
		total_jumps = int(d.get("total_jumps", 0))
		total_coins = int(d.get("total_coins", 0))
		total_levels_played = int(d.get("total_levels_played", 0))
		_per_level = d.get("per_level", {})
	f.close()

func _save() -> void:
	DirAccess.make_dir_recursive_absolute("user://geometry_dash_clone/")
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	var d := {
		"total_play_time": total_play_time,
		"total_completions": total_completions,
		"total_deaths": total_deaths,
		"total_jumps": total_jumps,
		"total_coins": total_coins,
		"total_levels_played": total_levels_played,
		"per_level": _per_level,
	}
	f.store_string(JSON.stringify(d))
	f.close()

func start_run(level_id: String) -> void:
	_current_level_id = level_id
	_run_start_time = Time.get_ticks_msec() / 1000.0
	_current_best = 0
	if not _per_level.has(level_id):
		_per_level[level_id] = {"attempts": 0, "best": 0, "completions": 0, "deaths": 0}
		total_levels_played += 1
	_per_level[level_id]["attempts"] = int(_per_level[level_id].get("attempts", 0)) + 1

func end_run() -> void:
	if _run_start_time > 0.0:
		total_play_time += (Time.get_ticks_msec() / 1000.0) - _run_start_time
		_run_start_time = 0.0
		_save()

func record_progress(progress: float) -> void:
	var p := roundi(progress)
	if p > _current_best:
		_current_best = p
	if _per_level.has(_current_level_id):
		if p > int(_per_level[_current_level_id].get("best", 0)):
			_per_level[_current_level_id]["best"] = p

func record_completion(coins: Array) -> void:
	total_completions += 1
	total_coins += coins.size()
	if _per_level.has(_current_level_id):
		_per_level[_current_level_id]["completions"] = int(_per_level[_current_level_id].get("completions", 0)) + 1
		_per_level[_current_level_id]["best"] = 100
	_save()

func record_death() -> void:
	total_deaths += 1
	if _per_level.has(_current_level_id):
		_per_level[_current_level_id]["deaths"] = int(_per_level[_current_level_id].get("deaths", 0)) + 1

func record_jump() -> void:
	total_jumps += 1

func get_best_progress(level_id: String) -> int:
	if _per_level.has(level_id):
		return int(_per_level[level_id].get("best", 0))
	return 0

func get_attempts(level_id: String) -> int:
	if _per_level.has(level_id):
		return int(_per_level[level_id].get("attempts", 0))
	return 0

func get_completions(level_id: String) -> int:
	if _per_level.has(level_id):
		return int(_per_level[level_id].get("completions", 0))
	return 0

func get_deaths(level_id: String) -> int:
	if _per_level.has(level_id):
		return int(_per_level[level_id].get("deaths", 0))
	return 0

func is_level_completed(level_id: String) -> bool:
	return get_completions(level_id) > 0
