class_name GDAchievementManager
extends Node

## v5.3 UPGRADE: XP system + 3 new achievements (daily_devotee, speedrunner, lint_master)
##
## Achievement system. Tracks unlocked achievements, evaluates conditions on
## stat changes, displays toast notifications, and persists through GameState.
## Achievements are data-driven; append to ACHIEVEMENT_DEFS to add more.
##
## v5.3 adds:
##   - Per-rarity XP constants (XP_COMMON/RARE/EPIC/LEGENDARY) mirroring the
##     web RARITY_XP table in src/components/pulse/content.ts.
##   - static _xp_for_rarity(rarity) helper ("common"/"rare"/"epic"/"legendary" -> XP).
##   - static _total_xp cache + get_total_xp() (recomputes if cache is 0/stale)
##     + get_max_xp() (sum across all ACHIEVEMENT_DEFS).
##   - New signal achievement_unlocked_xp(id, xp_awarded) emitted alongside
##     the existing `unlocked` signal so the HUD can show "+50 XP" toasts.
##   - 3 new achievement definitions: daily_devotee, speedrunner, lint_master.
##   - Incremental _total_xp update on each unlock (no recompute per call).
## Save schema unchanged: {"unlocked_achievements": {id: true}} -- no breaking change.

signal unlocked(id: String, display_name: String)
signal achievement_unlocked_xp(achievement_id: String, xp_awarded: int)

# --- Per-rarity XP constants (v5.3) -----------------------------------------
# Mirrors RARITY_XP in src/components/pulse/content.ts.
const XP_COMMON := 10
const XP_RARE := 25
const XP_EPIC := 50
const XP_LEGENDARY := 100

const ACHIEVEMENT_FIRST_RUN: String = GDGameTypes.ACHIEVEMENT_FIRST_RUN
const ACHIEVEMENT_FLAWLESS: String = GDGameTypes.ACHIEVEMENT_FLAWLESS
const ACHIEVEMENT_COIN_COLLECTOR: String = GDGameTypes.ACHIEVEMENT_COIN_COLLECTOR
const ACHIEVEMENT_FINISH_5: String = GDGameTypes.ACHIEVEMENT_FINISH_5
const ACHIEVEMENT_FINISH_10: String = GDGameTypes.ACHIEVEMENT_FINISH_10
const ACHIEVEMENT_FINISH_ALL: String = GDGameTypes.ACHIEVEMENT_FINISH_ALL
const ACHIEVEMENT_COINS_10: String = GDGameTypes.ACHIEVEMENT_COINS_10
const ACHIEVEMENT_COINS_25: String = GDGameTypes.ACHIEVEMENT_COINS_25
const ACHIEVEMENT_DEATHS_50: String = GDGameTypes.ACHIEVEMENT_DEATHS_50
const ACHIEVEMENT_DEATHS_500: String = GDGameTypes.ACHIEVEMENT_DEATHS_500
const ACHIEVEMENT_JUMPS_1000: String = GDGameTypes.ACHIEVEMENT_JUMPS_1000
const ACHIEVEMENT_PRACTICE_PRO: String = GDGameTypes.ACHIEVEMENT_PRACTICE_PRO
const ACHIEVEMENT_TRIGGER_MASTER: String = GDGameTypes.ACHIEVEMENT_TRIGGER_MASTER
const ACHIEVEMENT_SPEED_DEMON: String = GDGameTypes.ACHIEVEMENT_SPEED_DEMON
const ACHIEVEMENT_EDITOR: String = GDGameTypes.ACHIEVEMENT_EDITOR
# v5.3 new achievement IDs.
const ACHIEVEMENT_DAILY_DEVOTEE: String = GDGameTypes.ACHIEVEMENT_DAILY_DEVOTEE
const ACHIEVEMENT_SPEEDRUNNER: String = GDGameTypes.ACHIEVEMENT_SPEEDRUNNER
const ACHIEVEMENT_LINT_MASTER: String = GDGameTypes.ACHIEVEMENT_LINT_MASTER

# Achievement definitions. Each defines: id, name, description, rarity, category.
# v5.3: rarity + category backfilled on legacy defs for XP computation and UI
# filtering. New v5.3 defs also carry a `condition` dict (stat_key + threshold)
# documenting the unlock trigger for future data-driven evaluation. Append-only.
const ACHIEVEMENT_DEFS: Array[Dictionary] = [
	{"id": ACHIEVEMENT_FIRST_RUN, "name": "First Steps", "description": "Attempt your first level.", "rarity": "common", "category": "gameplay"},
	{"id": ACHIEVEMENT_FLAWLESS, "name": "Flawless Run", "description": "Complete a level on your first attempt.", "rarity": "epic", "category": "mastery"},
	{"id": ACHIEVEMENT_COIN_COLLECTOR, "name": "Coin Collector", "description": "Collect your first secret coin.", "rarity": "common", "category": "collection"},
	{"id": ACHIEVEMENT_FINISH_5, "name": "Finisher x5", "description": "Complete 5 levels total.", "rarity": "common", "category": "gameplay"},
	{"id": ACHIEVEMENT_FINISH_10, "name": "Finisher x10", "description": "Complete 10 levels total.", "rarity": "rare", "category": "gameplay"},
	{"id": ACHIEVEMENT_FINISH_ALL, "name": "Completionist", "description": "Complete every built-in level.", "rarity": "epic", "category": "mastery"},
	{"id": ACHIEVEMENT_COINS_10, "name": "Coin Hoarder", "description": "Collect 10 secret coins total.", "rarity": "rare", "category": "collection"},
	{"id": ACHIEVEMENT_COINS_25, "name": "Coin Vault", "description": "Collect 25 secret coins total.", "rarity": "epic", "category": "collection"},
	{"id": ACHIEVEMENT_DEATHS_50, "name": "Persistence", "description": "Die 50 times across all levels.", "rarity": "common", "category": "gameplay"},
	{"id": ACHIEVEMENT_DEATHS_500, "name": "Demon Slayer", "description": "Die 500 times across all levels.", "rarity": "epic", "category": "mastery"},
	{"id": ACHIEVEMENT_JUMPS_1000, "name": "Marathon Runner", "description": "Perform 1000 jumps total.", "rarity": "rare", "category": "gameplay"},
	{"id": ACHIEVEMENT_PRACTICE_PRO, "name": "Practice Pro", "description": "Place 10 practice checkpoints in one run.", "rarity": "rare", "category": "gameplay"},
	{"id": ACHIEVEMENT_TRIGGER_MASTER, "name": "Trigger Master", "description": "Fire 25 triggers in one level.", "rarity": "rare", "category": "creation"},
	{"id": ACHIEVEMENT_SPEED_DEMON, "name": "Speed Demon", "description": "Complete the Speed Demon level.", "rarity": "epic", "category": "mastery"},
	{"id": ACHIEVEMENT_EDITOR, "name": "Level Architect", "description": "Save your first custom level.", "rarity": "common", "category": "creation"},
	# v5.3 new achievements.
	{"id": ACHIEVEMENT_DAILY_DEVOTEE, "name": "Daily Devotee", "description": "Complete 7 daily challenges.", "rarity": "epic", "category": "mastery", "condition": {"stat_key": "daily_completions", "threshold": 7}},
	{"id": ACHIEVEMENT_SPEEDRUNNER, "name": "Speedrunner", "description": "Beat par time on 5 different levels.", "rarity": "epic", "category": "mastery", "condition": {"stat_key": "par_beats", "threshold": 5}},
	{"id": ACHIEVEMENT_LINT_MASTER, "name": "Lint Master", "description": "Pass the level linter 10 times with zero warnings.", "rarity": "rare", "category": "creation", "condition": {"stat_key": "lint_clean_passes", "threshold": 10}},
]

var unlocked_achievements: Dictionary = {}  # id -> true
var _stats: Node = null  # GDStatsTracker
var _settings_node: Node = null  # GDGameState
var _definition_by_id: Dictionary = {}

# v5.3: cached total XP across all unlocked achievements. Updated incrementally
# on each unlock(); recomputed lazily from unlocked_achievements by
# get_total_xp() / _recompute_total_xp() if the cache is 0 (e.g., fresh load).
static var _total_xp: int = 0


func _ready() -> void:
	_build_definition_lookup()
	_stats = get_node_or_null("/root/StatsTracker")
	_settings_node = get_node_or_null("/root/GameState")
	_load_from_settings()
	# v5.3: hydrate the static XP cache from the persisted unlocked set so
	# get_total_xp() returns the correct value before the first new unlock.
	_recompute_total_xp()
	if _stats != null and _stats.has_signal("stat_changed"):
		_stats.stat_changed.connect(_on_stat_changed)
		_on_stat_changed("", null)


func _exit_tree() -> void:
	# Guarantee durable save on teardown.
	_save(true)


func is_unlocked(id: String) -> bool:
	return bool(unlocked_achievements.get(id, false))


# Unlocks an achievement by id. Returns true if this call newly unlocked it.
# Persistence is debounced through GameState; unlocks are rare so the dirty
# flag is sufficient. v5.3: also computes the awarded XP, updates the static
# _total_xp cache incrementally, and emits achievement_unlocked_xp alongside
# the existing `unlocked` signal so the HUD can show "+50 XP" toasts.
func unlock(id: String) -> bool:
	id = id.strip_edges()
	if id.is_empty() or unlocked_achievements.has(id):
		return false
	unlocked_achievements[id] = true
	_save()
	var xp_awarded: int = _xp_for_rarity(_rarity_for_id(id))
	_total_xp += xp_awarded
	unlocked.emit(id, _display_name_for(id))
	achievement_unlocked_xp.emit(id, xp_awarded)
	return true


func get_all_definitions() -> Array[Dictionary]:
	return ACHIEVEMENT_DEFS.duplicate(true)


func get_unlocked_count() -> int:
	return unlocked_achievements.size()


func get_total_count() -> int:
	return ACHIEVEMENT_DEFS.size()


# --- v5.3 XP system ---------------------------------------------------------

# Maps a rarity string ("common"/"rare"/"epic"/"legendary") to its XP award.
# Unknown rarities yield 0 XP so a malformed definition cannot inflate totals.
static func _xp_for_rarity(rarity: String) -> int:
	match rarity:
		"common":
			return XP_COMMON
		"rare":
			return XP_RARE
		"epic":
			return XP_EPIC
		"legendary":
			return XP_LEGENDARY
		_:
			return 0


# Returns the total XP earned across all currently unlocked achievements.
# The cache is updated incrementally on each unlock(); if it is 0 (e.g., right
# after a fresh load before any unlock has fired), it is recomputed from the
# autoloaded singleton's unlocked_achievements dictionary.
static func get_total_xp() -> int:
	if _total_xp > 0:
		return _total_xp
	_recompute_total_xp_from_singleton()
	return _total_xp


# Returns the maximum possible XP (sum of XP for every defined achievement).
# Pure function over the const ACHIEVEMENT_DEFS table -- safe to call any time.
static func get_max_xp() -> int:
	var total: int = 0
	for def: Dictionary in ACHIEVEMENT_DEFS:
		total += _xp_for_rarity(str(def.get("rarity", "common")))
	return total


# Looks up the rarity for an achievement id from ACHIEVEMENT_DEFS, defaulting
# to "common" for legacy entries without an explicit rarity field.
static func _rarity_for_id(id: String) -> String:
	for def: Dictionary in ACHIEVEMENT_DEFS:
		if str(def.get("id", "")) == id:
			return str(def.get("rarity", "common"))
	return "common"


# Recomputes the static _total_xp cache from this instance's unlocked set.
# Called on _ready() after loading persisted state so the cache is warm.
func _recompute_total_xp() -> void:
	var total: int = 0
	for id: String in unlocked_achievements.keys():
		total += _xp_for_rarity(_rarity_for_id(id))
	_total_xp = total


# Fallback recompute path used by the static get_total_xp() when the cache is
# empty: looks up the autoloaded AchievementManager via the scene tree and
# sums XP across its unlocked_achievements. No-op if the singleton is absent
# (e.g., called from a tool context before the tree exists).
static func _recompute_total_xp_from_singleton() -> void:
	var tree: SceneTree = Engine.get_main_loop() as SceneTree
	if tree == null or tree.root == null:
		return
	var am: Node = tree.root.get_node_or_null("AchievementManager")
	if am == null or not (am is GDAchievementManager):
		return
	var total: int = 0
	for id: String in (am as GDAchievementManager).unlocked_achievements.keys():
		total += _xp_for_rarity(_rarity_for_id(id))
	_total_xp = total


# --- Condition evaluation ---------------------------------------------------

func _on_stat_changed(_key: String, _value: Variant) -> void:
	if _stats == null:
		return
	if _stats.total_completions >= 5:
		unlock(ACHIEVEMENT_FINISH_5)
	if _stats.total_completions >= 10:
		unlock(ACHIEVEMENT_FINISH_10)
	if _stats.total_coins >= 1:
		unlock(ACHIEVEMENT_COIN_COLLECTOR)
	if _stats.total_coins >= 10:
		unlock(ACHIEVEMENT_COINS_10)
	if _stats.total_coins >= 25:
		unlock(ACHIEVEMENT_COINS_25)
	if _stats.total_deaths >= 50:
		unlock(ACHIEVEMENT_DEATHS_50)
	if _stats.total_deaths >= 500:
		unlock(ACHIEVEMENT_DEATHS_500)
	if _stats.total_jumps >= 1000:
		unlock(ACHIEVEMENT_JUMPS_1000)


func notify_first_run() -> void:
	unlock(ACHIEVEMENT_FIRST_RUN)


func notify_flawless() -> void:
	unlock(ACHIEVEMENT_FLAWLESS)


func notify_practice_pro(checkpoint_count: int) -> void:
	if checkpoint_count >= 10:
		unlock(ACHIEVEMENT_PRACTICE_PRO)


func notify_trigger_master(trigger_count: int) -> void:
	if trigger_count >= 25:
		unlock(ACHIEVEMENT_TRIGGER_MASTER)


func notify_speed_demon_completed(level_id: String) -> void:
	if level_id == "builtin_speed_demon":
		unlock(ACHIEVEMENT_SPEED_DEMON)


func notify_level_saved() -> void:
	unlock(ACHIEVEMENT_EDITOR)


# v5.3: notify hooks for the 3 new achievements. Callers (DailyChallenge,
# FinishGate/Player, LevelLinter) invoke these after the relevant stat
# increments so the threshold check can fire. Mirrors the existing
# notify_practice_pro / notify_trigger_master pattern.
func notify_daily_devotee(daily_completions: int) -> void:
	if daily_completions >= 7:
		unlock(ACHIEVEMENT_DAILY_DEVOTEE)


func notify_speedrunner(par_beats: int) -> void:
	if par_beats >= 5:
		unlock(ACHIEVEMENT_SPEEDRUNNER)


func notify_lint_master(lint_clean_passes: int) -> void:
	if lint_clean_passes >= 10:
		unlock(ACHIEVEMENT_LINT_MASTER)


func check_finish_all(builtin_count: int) -> void:
	# Caller passes the number of built-in levels; if all are completed, unlock.
	if _stats == null or builtin_count <= 0:
		return
	var completed_builtin: int = 0
	# Built-in ids start with "builtin_".
	for level_id: String in _stats.level_completions.keys():
		if level_id.begins_with("builtin_") and int(_stats.level_completions.get(level_id, 0)) > 0:
			completed_builtin += 1
	if completed_builtin >= builtin_count:
		unlock(ACHIEVEMENT_FINISH_ALL)


# --- Persistence ------------------------------------------------------------

func export_state() -> Dictionary:
	return {"unlocked_achievements": unlocked_achievements.duplicate(true)}


func import_state(data: Dictionary) -> void:
	unlocked_achievements.clear()
	var saved: Variant = data.get("unlocked_achievements", {})
	if not (saved is Dictionary):
		return
	for id_variant: Variant in (saved as Dictionary).keys():
		var id: String = str(id_variant).strip_edges()
		if not id.is_empty() and bool((saved as Dictionary)[id_variant]):
			unlocked_achievements[id] = true


func _load_from_settings() -> void:
	if _settings_node == null or not _settings_node.has_method("get_achievements_state"):
		return
	var data: Dictionary = _settings_node.get_achievements_state()
	import_state(data)


func _save(immediate: bool = false) -> void:
	if _settings_node == null:
		return
	if _settings_node.has_method("set_achievements_state"):
		_settings_node.set_achievements_state(export_state())
		if immediate and _settings_node.has_method("flush"):
			_settings_node.flush()
	elif _settings_node.has_method("save_settings"):
		_settings_node.save_settings()


func _build_definition_lookup() -> void:
	_definition_by_id.clear()
	for def: Dictionary in ACHIEVEMENT_DEFS:
		_definition_by_id[str(def.get("id", ""))] = def


func _display_name_for(id: String) -> String:
	var def: Dictionary = _definition_by_id.get(id, {})
	return str(def.get("name", id))
