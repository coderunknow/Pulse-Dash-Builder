class_name AfterImagePool
extends Node2D

## Pooled afterimage renderer. At 2x+ speed, Main calls maybe_spawn() each
## frame; the pool reuses Polygon2D nodes. An active-count gate skips the
## per-node loop when nothing is alive, keeping the idle cost at zero.

@export_range(0.05, 1.00, 0.01) var lifetime: float = 0.32
@export_range(0, 64, 1) var pool_size: int = 24
@export_range(0.0, 1.0) var spawn_interval_at_4x: float = 0.05
@export_range(0.0, 1.0) var spawn_interval_at_2x: float = 0.10

var _pool: Array[Polygon2D] = []
var _lifetimes: Array[float] = []
var _spawn_timer: float = 0.0
var _next_index: int = 0
var _active_count: int = 0


func _ready() -> void:
	_pool.resize(pool_size)
	_lifetimes.resize(pool_size)
	for index: int in range(pool_size):
		var poly: Polygon2D = Polygon2D.new()
		poly.polygon = _silhouette()
		poly.visible = false
		poly.z_index = 3
		add_child(poly)
		_pool[index] = poly
		_lifetimes[index] = 0.0


func _process(delta: float) -> void:
	if _active_count == 0:
		return
	for index: int in range(_pool.size()):
		if _lifetimes[index] <= 0.0:
			continue
		_lifetimes[index] = maxf(_lifetimes[index] - delta, 0.0)
		var poly: Polygon2D = _pool[index]
		if not is_instance_valid(poly):
			continue
		var fade: float = clampf(_lifetimes[index] / lifetime, 0.0, 1.0)
		var color: Color = poly.color
		color.a = fade * 0.45
		poly.color = color
		poly.scale *= 1.0 - delta * 0.6
		if _lifetimes[index] <= 0.0:
			poly.visible = false
			_active_count -= 1


func maybe_spawn(player: DashPlayer, speed_multiplier: float, delta: float) -> void:
	if _pool.is_empty() or player == null or not is_instance_valid(player):
		return
	if speed_multiplier < 2.0:
		return
	var interval: float = lerpf(spawn_interval_at_2x, spawn_interval_at_4x, clampf((speed_multiplier - 2.0) / 2.0, 0.0, 1.0))
	_spawn_timer -= delta
	if _spawn_timer > 0.0:
		return
	_spawn_timer = interval
	_spawn(player)


func _spawn(player: DashPlayer) -> void:
	if _pool.is_empty():
		return
	var used_index: int = _next_index
	var poly: Polygon2D = _pool[used_index]
	_next_index = (_next_index + 1) % _pool.size()
	poly.global_position = player.global_position
	poly.global_rotation = player.visual.global_rotation
	poly.scale = player.visual.scale
	var color: Color = player.visual.color
	color.a = 0.45
	poly.color = color
	poly.visible = true
	if _lifetimes[used_index] <= 0.0:
		_active_count += 1
	_lifetimes[used_index] = lifetime


func _silhouette() -> PackedVector2Array:
	return PackedVector2Array([
		Vector2(-19.0, -19.0), Vector2(19.0, -19.0),
		Vector2(19.0, 19.0), Vector2(-19.0, 19.0),
	])
