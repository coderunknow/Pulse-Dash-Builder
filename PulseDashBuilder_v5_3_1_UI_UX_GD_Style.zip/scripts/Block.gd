extends StaticBody2D
@onready var visual: Polygon2D = $Visual
@onready var top_edge: Polygon2D = $TopEdge
@onready var bottom_edge: Polygon2D = $BottomEdge
@onready var left_edge: Polygon2D = $LeftEdge
@onready var right_edge: Polygon2D = $RightEdge
@onready var inset: Polygon2D = $Inset
@onready var inner_highlight: Polygon2D = $InnerHighlight
var accent_color: Color = Color("52d8ff")
func _ready() -> void: _refresh_visual()
func _refresh_visual() -> void:
	top_edge.color = accent_color
	bottom_edge.color = Color(accent_color.r * 0.75, accent_color.g * 0.75, accent_color.b * 0.75)
	left_edge.color = Color(accent_color.r * 0.88, accent_color.g * 0.88, accent_color.b * 0.88)
	right_edge.color = left_edge.color
