extends Area2D
@export var portal_type: int = 0
@onready var label: Label = $Label
@onready var outer_glow: Polygon2D = $OuterGlow
var _glow_phase: float = 0.0
func _ready() -> void:
	body_entered.connect(_on_body_entered)
	if label:
		label.text = GDGameTypes.game_mode_name(portal_type).to_upper() if portal_type <= GDGameTypes.GameMode.SWING else ""
func _process(delta: float) -> void:
	_glow_phase += delta * 2.0
	if outer_glow:
		outer_glow.modulate.a = 0.05 + sin(_glow_phase) * 0.03
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		(body as DashPlayer).portal_requested.emit(body as DashPlayer, portal_type)
