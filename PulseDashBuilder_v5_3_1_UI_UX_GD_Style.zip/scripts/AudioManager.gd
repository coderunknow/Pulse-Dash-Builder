## v5 UPGRADE: Added pitch-variation system for SFX. Every play_sfx() call now
## randomizes pitch within ±pitch_variance (default 0.06) so repeated sounds
## (jump, land, orb, coin, death) never sound identical. Per-cue variance can be
## tuned via set_sfx_pitch_variance(). Also added synth helpers for square/sine/
## noise PCM generation and a get_bgm_playback_position() accessor for BeatClock.

class_name GDAudioManager
extends Node

## Procedural SFX synthesizer + BGM loader. Generates short AudioStreamWAV PCM
## sounds at runtime so the project ships with zero audio assets. BGM can be
## loaded from `res://audio/bgm/` if a designer adds files. All volumes persist
## via GameState (debounced, not per-change).
##
## All 25 SFX are built once in _ready() through a single _build_stream() helper
## that takes a sampler Callable — this collapses ~300 lines of duplicated
## buffer/loop boilerplate into one reusable primitive while producing
## bit-identical PCM output to the previous per-cue implementations.

const SAMPLE_RATE: int = 44_100
const BGM_DIRECTORY: String = "res://audio/bgm"
const POOL_SIZE: int = 12
const SETTINGS_SAVE_COOLDOWN_SECONDS: float = 0.6

signal beat_pulse(strength: float)

var master_volume: float = 0.85
var sfx_volume: float = 0.85
var bgm_volume: float = 0.70
var muted: bool = false

var _players: Array[AudioStreamPlayer] = []
var _player_index: int = 0

var _cached_streams: Dictionary = {}
var _bgm_player: AudioStreamPlayer = null
var _bgm_tracks: Dictionary = {}  # track_name -> AudioStream
var _beat_accumulator: float = 0.0
var _bgm_beat_offset: float = 0.0
var _bgm_bpm: float = 140.0

var _settings_node: Node = null
var _save_cooldown: float = 0.0

## v5: Pitch variation system — makes repeated SFX plays sound slightly
## different each time, reducing auditory fatigue.
var _default_pitch_variance: float = 0.06
var _pitch_variances: Dictionary = {}  # int cue -> float per-cue override
var _sfx_rng: RandomNumberGenerator = RandomNumberGenerator.new()


func _ready() -> void:
	_sfx_rng.randomize()
	for index: int in range(POOL_SIZE):
		var player: AudioStreamPlayer = AudioStreamPlayer.new()
		player.bus = &"Master"
		add_child(player)
		_players.append(player)
	_precompute_streams()
	_scan_bgm_directory()
	_settings_node = get_node_or_null("/root/GameState")
	_load_audio_settings()
	apply_volumes()


func _process(delta: float) -> void:
	if _save_cooldown > 0.0:
		_save_cooldown = maxf(_save_cooldown - delta, 0.0)
		if _save_cooldown <= 0.0:
			_save_audio_settings()


# ─── Public API ─────────────────────────────────────────────────────────────

## Play an SFX cue with automatic pitch variation (default ±0.06).
## The pitch_variance parameter overrides the per-cue / default setting for
## this single call. Pass 0.0 to disable variation for this call.
## Backward-compatible: existing call sites with just cue:int still work.
func play_sfx(cue: int, pitch_variance: float = -1.0) -> void:
	if muted or sfx_volume <= 0.0:
		return
	var stream: AudioStreamWAV = _cached_streams.get(cue, null)
	if stream == null:
		return
	var variance: float = _default_pitch_variance
	if pitch_variance >= 0.0:
		variance = pitch_variance
	else:
		var per_cue: Variant = _pitch_variances.get(cue, -1.0)
		if per_cue is float and per_cue >= 0.0:
			variance = per_cue
	var pitch: float = 1.0
	if variance > 0.0:
		pitch = 1.0 + _sfx_rng.randf_range(-variance, variance)
		pitch = clampf(pitch, 0.5, 2.0)
	_play_stream(stream, sfx_volume, pitch)


## Play an SFX cue with an explicit pitch value (no variance applied).
func play_sfx_pitched(cue: int, pitch: float) -> void:
	if muted or sfx_volume <= 0.0:
		return
	var stream: AudioStreamWAV = _cached_streams.get(cue, null)
	if stream == null:
		return
	_play_stream(stream, sfx_volume, clampf(pitch, 0.5, 2.0))


func apply_volumes() -> void:
	var master_bus: int = AudioServer.get_bus_index(&"Master")
	if master_bus >= 0:
		AudioServer.set_bus_volume_db(master_bus, linear_to_db(0.0001 if muted else master_volume))
	if _bgm_player != null:
		_bgm_player.volume_db = linear_to_db(0.0001 if muted else bgm_volume)


func set_master_volume(value: float) -> void:
	master_volume = clampf(value, 0.0, 1.0)
	apply_volumes()
	_schedule_save()


func set_sfx_volume(value: float) -> void:
	sfx_volume = clampf(value, 0.0, 1.0)
	_schedule_save()


func set_bgm_volume(value: float) -> void:
	bgm_volume = clampf(value, 0.0, 1.0)
	apply_volumes()
	_schedule_save()


func set_muted(value: bool) -> void:
	muted = value
	apply_volumes()
	_schedule_save()


# BGM control
func play_bgm(track_name: String = "") -> void:
	if _bgm_player == null:
		_bgm_player = AudioStreamPlayer.new()
		_bgm_player.bus = &"Master"
		add_child(_bgm_player)
	var stream: AudioStream = null
	if track_name.is_empty():
		var names: Array = _bgm_tracks.keys()
		if names.is_empty():
			return
		names.sort()
		stream = _bgm_tracks.get(names[0], null)
	else:
		stream = _bgm_tracks.get(track_name, null)
	if stream == null:
		return
	_bgm_player.stream = stream
	_bgm_player.volume_db = linear_to_db(0.0001 if muted else bgm_volume)
	_bgm_player.play()


func stop_bgm() -> void:
	if _bgm_player != null:
		_bgm_player.stop()


func get_bgm_track_names() -> Array:
	var names: Array = _bgm_tracks.keys()
	names.sort()
	return names


func set_bgm_player(player: AudioStreamPlayer) -> void:
	_bgm_player = player
	if _bgm_player != null:
		_bgm_player.bus = &"Master"
	apply_volumes()


## v5: Get the current BGM playback position in seconds (0.0 if not playing).
## Used by BeatClock to slave to the actual audio timeline.
func get_bgm_playback_position() -> float:
	if _bgm_player != null and _bgm_player.playing:
		return _bgm_player.get_playback_position()
	return 0.0


## v5: Check whether BGM is currently playing.
func is_bgm_playing() -> bool:
	return _bgm_player != null and _bgm_player.playing


## v5: Set the global default pitch variance for all SFX cues.
## Individual cues can override this via set_sfx_pitch_variance().
func set_default_pitch_variance(variance: float) -> void:
	_default_pitch_variance = maxf(variance, 0.0)


## v5: Set per-cue pitch variance override. Pass variance=0.0 to disable
## variation for a specific cue. The cue parameter uses SfxCue int values.
func set_sfx_pitch_variance(cue: int, variance: float) -> void:
	if variance <= 0.0:
		_pitch_variances.erase(cue)
	else:
		_pitch_variances[cue] = variance


## v5: Get the current pitch variance for a specific cue (returns -1.0 if
## using default, or the per-cue override value).
func get_sfx_pitch_variance(cue: int) -> float:
	var per_cue: Variant = _pitch_variances.get(cue, -1.0)
	if per_cue is float:
		return per_cue
	return -1.0


## v5: Set per-cue pitch variance by cue name string (e.g. "jump", "death").
## Maps the string to the corresponding SfxCue enum int. Returns false if
## the name is not recognized.
func set_sfx_pitch_variance_by_name(cue_name: String, variance: float) -> bool:
	var cue_int: int = _cue_name_to_int(cue_name)
	if cue_int < 0:
		return false
	set_sfx_pitch_variance(cue_int, variance)
	return true


## v5: Reverse-lookup map for cue name -> int. Built lazily on first call.
var _cue_name_map: Dictionary = {}
var _cue_name_map_built: bool = false

func _cue_name_to_int(name: String) -> int:
	if not _cue_name_map_built:
		_cue_name_map_built = true
		var names: PackedStringArray = PackedStringArray([
			"jump", "death", "coin", "portal", "checkpoint", "pad", "orb",
			"finish", "countdown_tick", "countdown_go", "achievement",
			"editor_place", "editor_remove", "editor_undo", "editor_redo",
			"trigger_color", "trigger_pulse", "trigger_shake", "trigger_spawn",
			"key_pickup", "lock_open", "shrink", "grow", "bounce",
		])
		for idx: int in range(names.size()):
			_cue_name_map[names[idx]] = idx
	var val: Variant = _cue_name_map.get(name.to_lower(), -1)
	if val is int:
		return val
	return -1


# ─── Internal playback ──────────────────────────────────────────────────────

func _play_stream(stream: AudioStream, volume: float, pitch: float) -> void:
	if _players.is_empty():
		return
	var player: AudioStreamPlayer = _players[_player_index]
	_player_index = (_player_index + 1) % POOL_SIZE
	player.stream = stream
	player.volume_db = linear_to_db(volume)
	player.pitch_scale = pitch
	player.play()


# ─── Retro-futuristic synthesizer helpers (v5) ─────────────────────────────
## Simple waveform generators for creating retro-futuristic sound effects.
## These return a sample value in [-1.0, 1.0] for the given phase (0.0..1.0).

## Generate a square wave sample at the given phase.
## Duty cycle 0.5 by default; adjust for different timbres.
static func synth_square(phase: float, duty: float = 0.5) -> float:
	var p: float = fmod(phase, 1.0)
	return 1.0 if p < duty else -1.0


## Generate a sine wave sample at the given phase.
static func synth_sine(phase: float) -> float:
	return sin(fmod(phase, 1.0) * TAU)


## Generate a noise sample. The rng parameter allows deterministic noise.
static func synth_noise(_phase: float, rng: RandomNumberGenerator) -> float:
	return rng.randf() * 2.0 - 1.0


## Generate a sawtooth wave sample at the given phase.
static func synth_sawtooth(phase: float) -> float:
	var p: float = fmod(phase, 1.0)
	return 2.0 * p - 1.0


## Generate a triangle wave sample at the given phase.
static func synth_triangle(phase: float) -> float:
	var p: float = fmod(phase, 1.0)
	return 4.0 * absf(p - 0.5) - 1.0


# ─── SFX synthesis ──────────────────────────────────────────────────────────
# Single helper that allocates the PCM buffer once and invokes the sampler
# Callable per sample. The sampler signature is:
#   (t: float, i: int, rng: RandomNumberGenerator) -> float
# and must return a sample roughly in [-1, 1]. This eliminates the per-cue
# buffer-resize / write_sample boilerplate while keeping the PCM output
# identical to the previous hand-rolled implementations.

func _build_stream(duration: float, sampler: Callable, seed: int = -1) -> AudioStreamWAV:
	var sample_count: int = maxi(int(duration * SAMPLE_RATE), 1)
	var buf: PackedByteArray = PackedByteArray()
	buf.resize(sample_count * 2)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	if seed >= 0:
		rng.seed = seed
	else:
		rng.randomize()
	for i: int in range(sample_count):
		var t: float = float(i) / SAMPLE_RATE
		var sample: float = clampf(sampler.call(t, i, rng), -1.0, 1.0)
		buf.encode_s16(i * 2, int(sample * 32700.0))
	# Hard fade-out on the last ~4ms to guarantee zero-crossing (fixes click/pop on noise-based cues)
	var fade_samples: int = mini(176, sample_count)  # ~4ms at 44.1k
	if fade_samples > 0:
		for j: int in range(fade_samples):
			var idx: int = sample_count - fade_samples + j
			var fade: float = float(j) / float(fade_samples)
			var val: int = buf.decode_s16(idx * 2)
			buf.encode_s16(idx * 2, int(val * fade))
	return _make_stream(buf)


func _make_stream(samples: PackedByteArray, mix_rate: int = SAMPLE_RATE) -> AudioStreamWAV:
	var stream: AudioStreamWAV = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = mix_rate
	stream.stereo = false
	stream.data = samples
	return stream


func _precompute_streams() -> void:
	_cached_streams[GDGameTypes.SfxCue.JUMP] = _synth_jump()
	_cached_streams[GDGameTypes.SfxCue.DEATH] = _synth_death()
	_cached_streams[GDGameTypes.SfxCue.COIN] = _synth_coin()
	_cached_streams[GDGameTypes.SfxCue.PORTAL] = _synth_portal()
	_cached_streams[GDGameTypes.SfxCue.CHECKPOINT] = _synth_checkpoint()
	_cached_streams[GDGameTypes.SfxCue.PAD] = _synth_pad()
	_cached_streams[GDGameTypes.SfxCue.ORB] = _synth_orb()
	_cached_streams[GDGameTypes.SfxCue.FINISH] = _synth_finish()
	_cached_streams[GDGameTypes.SfxCue.COUNTDOWN_TICK] = _synth_tick()
	_cached_streams[GDGameTypes.SfxCue.COUNTDOWN_GO] = _synth_go()
	_cached_streams[GDGameTypes.SfxCue.ACHIEVEMENT] = _synth_achievement()
	_cached_streams[GDGameTypes.SfxCue.EDITOR_PLACE] = _synth_place()
	_cached_streams[GDGameTypes.SfxCue.EDITOR_REMOVE] = _synth_remove()
	_cached_streams[GDGameTypes.SfxCue.EDITOR_UNDO] = _synth_undo()
	_cached_streams[GDGameTypes.SfxCue.EDITOR_REDO] = _synth_redo()
	_cached_streams[GDGameTypes.SfxCue.TRIGGER_COLOR] = _synth_trigger_color()
	_cached_streams[GDGameTypes.SfxCue.TRIGGER_PULSE] = _synth_trigger_pulse()
	_cached_streams[GDGameTypes.SfxCue.TRIGGER_SHAKE] = _synth_trigger_shake()
	_cached_streams[GDGameTypes.SfxCue.TRIGGER_SPAWN] = _synth_trigger_spawn()
	_cached_streams[GDGameTypes.SfxCue.KEY_PICKUP] = _synth_key()
	_cached_streams[GDGameTypes.SfxCue.LOCK_OPEN] = _synth_lock()
	_cached_streams[GDGameTypes.SfxCue.SHRINK] = _synth_shrink()
	_cached_streams[GDGameTypes.SfxCue.GROW] = _synth_grow()
	_cached_streams[GDGameTypes.SfxCue.BOUNCE] = _synth_bounce()


# ─── Individual SFX (each delegates to _build_stream with a sampler Callable) ─

func _synth_jump() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 26.0)
		var freq: float = 380.0 + 1100.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.10, sampler)


func _synth_death() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, rng: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 8.0)
		var freq: float = 220.0 * exp(-t * 3.0)
		var noise: float = (rng.randf() * 2.0 - 1.0) * 0.35
		var tone: float = sin(t * freq * TAU) * 0.65
		return env * (tone + noise)
	return _build_stream(0.45, sampler, 0xA11CE)


func _synth_coin() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 11.0)
		var tone: float = sin(t * 1_320.0 * TAU) * 0.5 + sin(t * 1_760.0 * TAU) * 0.5
		return env * tone
	return _build_stream(0.22, sampler)


func _synth_portal() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 6.5)
		var freq: float = 220.0 + 900.0 * t
		var tone: float = sin(t * freq * TAU) * 0.6 + sin(t * freq * 2.0 * TAU) * 0.25
		return env * tone
	return _build_stream(0.30, sampler)


func _synth_checkpoint() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 8.0)
		var tone: float = sin(t * 660.0 * TAU) * 0.5 + sin(t * 990.0 * TAU) * 0.5
		return env * tone
	return _build_stream(0.28, sampler)


func _synth_pad() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 13.0)
		var freq: float = 300.0 + 600.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.18, sampler)


func _synth_orb() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 10.0)
		var freq: float = 540.0 + 720.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.20, sampler)


func _synth_finish() -> AudioStreamWAV:
	var notes: Array[float] = [523.0, 659.0, 784.0, 1_047.0]
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 3.5)
		var note_index: int = clampi(int(t * 8.0), 0, notes.size() - 1)
		var freq: float = notes[note_index]
		var tone: float = sin(t * freq * TAU) * 0.55 + sin(t * freq * 2.0 * TAU) * 0.20
		return env * tone
	return _build_stream(0.65, sampler)


func _synth_tick() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 28.0)
		return env * sin(t * 660.0 * TAU)
	return _build_stream(0.10, sampler)


func _synth_go() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 9.0)
		var freq: float = 880.0
		var tone: float = sin(t * freq * TAU) * 0.5 + sin(t * freq * 1.5 * TAU) * 0.3
		return env * tone
	return _build_stream(0.28, sampler)


func _synth_achievement() -> AudioStreamWAV:
	var notes: Array[float] = [659.0, 880.0, 1_318.0]
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 4.0)
		var note_index: int = clampi(int(t * 5.0), 0, notes.size() - 1)
		var freq: float = notes[note_index]
		var tone: float = sin(t * freq * TAU) * 0.55 + sin(t * freq * 2.0 * TAU) * 0.25
		return env * tone
	return _build_stream(0.55, sampler)


func _synth_place() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 32.0)
		return env * sin(t * 1_100.0 * TAU)
	return _build_stream(0.07, sampler)


func _synth_remove() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 26.0)
		var freq: float = 600.0 * exp(-t * 8.0)
		return env * sin(t * freq * TAU)
	return _build_stream(0.08, sampler)


func _synth_undo() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 16.0)
		var freq: float = 500.0 - 250.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.10, sampler)


func _synth_redo() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 16.0)
		var freq: float = 500.0 + 250.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.10, sampler)


func _synth_trigger_color() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 12.0)
		var freq: float = 440.0 + 600.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.16, sampler)


func _synth_trigger_pulse() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 5.0)
		var tone: float = sin(t * 220.0 * TAU) * 0.4 + sin(t * 440.0 * TAU) * 0.4
		return env * tone
	return _build_stream(0.30, sampler)


func _synth_trigger_shake() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, rng: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 7.0)
		var noise: float = (rng.randf() * 2.0 - 1.0) * 0.7
		return env * noise
	return _build_stream(0.25, sampler, 0xBAD)


func _synth_trigger_spawn() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 9.0)
		var freq: float = 700.0 + 500.0 * t
		var tone: float = sin(t * freq * TAU) * 0.5 + sin(t * freq * 1.5 * TAU) * 0.3
		return env * tone
	return _build_stream(0.20, sampler)


func _synth_key() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 14.0)
		var tone: float = sin(t * 880.0 * TAU) * 0.5 + sin(t * 1_320.0 * TAU) * 0.5
		return env * tone
	return _build_stream(0.18, sampler)


func _synth_lock() -> AudioStreamWAV:
	var notes: Array[float] = [440.0, 554.0, 659.0, 880.0]
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 5.0)
		var note_index: int = clampi(int(t * 12.0), 0, notes.size() - 1)
		var freq: float = notes[note_index]
		return env * sin(t * freq * TAU)
	return _build_stream(0.32, sampler)


func _synth_shrink() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 9.0)
		var freq: float = 800.0 - 500.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.20, sampler)


func _synth_grow() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 8.0)
		var freq: float = 300.0 + 700.0 * t
		return env * sin(t * freq * TAU)
	return _build_stream(0.22, sampler)


func _synth_bounce() -> AudioStreamWAV:
	var sampler: Callable = func(t: float, _i: int, _r: RandomNumberGenerator) -> float:
		var env: float = exp(-t * 18.0)
		var freq: float = 600.0 + 400.0 * sin(t * 30.0)
		return env * sin(t * freq * TAU)
	return _build_stream(0.14, sampler)


# ─── BGM directory scan ─────────────────────────────────────────────────────

func _scan_bgm_directory() -> void:
	var dir: DirAccess = DirAccess.open(BGM_DIRECTORY)
	if dir == null:
		return
	dir.list_dir_begin()
	var file_name: String = dir.get_next()
	while not file_name.is_empty():
		if not dir.current_is_dir() and (file_name.ends_with(".ogg") or file_name.ends_with(".wav") or file_name.ends_with(".mp3")):
			var path: String = BGM_DIRECTORY.path_join(file_name)
			if ResourceLoader.exists(path):
				var stream: AudioStream = load(path) as AudioStream
				if stream != null:
					_bgm_tracks[file_name.get_basename()] = stream
		file_name = dir.get_next()
	dir.list_dir_end()


# ─── Persistence ────────────────────────────────────────────────────────────

func _load_audio_settings() -> void:
	if _settings_node == null:
		return
	var state: Dictionary = _settings_node.get_audio_state()
	master_volume = clampf(float(state.get("master_volume", 0.85)), 0.0, 1.0)
	sfx_volume = clampf(float(state.get("sfx_volume", 0.85)), 0.0, 1.0)
	bgm_volume = clampf(float(state.get("bgm_volume", 0.70)), 0.0, 1.0)
	muted = bool(state.get("muted", false))


# Coalesce rapid slider tweaks into a single debounced save. Immediate writes
# would hammer the disk every value-changed frame while dragging a slider.
func _schedule_save() -> void:
	_save_cooldown = SETTINGS_SAVE_COOLDOWN_SECONDS


func _save_audio_settings() -> void:
	if _settings_node == null:
		return
	_settings_node.set_audio_state({
		"master_volume": master_volume,
		"sfx_volume": sfx_volume,
		"bgm_volume": bgm_volume,
		"muted": muted,
	})


# Force immediate persistence — called by GameState flush on run end / quit.
func flush() -> void:
	if _save_cooldown > 0.0:
		_save_cooldown = 0.0
		_save_audio_settings()
