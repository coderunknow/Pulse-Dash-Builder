extends Area2D
@export var target_position: Vector2 = Vector2.ZERO
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		body.global_position = target_position
