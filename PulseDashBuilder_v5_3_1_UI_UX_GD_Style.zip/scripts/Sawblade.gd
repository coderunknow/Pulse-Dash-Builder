extends Area2D
@onready var outer_glow: Polygon2D = $OuterGlow
@onready var visual: Polygon2D = $Visual
var _rotation_speed: float = 4.0
var _glow_phase: float = 0.0
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	visual.rotation += _rotation_speed * delta
	_glow_phase += delta * 2.5
	if outer_glow:
		outer_glow.modulate.a = 0.06 + sin(_glow_phase) * 0.04
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		(body as DashPlayer).die("sawblade")
