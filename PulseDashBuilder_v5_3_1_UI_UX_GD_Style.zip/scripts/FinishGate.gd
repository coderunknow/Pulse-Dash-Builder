extends Area2D
signal finished(body)
@onready var outer_glow: Polygon2D = $OuterGlow
@onready var inner_glow: Polygon2D = $InnerGlow
var _glow_phase: float = 0.0
func _ready() -> void:
	body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	_glow_phase += delta * 2.5
	if inner_glow:
		inner_glow.modulate.a = 0.15 + sin(_glow_phase) * 0.08
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		finished.emit(body)
