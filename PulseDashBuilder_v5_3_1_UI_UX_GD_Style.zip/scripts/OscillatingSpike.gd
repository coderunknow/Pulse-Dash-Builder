extends Node2D
@export var amplitude: float = 60.0
@export var freq: float = 1.5
var _time: float = 0.0
var _start_pos: Vector2 = Vector2.ZERO
func _ready() -> void:
	_start_pos = position
func _process(delta: float) -> void:
	_time += delta
	position.y = _start_pos.y + sin(_time * freq) * amplitude
