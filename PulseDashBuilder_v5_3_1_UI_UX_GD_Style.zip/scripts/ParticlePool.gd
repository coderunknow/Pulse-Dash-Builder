## ParticlePool — Lightweight burst particle system using GPUParticles2D pooling.
class_name ParticlePool
extends Node2D

const POOL_SIZE: int = 32

var _pool: Array[GPUParticles2D] = []
var _next_idx: int = 0

func _ready() -> void:
	for i in POOL_SIZE:
		var p := GPUParticles2D.new()
		p.emitting = false
		p.one_shot = true
		p.amount = 16
		p.lifetime = 0.6
		p.visibility_rect = Rect2(-200, -200, 400, 400)
		var mat := ParticleProcessMaterial.new()
		mat.direction = Vector3(0, -1, 0)
		mat.spread = 180.0
		mat.initial_velocity_min = 80.0
		mat.initial_velocity_max = 200.0
		mat.gravity = Vector3(0, 400, 0)
		mat.scale_min = 2.0
		mat.scale_max = 4.0
		p.process_material = mat
		add_child(p)
		_pool.append(p)

func play_burst(pos: Vector2, color: Color, count: int, speed_min: float, speed_max: float, _gravity: float) -> void:
	if _pool.is_empty():
		return
	var p := _pool[_next_idx]
	_next_idx = (_next_idx + 1) % POOL_SIZE
	p.global_position = pos
	p.amount = clampi(count, 1, 64)
	var mat := p.process_material as ParticleProcessMaterial
	if mat:
		mat.initial_velocity_min = speed_min
		mat.initial_velocity_max = speed_max
		mat.gravity = Vector3(0, _gravity, 0)
	p.modulate = color
	p.restart()
	p.emitting = true
