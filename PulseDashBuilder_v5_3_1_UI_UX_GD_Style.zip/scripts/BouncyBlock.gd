extends StaticBody2D
@onready var visual: Polygon2D = get_node_or_null("Visual")
@onready var outline: Polygon2D = get_node_or_null("Outline")
@onready var bounce_area: Area2D = get_node_or_null("BounceArea")
@export var bounce_force: float = 1100.0
func _ready() -> void:
	if bounce_area:
		bounce_area.body_entered.connect(_on_body_entered)
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		var p: DashPlayer = body as DashPlayer
		p.velocity.y = -bounce_force
