## BeatClock — Emits beat signals at the configured BPM for visual pulse sync.
class_name BeatClock
extends Node

signal beat(strength: float)

var _bpm: float = 140.0
var _running: bool = false
var _elapsed: float = 0.0
var _beat_interval: float = 0.0
var _pulse: float = 0.0

func start_clock(bpm: float) -> void:
	_bpm = clampf(bpm, 40.0, 300.0)
	_beat_interval = 60.0 / _bpm
	_elapsed = 0.0
	_running = true
	_pulse = 1.0

func stop_clock() -> void:
	_running = false
	_pulse = 0.0

func get_pulse() -> float:
	return _pulse

func _process(delta: float) -> void:
	if not _running:
		return
	_elapsed += delta
	_pulse = maxf(_pulse - delta * 4.0, 0.0)
	if _elapsed >= _beat_interval:
		_elapsed -= _beat_interval
		_pulse = 1.0
		beat.emit(1.0)
