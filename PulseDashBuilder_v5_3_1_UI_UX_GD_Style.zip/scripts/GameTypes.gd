## GDGameTypes — Central enums, constants, and static helpers for Pulse Dash Builder.
## Referenced by every script in the project. Append-only enum policy.
class_name GDGameTypes
extends RefCounted

# ─── Game Modes ───────────────────────────────────────────────────────────────
enum GameMode { CUBE, SHIP, UFO, WAVE, ROBOT, SPIDER, BALL, SWING }

static func game_mode_name(mode: int) -> String:
	match mode:
		GameMode.CUBE: return "cube"
		GameMode.SHIP: return "ship"
		GameMode.UFO: return "ufo"
		GameMode.WAVE: return "wave"
		GameMode.ROBOT: return "robot"
		GameMode.SPIDER: return "spider"
		GameMode.BALL: return "ball"
		GameMode.SWING: return "swing"
		_: return "cube"

# ─── Orb Types ────────────────────────────────────────────────────────────────
enum OrbType { YELLOW, PINK, RED, BLUE, GREEN, BLACK, ORANGE, PURPLE, DASH }

# ─── Pad Types ────────────────────────────────────────────────────────────────
enum PadType { YELLOW, PINK, RED, BLUE }

# ─── Portal Types ─────────────────────────────────────────────────────────────
enum PortalType {
	GRAVITY_NORMAL, GRAVITY_INVERT,
	MODE_CUBE, MODE_SHIP, MODE_UFO, MODE_WAVE, MODE_ROBOT, MODE_SPIDER, MODE_BALL, MODE_SWING,
	SIZE_NORMAL, SIZE_MINI,
	SPEED_HALF, SPEED_NORMAL, SPEED_DOUBLE, SPEED_TRIPLE, SPEED_QUAD,
	MIRROR_ON, MIRROR_OFF,
	DUAL_ON, DUAL_OFF,
}

# ─── SFX Cues ─────────────────────────────────────────────────────────────────
enum SfxCue {
	JUMP, DEATH, COIN, PORTAL, CHECKPOINT, PAD, ORB, FINISH,
	COUNTDOWN_TICK, COUNTDOWN_GO, ACHIEVEMENT,
	EDITOR_PLACE, EDITOR_REMOVE, EDITOR_UNDO, EDITOR_REDO,
	TRIGGER_COLOR, TRIGGER_PULSE, TRIGGER_SHAKE, TRIGGER_SPAWN,
	KEY_PICKUP, LOCK_OPEN, SHRINK, GROW, BOUNCE,
}

# ─── Trigger Actions ──────────────────────────────────────────────────────────
enum TriggerAction {
	COLOR, MOVE, ROTATE, ALPHA, TOGGLE, PULSE, SHAKE, SPAWN,
	CAMERA_ZOOM, CAMERA_MOVE, COLLISION_TOGGLE, BACKGROUND, SPEED, COUNTER,
}

# ─── Easing ───────────────────────────────────────────────────────────────────
enum Easing { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE, ELASTIC }

static func easing_name(e: int) -> String:
	match e:
		Easing.LINEAR: return "Linear"
		Easing.EASE_IN: return "Ease In"
		Easing.EASE_OUT: return "Ease Out"
		Easing.EASE_IN_OUT: return "Ease In-Out"
		Easing.BOUNCE: return "Bounce"
		Easing.ELASTIC: return "Elastic"
		_: return "Linear"

static func easing_token(e: int) -> String:
	match e:
		Easing.LINEAR: return "linear"
		Easing.EASE_IN: return "ease_in"
		Easing.EASE_OUT: return "ease_out"
		Easing.EASE_IN_OUT: return "ease_in_out"
		Easing.BOUNCE: return "bounce"
		Easing.ELASTIC: return "elastic"
		_: return "linear"

static func easing_from_token(tok: String) -> int:
	match tok:
		"linear": return Easing.LINEAR
		"ease_in": return Easing.EASE_IN
		"ease_out": return Easing.EASE_OUT
		"ease_in_out": return Easing.EASE_IN_OUT
		"bounce": return Easing.BOUNCE
		"elastic": return Easing.ELASTIC
		_: return Easing.LINEAR

# ─── Background Themes ────────────────────────────────────────────────────────
enum BackgroundTheme { NEON, SUNSET, FOREST, OCEAN, VOID, LAVA, AURORA }

static func background_theme_name(theme: int) -> String:
	match theme:
		BackgroundTheme.NEON: return "Neon"
		BackgroundTheme.SUNSET: return "Sunset"
		BackgroundTheme.FOREST: return "Forest"
		BackgroundTheme.OCEAN: return "Ocean"
		BackgroundTheme.VOID: return "Void"
		BackgroundTheme.LAVA: return "Lava"
		BackgroundTheme.AURORA: return "Aurora"
		_: return "Neon"

static func background_theme_token(theme: int) -> String:
	match theme:
		BackgroundTheme.NEON: return "neon"
		BackgroundTheme.SUNSET: return "sunset"
		BackgroundTheme.FOREST: return "forest"
		BackgroundTheme.OCEAN: return "ocean"
		BackgroundTheme.VOID: return "void"
		BackgroundTheme.LAVA: return "lava"
		BackgroundTheme.AURORA: return "aurora"
		_: return "neon"

static func background_theme_from_token(tok: String) -> int:
	match tok:
		"neon": return BackgroundTheme.NEON
		"sunset": return BackgroundTheme.SUNSET
		"forest": return BackgroundTheme.FOREST
		"ocean": return BackgroundTheme.OCEAN
		"void": return BackgroundTheme.VOID
		"lava": return BackgroundTheme.LAVA
		"aurora": return BackgroundTheme.AURORA
		_: return BackgroundTheme.NEON

static func background_theme_palette(theme: int) -> Dictionary:
	match theme:
		BackgroundTheme.NEON:
			return {"base": Color("0a1228"), "accent": Color("52d8ff"), "fog": Color(0.04, 0.07, 0.16)}
		BackgroundTheme.SUNSET:
			return {"base": Color("1a0a18"), "accent": Color("ff6b4a"), "fog": Color(0.12, 0.04, 0.08)}
		BackgroundTheme.FOREST:
			return {"base": Color("0a1a0a"), "accent": Color("4aff6b"), "fog": Color(0.02, 0.10, 0.04)}
		BackgroundTheme.OCEAN:
			return {"base": Color("0a1428"), "accent": Color("4ac8ff"), "fog": Color(0.02, 0.06, 0.14)}
		BackgroundTheme.VOID:
			return {"base": Color("08080c"), "accent": Color("9b59b6"), "fog": Color(0.03, 0.02, 0.06)}
		BackgroundTheme.LAVA:
			return {"base": Color("4a1a1a"), "accent": Color("ff6b4a"), "fog": Color(0.12, 0.04, 0.02)}
		BackgroundTheme.AURORA:
			return {"base": Color("0a1820"), "accent": Color("66ffcc"), "fog": Color(0.02, 0.08, 0.08)}
		_:
			return {"base": Color("0a1228"), "accent": Color("52d8ff"), "fog": Color(0.04, 0.07, 0.16)}

# ─── Color Helpers ────────────────────────────────────────────────────────────
## Accepts named tokens ("cyan", "pink", ...) OR hex strings ("ff00aa", "#ff00aa").
## Optional default_color returned when token is unrecognized.
static func color_from_token(tok: String, default_color: Color = Color.WHITE) -> Color:
	if tok.is_empty():
		return default_color
	# Try named tokens first
	match tok.to_lower():
		"cyan": return Color("52d8ff")
		"pink": return Color("ff6bb5")
		"green": return Color("4aff6b")
		"yellow": return Color("ffd85a")
		"purple": return Color("a77cff")
		"red": return Color("ff4a4a")
		"orange": return Color("ffaa44")
		"white": return Color.WHITE
		"blue": return Color("4a9fff")
		"black": return Color.BLACK
	# Try hex parsing (with or without # prefix)
	var hex := tok.strip_edges()
	if hex.begins_with("#"):
		hex = hex.substr(1)
	if hex.length() == 6:
		var r := hex.substr(0, 2).hex_to_int() / 255.0
		var g := hex.substr(2, 2).hex_to_int() / 255.0
		var b := hex.substr(4, 2).hex_to_int() / 255.0
		return Color(r, g, b)
	elif hex.length() == 8:
		var r := hex.substr(0, 2).hex_to_int() / 255.0
		var g := hex.substr(2, 2).hex_to_int() / 255.0
		var b := hex.substr(4, 2).hex_to_int() / 255.0
		var a := hex.substr(6, 2).hex_to_int() / 255.0
		return Color(r, g, b, a)
	return default_color

static func color_to_hex(c: Color) -> String:
	return "#%02x%02x%02x" % [int(c.r * 255), int(c.g * 255), int(c.b * 255)]

# ─── Achievement IDs ──────────────────────────────────────────────────────────
const ACHIEVEMENT_FIRST_RUN: String = "first_run"
const ACHIEVEMENT_FLAWLESS: String = "flawless"
const ACHIEVEMENT_COIN_COLLECTOR: String = "coin_collector"
const ACHIEVEMENT_FINISH_5: String = "finish_5"
const ACHIEVEMENT_FINISH_10: String = "finish_10"
const ACHIEVEMENT_FINISH_ALL: String = "finish_all"
const ACHIEVEMENT_COINS_10: String = "coins_10"
const ACHIEVEMENT_COINS_25: String = "coins_25"
const ACHIEVEMENT_DEATHS_50: String = "deaths_50"
const ACHIEVEMENT_DEATHS_500: String = "deaths_500"
const ACHIEVEMENT_JUMPS_1000: String = "jumps_1000"
const ACHIEVEMENT_PRACTICE_PRO: String = "practice_pro"
const ACHIEVEMENT_TRIGGER_MASTER: String = "trigger_master"
const ACHIEVEMENT_SPEED_DEMON: String = "speed_demon"
const ACHIEVEMENT_EDITOR: String = "editor"
const ACHIEVEMENT_DAILY_DEVOTEE: String = "daily_devotee"
const ACHIEVEMENT_SPEEDRUNNER: String = "speedrunner"
const ACHIEVEMENT_LINT_MASTER: String = "lint_master"
