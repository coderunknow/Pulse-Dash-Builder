extends StaticBody2D
@onready var outline: Polygon2D = get_node_or_null("Outline")
@onready var danger_glow: Polygon2D = get_node_or_null("DangerGlow")
@onready var hazard_area: Area2D = get_node_or_null("HazardArea")
var _glow_phase: float = 0.0
func _ready() -> void:
	if hazard_area:
		hazard_area.body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	_glow_phase += delta * 3.0
	if danger_glow:
		danger_glow.modulate.a = 0.06 + sin(_glow_phase) * 0.04
func _on_body_entered(body: Node) -> void:
	if body is DashPlayer:
		(body as DashPlayer).die("hazard_block")
