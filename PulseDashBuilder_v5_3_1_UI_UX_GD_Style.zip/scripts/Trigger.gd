## LevelTrigger — Area2D that fires when the player passes through it.
class_name LevelTrigger
extends Area2D

@export var trigger_action: int = 0
@export var target_id: String = ""
@export var color_value: Color = Color.WHITE
@export var duration: float = 0.5
@export var easing: int = 0
@export var text_value: String = ""
@export var vector_value: Vector2 = Vector2.ZERO
@export var pulse_strength: float = 1.0
@export var shake_strength: float = 4.0
@export var shake_duration: float = 0.2

var _fired: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	if not has_meta("object_id"):
		set_meta("object_id", target_id)

func _on_body_entered(body: Node) -> void:
	if _fired:
		return
	if body is DashPlayer:
		_fired = true
		var tc := get_node_or_null("/root/TriggerController")
		if tc:
			tc.trigger_fired.emit(self, body)
