# Pulse Dash Builder — Geometry Dash-style prototype (Godot 4.7.1)

A heavy-scope v3 rewrite of the prototype. Clean modular architecture with five autoloads (GameState, AudioManager, StatsTracker, AchievementManager, TriggerController), a full GD-style trigger system (14 action types), a unified ParticlePool, four background themes, six built-in levels, fifteen achievements, and an expanded editor with undo/redo, copy/paste, an object inspector, and a level settings dialog.

> **Handoff for AI/developers:** read `AI_PROJECT_HANDOFF.md` before changing scripts, scenes, JSON level data, physics layers, or asset-loading code.

> This is an original Geometry Dash-style platformer. It does not bundle any original Geometry Dash assets, songs, or levels. All audio is synthesised at runtime; all visuals are primitive Godot nodes.

## Running the project

1. Import `project.godot` into **Godot 4.7.1**.
2. Press **F6/F5**. Startup scene is `res://scenes/Main.tscn`.
3. Pick a level from the **Level Library**.
4. Default controls:
   - **Space / Enter / left mouse**: action for the current mode.
   - **P**: toggle Practice Mode.
   - **C**: place a Practice checkpoint.
   - **X**: remove the latest checkpoint.
   - **R**: respawn at the latest checkpoint.
   - **M**: mute/unmute audio.
   - **Esc**: pause or return to the Level Library.

## Systems

### 1) Game modes

`DashPlayer` (`scripts/Player.gd`) supports all 8 modes:

| Mode | Action behaviour |
|---|---|
| Cube | Buffered/coyote jump; held action auto-jumps on landing. |
| Ship | Held thrust against gravity; surface contact is lethal. |
| Ball | Action on a surface toggles gravity. |
| UFO | Each press is an air flap. |
| Wave | Held/released produces diagonal motion; surface contact is lethal. |
| Robot | Variable-height jump from a short held window. |
| Spider | Surface action flips gravity and raycasts to the opposite surface. |
| Swing | Surface action toggles gravity. |

Visual rotation is decoupled from the collider so high-speed rotation never snags.

### 2) Portals

`Portal.tscn` / `Portal.gd` supports every portal token:

- Gravity: `gravity_normal`, `gravity_invert`
- Size: `mini`, `normal`
- Speed: `speed_half`, `speed_normal`, `speed_double`, `speed_triple`, `speed_quad`
- Dual: `dual_on`, `dual_off`
- Mirror: `mirror_on`, `mirror_off`
- Mode: `cube`, `ship`, `ball`, `ufo`, `wave`, `robot`, `spider`, `swing`

### 3) Interactive objects

| Scene | `kind` | Mechanic |
|---|---|---|
| `Spike.tscn` | `spike` | Lethal Area2D. |
| `Block.tscn` | `block` | Resizable solid; carries `id` for trigger targeting. |
| `BreakableBlock.tscn` | `breakable` | Solid; breaks only during a Dash Orb boost. |
| `JumpPad.tscn` | `pad` | Yellow/Pink/Red/Blue auto-pad. |
| `JumpOrb.tscn` | `orb` | Yellow/Pink/Red/Blue/Purple/Black/Dash; activated by action while overlapping. |
| `Coin.tscn` | `coin` | Hidden/visible secret coin. |
| `FinishGate.tscn` | `finish` | Level end. |
| **`MovingPlatform.tscn`** | `moving_block` | Oscillating solid; carries the player when standing on it. |
| **`Sawblade.tscn`** | `sawblade` | Rotating lethal hazard; configurable radius/teeth/speed. |
| **`HazardBlock.tscn`** | `hazard_block` | Solid block that also damages the player. |
| **`BouncyBlock.tscn`** | `bouncy_block` | Solid block that auto-bounces the player. |
| **`OscillatingSpike.tscn`** | `oscillating_spike` | Spike that oscillates along an axis. |
| **`KeyLock.tscn`** | `key` / `lock` | Collectible key + matching lock that opens when the key is picked up. |
| **`Trigger.tscn`** | `trigger` | One-shot zone that fires any of 14 trigger actions. |

### 4) Trigger system (Full GD-style)

Triggers are Area2D zones that fire once (configurable `repeat_count`) when the player enters. `TriggerController` resolves the action against targets identified by `target_id` or `target_group`.

| Action token | Effect |
|---|---|
| `color` | Recolor target blocks. |
| `move` | Translate target blocks by `move_delta` over `duration` with `easing`. |
| `rotate` | Rotate target blocks by `rotate_delta` radians over `duration` with `easing`. |
| `pulse` | Pulse screen flash + small camera shake. |
| `alpha` | Fade target blocks to `alpha_value` over `duration`. |
| `toggle` | Show/hide target blocks (also toggles collision). |
| `shake` | Camera shake with `shake_strength` × `shake_duration`. |
| `spawn` | Spawn `spawn_objects` array at runtime. |
| `camera_zoom` | Tween camera zoom to `zoom_factor` over `duration`. |
| `camera_move` | Tween camera offset to `camera_offset` over `duration`. |
| `collision_toggle` | Toggle collision shape on target blocks (visibility unchanged). |
| `background` | Switch parallax background theme + base color. |
| `speed` | Temporarily change player speed multiplier. |
| `counter` | Increment a named counter; used as a condition for other triggers via `required_counter`/`required_count`. |

Easing tokens: `linear`, `quad_in`, `quad_out`, `quad_in_out`, `cubic_in`, `cubic_out`, `cubic_in_out`, `expo_out`, `bounce_out`, `elastic_out`.

Example trigger in JSON:

```json
{"kind":"trigger", "action":"move", "target_id":"gate_a", "move_delta":[0.0,-120.0], "duration":0.6, "easing":"bounce_out", "position":[1240.0,454.0]}
```

### 5) Procedural audio

`AudioManager` autoload synthesises 25 SFX cues as 16-bit PCM `AudioStreamWAV` at runtime — zero audio files required. SFX cover jumps, deaths, coins, portals, pads, orbs, finish, countdown tick/GO, achievement, editor place/remove/undo/redo, trigger colour/pulse/shake/spawn, key pickup, lock open, shrink, grow, bounce.

BGM support: drop `.ogg` / `.wav` / `.mp3` files into `res://audio/bgm/` and they'll be auto-detected. Volume Master/SFX/Music + Mute persist via `GameState`.

### 6) Stats and achievements

`StatsTracker` autoload tracks per-level attempts/deaths/jumps/completions/best %, plus aggregate totals (total deaths, completions, coins, jumps, play time, levels attempted). All persist in `user://geometry_dash_clone/settings.json`.

`AchievementManager` autoload tracks 15 achievements:

| Achievement | Trigger |
|---|---|
| First Steps | Attempt your first level. |
| Flawless Run | Complete a level on your first attempt. |
| Coin Collector | Collect your first secret coin. |
| Finisher ×5 / ×10 / All | Complete 5/10/every built-in level. |
| Coin Hoarder / Vault | Collect 10/25 coins total. |
| Persistence / Demon Slayer | Die 50/500 times. |
| Marathon Runner | Perform 1000 jumps. |
| Practice Pro | Place 10 practice checkpoints in one run. |
| Trigger Master | Fire 25 triggers in one level. |
| Speed Demon | Complete the Speed Demon level. |
| Level Architect | Save your first custom level. |

Achievement toasts appear bottom-centre; the Stats dashboard lists every achievement with progress and per-level breakdowns.

### 7) Visual polish

- **Parallax backdrop**: 3-layer procedural parallax in 4 themes (Neon/Sunset/Aurora/Void). Switchable at runtime via the `background` trigger or level settings.
- **Afterimage pool**: spawns faded silhouettes at 2x+ speed; pool of 24 Polygon2D nodes reused.
- **Particle pool**: unified pool of 96 Polygon2D particles for all bursts (jump, death, coin, portal, trigger, bounce, etc.).
- **Player trail**: Line2D recoloured per game mode.
- **3-2-1-GO countdown** with tick + GO SFX.
- **Mode toast + camera shake + achievement toast**.
- **Hit-flash** on player visual when hit (reserved for hazard-block grazing).
- **Beat-synced progress bar pulse** from `BeatClock`.

## Level library + permanent map editor

### Building a level

1. Level Library → **Create New Level**.
2. Enter a **level name**.
3. Pick an object in the Palette.
4. **Left click** the playfield to place on a 20 px grid.
5. **Right click** to remove the nearest object.
6. **A/D/W/S** pan the editor camera.
7. **Inspector** (hover an object): edit id/color/width/height live.
8. **Ctrl+Z** undo • **Ctrl+Y** / **Ctrl+Shift+Z** redo.
9. **Ctrl+C** / **Ctrl+V** copy/paste.
10. **Del** remove object under cursor.
11. **Ctrl+S** save.
12. **Level Settings...** dialog: edit BPM, length, background theme, difficulty.
13. **Save Level** or Ctrl+S.

Levels are saved as JSON to:

```text
user://geometry_dash_clone/levels/<level-id>.gdlevel.json
```

Coin/progress/achievements/audio/creator settings are persisted in `user://geometry_dash_clone/settings.json`.

### Turning off creator mode

Level Library → **Settings** → toggle **Creator Mode** to `OFF`. The **Create New Level** button is hidden but existing custom levels remain playable. Settings is always reachable to re-enable Creator Mode.

## Built-in levels

| ID | Name | Difficulty |
|---|---|---|
| `builtin_pulse_starter` | Pulse Starter | Easy |
| `builtin_mechanic_gallery` | Mechanic Gallery | Easy |
| `builtin_trigger_wonderland` | Trigger Wonderland | Medium |
| `builtin_spike_gauntlet` | Spike Gauntlet | Hard |
| `builtin_speed_demon` | Speed Demon | Demon |
| `builtin_final_pulse` | Final Pulse | Demon |

## JSON level format (v3)

```json
{
  "format_version": 3,
  "id": "custom_my_level",
  "name": "My First Level",
  "author": "Player",
  "built_in": false,
  "bpm": 140.0,
  "length": 4800.0,
  "start": [160.0, 450.0],
  "background": "neon",
  "difficulty": "easy",
  "objects": [
    {"kind":"block", "id":"gate_a", "position":[2000.0,582.0], "size":[6000.0,64.0], "color":"274676"},
    {"kind":"moving_block", "position":[2400.0,470.0], "size":[160.0,32.0], "color":"4f9bd6", "axis":[1.0,0.0], "distance":200.0, "period":3.0},
    {"kind":"sawblade", "position":[2700.0,480.0], "radius":32.0, "rotation_speed":5.0},
    {"kind":"bouncy_block", "position":[2900.0,520.0], "size":[120.0,32.0], "color":"7cf5a4", "bounce_strength":820.0},
    {"kind":"trigger", "action":"move", "target_id":"gate_a", "move_delta":[0.0,-120.0], "duration":0.6, "easing":"bounce_out", "position":[2300.0,454.0]},
    {"kind":"trigger", "action":"background", "background_theme":"void", "duration":0.8, "position":[2500.0,454.0]},
    {"kind":"coin", "id":"coin_01", "position":[1300.0,350.0], "hidden":true},
    {"kind":"finish", "position":[4400.0,454.0]}
  ]
}
```

`GameState.normalize_level()` fills in missing fields; old format_version 1/2 files still load (with new defaults applied).

## File structure

```text
scripts/
├── GameTypes.gd            # Enums (modes, portals, orbs, pads, triggers, SFX, themes, achievements) + helpers
├── GameState.gd            # Autoload: level library + persistence
├── AudioManager.gd         # Autoload: procedural SFX synthesizer + BGM loader
├── StatsTracker.gd         # Autoload: per-level + aggregate stats
├── AchievementManager.gd   # Autoload: 15 achievements
├── TriggerController.gd    # Autoload: resolves all 14 trigger actions
├── ObjectFactory.gd        # Static dispatch: spawns any object from JSON
├── Main.gd                 # Game director: state machine, HUD, menu, editor, stats dashboard
├── Player.gd               # 8-mode controller + audio/stats hooks
├── Block.gd / Spike.gd / Portal.gd / JumpOrb.gd / JumpPad.gd / BreakableBlock.gd / Coin.gd / FinishGate.gd
├── MovingPlatform.gd       # Oscillating solid + rider carry
├── Sawblade.gd             # Rotating hazard
├── HazardBlock.gd          # Damaging solid
├── BouncyBlock.gd          # Auto-bouncing solid
├── OscillatingSpike.gd     # Moving spike
├── KeyLock.gd              # Key + lock pair
├── Trigger.gd              # One-shot trigger zone
├── ParallaxBackdrop.gd     # 3-layer procedural parallax (4 themes)
├── AfterImagePool.gd       # Pooled afterimage renderer
├── ParticlePool.gd         # Unified pooled particle system
└── BeatClock.gd            # BPM pulse clock

scenes/
├── Main.tscn               # Root scene with all UI layers
├── Player.tscn
├── Block.tscn / Spike.tscn / BreakableBlock.tscn
├── Portal.tscn / JumpOrb.tscn / JumpPad.tscn / Coin.tscn / FinishGate.tscn
├── MovingPlatform.tscn / Sawblade.tscn / HazardBlock.tscn
├── BouncyBlock.tscn / OscillatingSpike.tscn / KeyLock.tscn / Trigger.tscn
```

## Collision matrix

| Layer | Bit | Objects | Mask | Purpose |
|---|---:|---|---:|---|
| World / Ground | 1 | Block, BreakableBlock, MovingPlatform, BouncyBlock, HazardBlock | 0 | Solid collision. |
| Player | 2 | DashPlayer | 1 | Only collides with solids. |
| Hazards | 4 | Spike, Sawblade, HazardBlock (area) | 2 | Detect player; never ramps/blocks. |
| Trigger | 0 | Portal, Orb, Pad, Coin, FinishGate, Trigger, BouncyBlock (area), KeyLock | 2 | Detect player without blocking. |

## Performance notes

- **No scene reloads on death.** `_instant_respawn()` rebuilds only the dynamic world.
- **Pooled particles** (96 nodes) and **pooled afterimages** (24 nodes) — no per-frame allocations during steady-state gameplay.
- **TriggerController uses Tweens** for animated actions (Move/Rotate/Alpha/Camera). Tweens are cleaned up automatically by Godot when their target is freed.
- **All level data is JSON-safe primitives** (numbers, strings, booleans, arrays, dictionaries).
- **All optional assets use `ResourceLoader.exists()`** — replacing or deleting any PNG keeps the game running with procedural fallbacks.
- **Audio is fully procedural** — no audio files required; 25 SFX are synthesised as 16-bit PCM at startup.

## Extension notes

To add a new gameplay object:

1. Add a new `kind` token and the corresponding scene/script.
2. Add a spawn branch in `ObjectFactory.gd`.
3. Add an editor palette entry in `Main._populate_editor_palette()`.
4. Add a `_make_editor_object` branch in `Main.gd`.
5. (Optional) Add trigger support by exposing `apply_color`/`apply_alpha`/`apply_toggle`/`apply_collision_toggle`/`apply_move`/`apply_rotate` methods on the new node — `TriggerController` will pick them up via `has_method`.

To add a new trigger action:

1. Append to `GDGameTypes.TriggerAction` (do not reorder).
2. Add token mapping in `GameTypes.gd`.
3. Add an `_apply_*` method in `TriggerController.gd` and a branch in `_resolve_action`.
4. Add a palette entry `trigger_<token>` in `Main._populate_editor_palette`.
5. Add a `_make_editor_object` branch in `Main.gd`.

To add a new achievement:

1. Add a `const` ID in `GameTypes.gd` and an entry in `AchievementManager.ACHIEVEMENT_DEFS`.
2. Add the unlock condition check (either in `_on_stat_changed` or via a `notify_*` method).
3. Call the appropriate `notify_*` from `Main.gd` when the event fires.
