# UI/UX Improvements — Geometry Dash Style Overhaul

> **Version:** v5.3.1 (UI/UX Patch)
> **Date:** 2026-07-27
> **Based on:** PulseDashBuilder v5.3 Visual Overhaul Complete

## Summary of Changes

This patch overhauls the in-game HUD to match Geometry Dash's clean, minimal aesthetic.
The goal is to reduce visual clutter during gameplay and let the level design shine.

---

## Changes Made

### 1. Progress Bar — Full-Width Thin Bar (GD Style)
**Before:** Centered 300px bar with thick border and rounded corners, floating in the middle-top area.
**After:** Full-width 6px thin bar at the very top edge of the screen, no border, no rounded corners.
- Matches GD's signature progress indicator
- Background is nearly invisible (60% alpha dark)
- Fill is a clean bright cyan with no border
- Percentage label sits just below the bar, centered, with text outline for readability

### 2. Level Info Panel — Compact & Auto-Hiding
**Before:** Large 358×106px panel with bright cyan border, always visible during gameplay.
**After:** Smaller 268×78px panel with subtle border (30% alpha), auto-fades after ~2.5 seconds.
- Shows level name, attempt number, and mode on spawn/respawn
- Fades out smoothly over 0.5 seconds once the timer expires
- Re-appears briefly on each death/respawn (showing new attempt number)
- Much less visual obstruction during gameplay

### 3. Removed Gameplay Clutter
**Before:** "BEST 100%" and "TRIGGERS: 0" always visible in top-right corner.
**After:** Both labels hidden during gameplay (`visible = false`).
- These stats belong on the level select / completion screen, not during play
- Reduces cognitive load and visual noise
- Coin counter (◈) remains but is smaller and has text outline for readability

### 4. Bottom Buttons — Subtle Floating Style
**Before:** Default Godot buttons with heavy dark backgrounds spanning bottom of screen.
**After:** Custom semi-transparent StyleBox with subtle 1px border, rounded 4px corners.
- Practice button: bottom-left, 120×28px, muted colors
- Pause button: bottom-right, 70×28px, muted colors
- Hover state: slightly brighter background and border
- No full-width dark bar anymore — buttons float cleanly over the game

### 5. New StyleBox Resources Added
- `StyleBoxFlat_btn_subtle` — Normal state for HUD buttons (55% alpha dark, 25% alpha border)
- `StyleBoxFlat_btn_hover` — Hover/pressed state for HUD buttons (75% alpha, 50% alpha border)

### 6. Script Logic — Auto-Hide Timer
New function `_update_hud_info_fade(delta)` manages the info panel lifecycle:
- 2.5s countdown after "GO!" disappears (first attempt)
- 2.0s countdown after each respawn
- Smooth alpha fade from 1.0 → 0.0 over 0.5s
- Panel set to `visible = false` after fade completes (zero render cost)

### 7. Indentation Fix
Fixed mixed tab/space indentation throughout Main.gd (converted all tabs to 8-space indents
for consistency and to prevent potential GDScript parse errors).

---

## Visual Comparison

| Element | Before | After |
|---------|--------|-------|
| Progress bar | 300px centered, thick border | Full-width 6px, no border |
| Info panel | 358×106, bright border, always on | 268×78, subtle, auto-hides |
| BEST % | Visible top-right | Hidden |
| TRIGGERS | Visible top-right | Hidden |
| Bottom buttons | Heavy default style | Subtle floating chips |
| Coin counter | Large, no outline | Smaller, text outline |

---

## Files Modified

1. `scenes/Main.tscn` — Complete GameHUD section rewrite + new StyleBox resources
2. `scripts/Main.gd` — Added `top_panel` reference, fade timer vars, `_update_hud_info_fade()`,
   respawn re-show logic, indentation fix

---

## How It Feels Now

- **Cleaner screen** — Your eyes focus on the gameplay, not the UI
- **GD-like flow** — See attempt number briefly, then it's gone; just you and the level
- **Minimal but informative** — Progress bar always visible (thin, unobtrusive), pause accessible
- **Professional polish** — Text outlines, subtle transparency, smooth fades
